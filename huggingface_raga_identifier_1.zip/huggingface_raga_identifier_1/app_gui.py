import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import argparse

# --- FORCE 100% OFFLINE MODE ---
os.environ["GRADIO_ANALYTICS_ENABLED"] = "False"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["DO_NOT_TRACK"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
# -------------------------------

import torch
import torchaudio
import numpy as np
from utils.YParams import YParams
from inference import Evaluator

class RagaClassifierApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Carnatic Raga Classifier (Offline)")
        self.root.geometry("650x550")
        self.root.minsize(500, 400)
        
        self.file_path = None
        self.evaluator = None
        
        self.setup_ui()
        
        # Load the AI model in the background so the UI doesn't freeze on startup
        self.status_var.set("Status: Loading AI Model... (Please wait)")
        threading.Thread(target=self.load_model, daemon=True).start()

    def setup_ui(self):
        # --- Top Frame: File Selection ---
        top_frame = ttk.Frame(self.root, padding="10")
        top_frame.pack(fill=tk.X)
        
        ttk.Label(top_frame, text="Audio File:").pack(side=tk.LEFT)
        self.file_label = ttk.Label(top_frame, text="No file selected...", foreground="gray")
        self.file_label.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        self.browse_btn = ttk.Button(top_frame, text="Browse...", command=self.browse_file)
        self.browse_btn.pack(side=tk.RIGHT)

        # --- Middle Frame: Settings ---
        mid_frame = ttk.Frame(self.root, padding="10")
        mid_frame.pack(fill=tk.X)
        
        ttk.Label(mid_frame, text="Number of Top Ragas to Display:").pack(side=tk.LEFT)
        self.top_k_var = tk.IntVar(value=5)
        self.k_spinbox = ttk.Spinbox(mid_frame, from_=1, to=50, textvariable=self.top_k_var, width=5)
        self.k_spinbox.pack(side=tk.LEFT, padx=5)

        # --- Action Frame ---
        action_frame = ttk.Frame(self.root, padding="10")
        action_frame.pack(fill=tk.X)
        
        self.analyze_btn = ttk.Button(action_frame, text="Analyze Audio", command=self.start_analysis, state=tk.DISABLED)
        self.analyze_btn.pack(side=tk.LEFT, padx=5)
        
        self.clear_btn = ttk.Button(action_frame, text="Clear Results", command=self.clear_results)
        self.clear_btn.pack(side=tk.LEFT, padx=5)
        
        self.status_var = tk.StringVar(value="Status: Initializing...")
        self.status_label = ttk.Label(action_frame, textvariable=self.status_var, foreground="blue", font=("Arial", 9, "italic"))
        self.status_label.pack(side=tk.RIGHT)

        # --- Bottom Frame: Results ---
        bottom_frame = ttk.Frame(self.root, padding="10")
        bottom_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(bottom_frame, text="Prediction Results:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        self.output_text = tk.Text(bottom_frame, wrap=tk.WORD, state=tk.DISABLED, font=("Consolas", 11))
        self.output_text.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Scrollbar for results
        scrollbar = ttk.Scrollbar(bottom_frame, orient=tk.VERTICAL, command=self.output_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.output_text.config(yscrollcommand=scrollbar.set)

    def load_model(self):
        try:
            # Setup parameters (same as app.py but hardcoded for GUI)
            params = YParams(os.path.abspath('config.yaml'), 'resnet_0.7')
            
            try:
                params.device = torch.device(torch.cuda.current_device())
            except:
                params.device = "cpu"
            
            expDir = "ckpts/resnet_0.7/150classes_alldata_cliplength30"
            params['best_checkpoint_path'] = os.path.join(expDir, 'training_checkpoints/best_ckpt.tar')
            
            # Initialize the Evaluator
            self.evaluator = Evaluator(params)
            
            # Update UI safely from background thread
            self.root.after(0, self.model_loaded_success)
        except Exception as e:
            self.root.after(0, self.model_loaded_error, str(e))

    def model_loaded_success(self):
        self.status_var.set("Status: Ready! Select an audio file.")
        self.status_label.config(foreground="green")
        self.analyze_btn.config(state=tk.NORMAL)

    def model_loaded_error(self, error_msg):
        self.status_var.set("Status: Error loading model!")
        self.status_label.config(foreground="red")
        messagebox.showerror("Model Error", f"Failed to load the AI model.\n\nError:\n{error_msg}")

    def browse_file(self):
        filetypes = (
            ("Audio files", "*.wav *.mp3 *.flac *.ogg"),
            ("All files", "*.*")
        )
        path = filedialog.askopenfilename(filetypes=filetypes)
        if path:
            self.file_path = path
            # Show just the filename in the UI
            filename = os.path.basename(path)
            self.file_label.config(text=filename, foreground="black")

    def start_analysis(self):
        if not self.file_path:
            messagebox.showwarning("No File", "Please select an audio file first.")
            return
            
        self.status_var.set("Status: Analyzing... (This may take a few seconds)")
        self.status_label.config(foreground="orange")
        self.analyze_btn.config(state=tk.DISABLED)
        
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, "Processing audio waves...\nPlease wait.\n\n")
        self.output_text.config(state=tk.DISABLED)
        
        # Run inference in a background thread so the window doesn't freeze
        threading.Thread(target=self.run_inference, daemon=True).start()

    def run_inference(self):
        try:
            # 1. Load audio using torchaudio
            waveform, sample_rate = torchaudio.load(self.file_path)
            
            # 2. Convert to numpy array
            audio_np = waveform.numpy()
            
            # --- FIX: Handle Mono vs Stereo audio ---
            # The AI model expects 2 channels (stereo).
            if audio_np.ndim == 2 and audio_np.shape[0] == 1:
                # MONO file: squeeze to 1D so inference.py auto-converts it to stereo
                audio_np = audio_np.squeeze(0)
            elif audio_np.ndim == 2:
                # STEREO file: transpose to (time, channels) format
                audio_np = audio_np.T
            # ------------------------------------------
            
            audio_tuple = (sample_rate, audio_np)
            
            # 3. Run the AI model
            k = self.top_k_var.get()
            results = self.evaluator.inference(k, audio_tuple)
            
            # 4. Update UI with results
            self.root.after(0, self.display_results, results)
            
        except Exception as e:
            self.root.after(0, self.display_error, str(e))

    def display_results(self, results):
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete(1.0, tk.END)
        
        self.output_text.insert(tk.END, "=== PREDICTION RESULTS ===\n\n", "header")
        self.output_text.tag_config("header", font=("Arial", 12, "bold"))
        
        # Sort by confidence (highest first) just in case
        sorted_results = sorted(results.items(), key=lambda x: x[1], reverse=True)
        
        for i, (raga, score) in enumerate(sorted_results):
            confidence = score * 100
            self.output_text.insert(tk.END, f"#{i+1}  {raga}\n")
            self.output_text.insert(tk.END, f"     Confidence: {confidence:.2f}%\n\n")
            
        self.output_text.config(state=tk.DISABLED)
        self.status_var.set("Status: Analysis Complete!")
        self.status_label.config(foreground="green")
        self.analyze_btn.config(state=tk.NORMAL)

    def display_error(self, error_msg):
        messagebox.showerror("Analysis Error", f"Could not analyze this file.\n\nError:\n{error_msg}")
        self.status_var.set("Status: Ready (Error occurred)")
        self.status_label.config(foreground="green")
        self.analyze_btn.config(state=tk.NORMAL)
        
    def clear_results(self):
        self.output_text.config(state=tk.NORMAL)
        self.output_text.delete(1.0, tk.END)
        self.output_text.config(state=tk.DISABLED)

if __name__ == "__main__":
    root = tk.Tk()
    app = RagaClassifierApp(root)
    root.mainloop()