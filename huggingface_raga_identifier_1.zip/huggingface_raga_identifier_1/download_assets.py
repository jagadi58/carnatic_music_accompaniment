import os
import urllib.request

BASE_URL = "https://huggingface.co/spaces/jeevster/carnatic-raga-classifier/resolve/main"

# List of files to download: (remote_path, local_path)
files_to_download = [
    ("labeled_0.7_wav_metadata.json", "labeled_0.7_wav_metadata.json"),
    ("metadata_0.7.json", "metadata_0.7.json"),
    ("about.md", "about.md"),
    ("site/tsne.jpeg", "site/tsne.jpeg"),
    ("ckpts/resnet_0.7/150classes_alldata_cliplength30/training_checkpoints/best_ckpt.tar", 
     "ckpts/resnet_0.7/150classes_alldata_cliplength30/training_checkpoints/best_ckpt.tar")
]

print("Starting download of required assets...")

for remote_path, local_path in files_to_download:
    url = f"{BASE_URL}/{remote_path}"
    
    # Create directories if they don't exist
    directory = os.path.dirname(local_path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    
    print(f"Downloading {local_path}...")
    try:
        urllib.request.urlretrieve(url, local_path)
        print(f"✅ Successfully downloaded {local_path}")
    except Exception as e:
        print(f"❌ Failed to download {local_path}: {e}")

print("\nAll downloads complete! You can now run app.py.")