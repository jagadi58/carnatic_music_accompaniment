import os
import subprocess
import sys

def download_packages():
    output_dir = "offline_packages"
    os.makedirs(output_dir, exist_ok=True)

    # Exact requirements needed for the Raga Classifier
    # Pinned huggingface_hub to <1.0.0 to prevent the HfFolder error
    requirements = [
        "torch",
        "torchaudio",
        "numpy",
        "ruamel.yaml",
        "gradio==4.26.0",
        "huggingface_hub<1.0.0"
    ]

    temp_req_file = "temp_requirements.txt"
    with open(temp_req_file, "w") as f:
        for req in requirements:
            f.write(req + "\n")

    print(f"⏳ Starting download of packages to './{output_dir}'...")
    print("   (This may take a few minutes as PyTorch is a large download)\n")
    
    # Run pip download
    command = [
        sys.executable, "-m", "pip", "download", 
        "-r", temp_req_file, 
        "-d", output_dir
    ]
    
    try:
        subprocess.check_call(command)
        print("\n" + "="*50)
        print("✅ SUCCESS: All offline packages downloaded!")
        print(f"📁 You can now copy the '{output_dir}' folder to your USB drive.")
        print("="*50)
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Failed to download packages. Error: {e}")
    finally:
        if os.path.exists(temp_req_file):
            os.remove(temp_req_file)

if __name__ == "__main__":
    download_packages()