import os
import urllib.request
import sys

BASE_URL = "https://huggingface.co/spaces/jeevster/carnatic-raga-classifier/resolve/main"

# All files needed: (remote_path, local_path)
files_to_download = [
    # Model checkpoint (66 MB) - REQUIRED for inference
    ("ckpts/resnet_0.7/150classes_alldata_cliplength30/training_checkpoints/best_ckpt.tar",
     "ckpts/resnet_0.7/150classes_alldata_cliplength30/training_checkpoints/best_ckpt.tar"),
    
    # JSON metadata files - REQUIRED for label mapping
    ("labeled_0.7_wav_metadata.json", "labeled_0.7_wav_metadata.json"),
    ("metadata_0.7.json", "metadata_0.7.json"),
    
    # UI assets - For the "About" tab in Gradio
    ("about.md", "about.md"),
    ("site/tsne.jpeg", "site/tsne.jpeg"),
]

def download_file(url, local_path):
    """Download a file with basic progress indication."""
    directory = os.path.dirname(local_path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    
    try:
        # Get file size for progress
        req = urllib.request.Request(url, method='HEAD')
        response = urllib.request.urlopen(req)
        file_size = int(response.headers.get('Content-Length', 0))
        
        # Download the file
        urllib.request.urlretrieve(url, local_path)
        
        size_mb = os.path.getsize(local_path) / (1024 * 1024)
        print(f"  ✅ {local_path} ({size_mb:.1f} MB)")
        return True
        
    except Exception as e:
        print(f"  ❌ FAILED: {local_path}")
        print(f"     Error: {e}")
        return False

def main():
    print("=" * 60)
    print("  CARNATIC RAGA CLASSIFIER - ASSET DOWNLOADER")
    print("=" * 60)
    print(f"\n  Source: {BASE_URL}")
    print(f"  Downloading {len(files_to_download)} files...\n")
    
    success_count = 0
    fail_count = 0
    
    for remote_path, local_path in files_to_download:
        url = f"{BASE_URL}/{remote_path}"
        print(f"  Downloading: {local_path}")
        
        if download_file(url, local_path):
            success_count += 1
        else:
            fail_count += 1
    
    print("\n" + "=" * 60)
    if fail_count == 0:
        print(f"  ✅ ALL {success_count} FILES DOWNLOADED SUCCESSFULLY!")
        print("  You can now run: python app.py")
    else:
        print(f"  ⚠️  {success_count} downloaded, {fail_count} FAILED.")
        print("  Please check your internet connection and try again.")
    print("=" * 60)

if __name__ == "__main__":
    main()