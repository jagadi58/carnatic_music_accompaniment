#!/usr/bin/env python3
"""
Audio Mixer for Carnatic Accompanist.
Combines vocal audio with generated accompaniment into a true Stereo mix
(Vocal = Left Channel, Instruments = Right Channel).
"""

import numpy as np
from pathlib import Path
from typing import Dict, Any, Optional, Callable

from src.instruments.sruti_box import SrutiBox
from src.instruments.harmonium import Harmonium
from src.instruments.mridangam import Mridangam
from src.instruments.veena import Veena
from src.instruments.clarinet import Clarinet
from src.core.audio_loader import AudioLoader


class AudioMixer:
    """Mixes vocal and accompaniment tracks with per-track controls."""

    def __init__(self):
        self.sruti_box = SrutiBox()
        self.harmonium = Harmonium()
        self.veena = Veena()
        self.clarinet = Clarinet()
        self.mridangam = Mridangam()
        self.audio_loader = AudioLoader()

    def generate_accompaniment(
        self,
        vocal_audio: Optional[np.ndarray],
        duration: float,
        sr: int,
        sruti_freq: float,
        bpm: float,
        aksharas: int,
        instrument_params: Dict[str, Dict[str, Any]],
        frequencies: Optional[np.ndarray] = None,
        confidences: Optional[np.ndarray] = None,
        pitch_times: Optional[np.ndarray] = None,
        progress_callback: Optional[Callable[[int], None]] = None
    ) -> Dict[str, np.ndarray]:
        """Generate all accompaniment tracks."""
        tracks = {}
        # NEW: silence tracker leakage during breaths (energy without harmonics)
        if frequencies is not None and confidences is not None and vocal_audio is not None:
            try:
                from src.core.breath_detector import breath_quality
                pt = pitch_times if pitch_times is not None else np.arange(len(confidences)) / 100.0
                q = breath_quality(vocal_audio, sr, np.asarray(pt, dtype=float))
                confidences = confidences * np.where(q > 0.3, 1.0, 0.0)
            except Exception as e:
                print("[breath] gate skipped:", e)

        # 1. Sruti Box
        sruti_params = instrument_params.get("sruti", self.sruti_box.get_default_params())
        tracks["sruti"] = self.sruti_box.generate(
            duration, sr, sruti_params, sruti_freq=sruti_freq
        )
        if progress_callback: progress_callback(20)

        # 2. Harmonium
        harm_params = instrument_params.get("harmonium", self.harmonium.get_default_params())
        tracks["harmonium"] = self.harmonium.generate(
            duration, sr, harm_params,
            frequencies=frequencies, confidences=confidences, pitch_times=pitch_times,
            sruti_freq=sruti_freq, vocal_audio=vocal_audio
        )
        if progress_callback: progress_callback(40)

        # 3. Veena
        veena_params = instrument_params.get("veena", self.veena.get_default_params())
        tracks["veena"] = self.veena.generate(
            duration, sr, veena_params,
            start_freq=sruti_freq, frequencies=frequencies, confidences=confidences,
            pitch_times=pitch_times,
            sruti_freq=sruti_freq, vocal_audio=vocal_audio
        )
        if progress_callback: progress_callback(60)

        # 4. Clarinet
        clar_params = instrument_params.get("clarinet", self.clarinet.get_default_params())
        tracks["clarinet"] = self.clarinet.generate(
            duration, sr, clar_params,
            start_freq=sruti_freq, frequencies=frequencies, confidences=confidences,
            pitch_times=pitch_times,
            sruti_freq=sruti_freq, vocal_audio=vocal_audio
        )
        if progress_callback: progress_callback(80)

        # 5. Mridangam — RECEIVES THE VOCAL + SRUTI (the missing wire)
        mrid_params = instrument_params.get("mridangam", self.mridangam.get_default_params())
        tracks["mridangam"] = self.mridangam.generate(
            duration, sr, mrid_params, bpm=bpm, aksharas=aksharas,
            vocal_audio=vocal_audio, sruti_freq=sruti_freq
        )
        if progress_callback: progress_callback(90)

        return tracks

    def mix_tracks(
        self,
        vocal_audio: Optional[np.ndarray],
        accompaniment_tracks: Dict[str, np.ndarray],
        vocal_volume: float = 1.0
    ) -> np.ndarray:
        max_len = len(vocal_audio) if vocal_audio is not None else 0
        for track in accompaniment_tracks.values():
            max_len = max(max_len, len(track))

        if max_len == 0:
            raise ValueError("No audio to mix")

        stereo_mix = np.zeros((max_len, 2), dtype=np.float32)

        if vocal_audio is not None:
            vocal_scaled = vocal_audio * np.clip(vocal_volume, 0.0, 2.0)
            if len(vocal_scaled) < max_len:
                vocal_scaled = np.pad(vocal_scaled, (0, max_len - len(vocal_scaled)))
            else:
                vocal_scaled = vocal_scaled[:max_len]
            stereo_mix[:, 0] = vocal_scaled

        for track in accompaniment_tracks.values():
            if len(track) < max_len:
                track_padded = np.pad(track, (0, max_len - len(track)))
            else:
                track_padded = track[:max_len]
            stereo_mix[:, 1] += track_padded

        peak = np.max(np.abs(stereo_mix))
        if peak > 1.0:
            stereo_mix = stereo_mix / peak

        return stereo_mix.astype(np.float32)

    def mix_and_export(
        self, vocal_audio, sr, sruti_freq, bpm, aksharas, instrument_params,
        vocal_volume, output_path, frequencies=None, confidences=None,
        pitch_times=None, progress_callback=None
    ) -> str:
        duration = len(vocal_audio) / sr if vocal_audio is not None else 10.0

        if progress_callback: progress_callback(10)

        acc_tracks = self.generate_accompaniment(
            vocal_audio, duration, sr, sruti_freq, bpm, aksharas, instrument_params,
            frequencies=frequencies, confidences=confidences, pitch_times=pitch_times,
            progress_callback=progress_callback
        )

        if progress_callback: progress_callback(95)

        final_mix = self.mix_tracks(vocal_audio, acc_tracks, vocal_volume)
        self.audio_loader.save(output_path, final_mix, sr)

        if progress_callback: progress_callback(100)

        return str(Path(output_path).resolve())