#!/usr/bin/env python3
"""
Generic JSON database manager for Carnatic Accompanist.
Handles CRUD operations for ragas, talas, and instruments.
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Optional
import threading

class JSONDatabase:
    """Thread-safe JSON database manager."""
    
    def __init__(self, file_path: str, default_data: Dict[str, Any] = None):
        self.file_path = Path(file_path)
        self.default_data = default_data or {}
        self._lock = threading.Lock()
        self._ensure_file_exists()
    
    def _ensure_file_exists(self):
        """Create the file with default data if it doesn't exist."""
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.file_path.exists():
            self.save(self.default_data)
    
    def load(self) -> Dict[str, Any]:
        """Load data from the JSON file."""
        with self._lock:
            try:
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                # If file is corrupted, reset to default
                self.save(self.default_data)
                return self.default_data
    
    def save(self, data: Dict[str, Any]):
        """Save data to the JSON file."""
        with self._lock:
            with open(self.file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
    
    def get_all(self, key: str) -> List[Dict[str, Any]]:
        """Get all entries under a specific key."""
        data = self.load()
        return data.get(key, [])
    
    def add_entry(self, key: str, entry: Dict[str, Any]):
        """Add a new entry to a specific key."""
        data = self.load()
        if key not in data:
            data[key] = []
        
        # Check for duplicates based on 'name' field if it exists
        if 'name' in entry:
            if any(item.get('name') == entry['name'] for item in data[key]):
                raise ValueError(f"Entry with name '{entry['name']}' already exists.")
        
        data[key].append(entry)
        self.save(data)
    
    def update_entry(self, key: str, name: str, new_data: Dict[str, Any]):
        """Update an existing entry by name."""
        data = self.load()
        if key not in data:
            raise KeyError(f"Key '{key}' not found in database.")
        
        for i, item in enumerate(data[key]):
            if item.get('name') == name:
                data[key][i] = {**item, **new_data}  # Merge old and new data
                self.save(data)
                return
        
        raise ValueError(f"Entry with name '{name}' not found.")
    
    def delete_entry(self, key: str, name: str):
        """Delete an entry by name."""
        data = self.load()
        if key not in data:
            return
        
        data[key] = [item for item in data[key] if item.get('name') != name]
        self.save(data)