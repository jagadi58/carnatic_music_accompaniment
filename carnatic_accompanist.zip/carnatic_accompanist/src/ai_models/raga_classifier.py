#!/usr/bin/env python3
"""
Offline AI Raga Classifier adapter (ResNet, jeevster/carnatic-raga-classifier).
Loads the local checkpoint from <project_root>/ai_raga_classifier and exposes
identify(audio, sr, top_k) -> [{"name": ..., "score": ...}, ...].
100% offline; returns None on any failure so the rule-based identifier
remains the safety net.
"""
import os
import sys
import numpy as np
from pathlib import Path

# Force offline mode BEFORE torch/hub imports
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
MODEL_DIR = _PROJECT_ROOT / "ai_raga_classifier"

# Keep the heavy model loaded across calls/instances
_SHARED = {"evaluator": None, "failed": False}


class AIRagaClassifier:
    def __init__(self, model_dir=None):
        self.model_dir = Path(model_dir) if model_dir else MODEL_DIR

    def load(self):
        if _SHARED["evaluator"] is not None:
            return True
        if _SHARED["failed"]:
            return False
        if not self.model_dir.exists():
            print("[AI Raga] model folder missing:", self.model_dir)
            _SHARED["failed"] = True
            return False
        try:
            import torch
            if str(self.model_dir) not in sys.path:
                sys.path.insert(0, str(self.model_dir))
            from utils.YParams import YParams
            from inference import Evaluator

            cwd = os.getcwd()
            os.chdir(self.model_dir)   # config.yaml + metadata are relative
            try:
                params = YParams('config.yaml', 'resnet_0.7')
                params.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
                params['best_checkpoint_path'] = os.path.join(
                    "ckpts", "resnet_0.7", "150classes_alldata_cliplength30",
                    "training_checkpoints", "best_ckpt.tar")
                print("[AI Raga] loading offline ResNet (first time only)...")
                _SHARED["evaluator"] = Evaluator(params)
            finally:
                os.chdir(cwd)
            print("[AI Raga] model loaded.")
            return True
        except Exception as e:
            print("[AI Raga] load failed:", e)
            _SHARED["failed"] = True
            return False

    def identify(self, audio, sr, top_k=5):
        if not self.load():
            return None
        try:
            a = np.asarray(audio, dtype=np.float32)
            if a.ndim > 1:
                a = a.mean(axis=1)
            cwd = os.getcwd()
            os.chdir(self.model_dir)
            try:
                res = _SHARED["evaluator"].inference(top_k, (int(sr), a))
            finally:
                os.chdir(cwd)
            return [{"name": str(k), "score": float(v)}
                    for k, v in sorted(res.items(), key=lambda kv: kv[1], reverse=True)]
        except Exception as e:
            print("[AI Raga] inference failed:", e)
            return None