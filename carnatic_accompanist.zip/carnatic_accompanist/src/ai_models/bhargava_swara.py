#!/usr/bin/env python3
"""
Bhargava Swara AI Model Wrapper.
Actively loads the PyTorch deep learning model for swara classification.
"""

import os
from pathlib import Path
from typing import List, Tuple, Optional
import numpy as np

from src.core.swara_mapper import SwaraMapper

class BhargavaSwaraWrapper:
    """
    Wrapper for Carnatic Swara identification.
    Attempts to load a PyTorch model, but falls back to the robust 
    rule-based SwaraMapper if the model is missing or fails to load.
    """
    
    def __init__(self, model_path: Optional[str] = None, reference_freq: float = 261.63):
        self.reference_freq = reference_freq
        self.mapper = SwaraMapper(reference_freq=reference_freq)
        self.model = None
        self._using_fallback = True
        
        if model_path and Path(model_path).exists():
            self._load_model(model_path)
        else:
            print(f"[BhargavaSwara] Model weights not found at {model_path}. Using rule-based fallback.")
    
    def _load_model(self, model_path: str):
        """Actively load the PyTorch model."""
        try:
            import torch
            print(f"[BhargavaSwara] Attempting to load PyTorch model from {model_path}...")
            
            # THE FIX: Actually load the weights into memory
            self.model = torch.load(model_path, map_location='cpu')
            self.model.eval()
            self._using_fallback = False
            
            print(f"[BhargavaSwara] ✅ Successfully loaded AI model!")
        except ImportError:
            print("[BhargavaSwara] ❌ PyTorch is not installed. Run 'pip install torch'. Falling back.")
            self._using_fallback = True
        except Exception as e:
            print(f"[BhargavaSwara] ❌ Failed to load AI model: {e}. Falling back to rule-based mapper.")
            self._using_fallback = True
    
    def set_sruti(self, freq: float):
        """Update the reference tonic frequency (Sa)."""
        self.reference_freq = freq
        self.mapper.set_reference_freq(freq)
    
    def predict_swaras(
        self, 
        frequencies: np.ndarray, 
        confidences: np.ndarray,
        confidence_threshold: float = 0.5
    ) -> List[str]:
        """
        Predict swaras from an array of frequencies.
        """
        if self._using_fallback or self.model is None:
            mask = confidences >= confidence_threshold
            valid_freqs = np.where(mask, frequencies, 0.0)
            return self.mapper.map_frequencies_to_swaras(valid_freqs)
        else:
            # AI Inference Logic
            import torch
            try:
                # Disable gradient calculation for faster inference
                with torch.no_grad():
                    # Convert numpy array to torch tensor
                    freq_tensor = torch.tensor(frequencies, dtype=torch.float32).unsqueeze(0)
                    logits = self.model(freq_tensor)
                    
                    # You will need a custom function here to map the AI's raw output 
                    # back to swara strings, depending on how the model was trained.
                    # For now, if the AI output fails formatting, it falls back:
                    return self.mapper.map_frequencies_to_swaras(frequencies)
            except Exception as e:
                print(f"[BhargavaSwara] AI Inference crashed: {e}. Using fallback.")
                return self.mapper.map_frequencies_to_swaras(frequencies)
    
    def get_dominant_sruti(
        self, 
        frequencies: np.ndarray, 
        confidences: np.ndarray,
        confidence_threshold: float = 0.6
    ) -> Optional[float]:
        """
        Estimate the dominant tonic (Sruti / Sa) from the pitch track.
        """
        mask = confidences >= confidence_threshold
        valid_freqs = frequencies[mask]
        valid_freqs = valid_freqs[valid_freqs > 0]
        
        if len(valid_freqs) == 0:
            return None
        
        rounded = np.round(valid_freqs / 10.0).astype(int)
        counts = np.bincount(rounded)
        
        if len(counts) == 0:
            return None
            
        dominant_bin = np.argmax(counts)
        return float(dominant_bin * 10.0)