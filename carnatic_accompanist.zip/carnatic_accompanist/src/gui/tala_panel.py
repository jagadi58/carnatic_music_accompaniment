#!/usr/bin/env python3
"""
Tala identification and database management panel.
"""

from pathlib import Path
from typing import Optional

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox,
    QFormLayout, QLineEdit, QTextEdit, QMessageBox, QDialog, QDialogButtonBox
)
from PyQt6.QtCore import pyqtSignal

from src.core.tala_identifier import TalaIdentifier
from src.utils.json_db import JSONDatabase


class TalaPanel(QWidget):
    """Panel for tala identification and database management."""
    
    tala_identified = pyqtSignal(str, float)  # tala_name, confidence
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.db_path = Path("config/databases/talas.json")
        self.db = JSONDatabase(str(self.db_path), default_data={"talas": []})
        self.identifier = TalaIdentifier(str(self.db_path))
        
        self.current_audio = None
        self.current_sr = None
        
        self.init_ui()
        self.refresh_table()
    
    def init_ui(self):
        """Initialize the UI."""
        layout = QVBoxLayout(self)
        
        # Identification Results Group
        result_group = QGroupBox("Identified Tala")
        result_layout = QVBoxLayout(result_group)
        
        self.lbl_detected_tala = QLabel("No audio analyzed yet")
        self.lbl_detected_tala.setStyleSheet("font-size: 18px; font-weight: bold; color: blue;")
        result_layout.addWidget(self.lbl_detected_tala)
        
        self.lbl_bpm = QLabel("Estimated BPM: -")
        result_layout.addWidget(self.lbl_bpm)
        
        self.lbl_details = QLabel("")
        self.lbl_details.setWordWrap(True)
        self.lbl_details.setStyleSheet("color: gray; padding: 10px;")
        result_layout.addWidget(self.lbl_details)
        
        layout.addWidget(result_group)
        
        # Database Management Group
        db_group = QGroupBox("Tala Database")
        db_layout = QVBoxLayout(db_group)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Name", "Aksharas", "Structure", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        db_layout.addWidget(self.table)
        
        # Buttons
        btn_layout = QHBoxLayout()
        self.btn_add = QPushButton("Add New Tala")
        self.btn_edit = QPushButton("Edit Selected")
        self.btn_delete = QPushButton("Delete Selected")
        
        self.btn_add.clicked.connect(self.show_add_dialog)
        self.btn_edit.clicked.connect(self.show_edit_dialog)
        self.btn_delete.clicked.connect(self.delete_selected)
        
        btn_layout.addWidget(self.btn_add)
        btn_layout.addWidget(self.btn_edit)
        btn_layout.addWidget(self.btn_delete)
        db_layout.addLayout(btn_layout)
        
        layout.addWidget(db_group)
    
    def set_audio_data(self, audio: Optional[object], sr: Optional[int]):
        """Receive audio data and identify tala."""
        if audio is None or sr is None:
            return
        
        self.current_audio = audio
        self.current_sr = sr
        
        # Ensure mono
        if hasattr(audio, 'ndim') and audio.ndim > 1:
            audio = audio.mean(axis=0)
        
        results = self.identifier.identify_tala(audio, sr)
        
        if results:
            top_tala = results[0]
            self.lbl_detected_tala.setText(f"Detected: {top_tala['name']}")
            self.lbl_bpm.setText(f"Estimated Akshara BPM: {top_tala['bpm']}")
            self.lbl_details.setText(
                f"Aksharas: {top_tala['aksharas']}\n"
                f"Structure: {top_tala['structure']}\n"
                f"Note: {top_tala['description']}"
            )
            self.tala_identified.emit(top_tala['name'], top_tala['score'])

        else:
            # FALLBACK: Default to Adi tala at 120 BPM for vocal recordings
            print("\n=== TALA IDENTIFICATION DEBUG ===")
            print("No strong rhythmic pattern detected. Defaulting to Adi tala at 120 BPM.")
            print("=================================\n")
            
            self.lbl_detected_tala.setText("Detected: Adi (default)")
            self.lbl_bpm.setText("Estimated Akshara BPM: 120.0")
            self.lbl_details.setText(
                "Aksharas: 8\n"
                "Structure: 4+2+2\n"
                "Note: Vocal recording - defaulting to Adi tala. You can adjust this manually."
            )
            self.tala_identified.emit("Adi", 0.5)  # Emit with moderate confidence
    
    def refresh_table(self):
        """Refresh the tala database table."""
        talas = self.db.get_all("talas")
        self.table.setRowCount(len(talas))
        
        for row, tala in enumerate(talas):
            self.table.setItem(row, 0, QTableWidgetItem(tala.get("name", "")))
            self.table.setItem(row, 1, QTableWidgetItem(str(tala.get("aksharas", ""))))
            self.table.setItem(row, 2, QTableWidgetItem(tala.get("structure", "")))
            self.table.setItem(row, 3, QTableWidgetItem(tala.get("description", "")))
    
    def show_add_dialog(self):
        self._show_tala_dialog()
    
    def show_edit_dialog(self):
        selected = self.table.selectedItems()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select a tala to edit.")
            return
        
        row = selected[0].row()
        name = self.table.item(row, 0).text()
        
        talas = self.db.get_all("talas")
        tala_to_edit = next((t for t in talas if t["name"] == name), None)
        
        if tala_to_edit:
            self._show_tala_dialog(tala_to_edit)
    
    def _show_tala_dialog(self, existing_tala: dict = None):
        dialog = QDialogWithForm(self, existing_tala)
        if dialog.exec():
            data = dialog.get_data()
            try:
                if existing_tala:
                    self.db.update_entry("talas", existing_tala["name"], data)
                else:
                    self.db.add_entry("talas", data)
                self.refresh_table()
            except ValueError as e:
                QMessageBox.warning(self, "Error", str(e))
    
    def delete_selected(self):
        selected = self.table.selectedItems()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select a tala to delete.")
            return
        
        row = selected[0].row()
        name = self.table.item(row, 0).text()
        
        reply = QMessageBox.question(
            self, "Confirm Delete", 
            f"Are you sure you want to delete '{name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.db.delete_entry("talas", name)
            self.refresh_table()


class QDialogWithForm(QDialog):
    """Custom dialog for adding/editing talas."""
    def __init__(self, parent, existing_tala=None):
        super().__init__(parent)
        self.setWindowTitle("Add/Edit Tala" if existing_tala else "Add New Tala")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout(self)
        form = QFormLayout()
        
        self.name_input = QLineEdit(existing_tala["name"] if existing_tala else "")
        self.aksharas_input = QLineEdit(str(existing_tala["aksharas"]) if existing_tala else "")
        self.structure_input = QLineEdit(existing_tala["structure"] if existing_tala else "")
        self.desc_input = QTextEdit(existing_tala["description"] if existing_tala else "")
        self.desc_input.setMaximumHeight(60)
        
        form.addRow("Name (e.g., Adi):", self.name_input)
        form.addRow("Aksharas (e.g., 8):", self.aksharas_input)
        form.addRow("Structure (e.g., 4+2+2):", self.structure_input)
        form.addRow("Description:", self.desc_input)
        
        layout.addLayout(form)
        
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def get_data(self) -> dict:
        try:
            aksharas = int(self.aksharas_input.text().strip())
        except ValueError:
            aksharas = 8
            
        return {
            "name": self.name_input.text().strip(),
            "aksharas": aksharas,
            "structure": self.structure_input.text().strip(),
            "description": self.desc_input.toPlainText().strip()
        }