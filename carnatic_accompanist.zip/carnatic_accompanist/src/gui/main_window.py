#!/usr/bin/env python3
"""
Main window for Carnatic Accompanist GUI.
Includes:
1) stereo inputs downmixed to mono at load,
2) breath-gating of pitch confidences (worker + cache load),
3) sruti auto-correction via raga reference-rotation search,
4) raga (detected or overridden) selects the sruti-box secondary drone,
5) OFFLINE AI raga classifier (ResNet) in a background thread, with
   cached results and confidence-gated auto-apply,
6) all database paths anchored to the project root, allow_pickle caches.
"""
import sys
from pathlib import Path
import numpy as np

_project_root = Path(__file__).resolve().parent.parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton, QTabWidget,
    QStatusBar, QMenu, QMessageBox, QProgressBar
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QAction

from src.gui.audio_panel import AudioPanel
from src.gui.raga_panel import RagaPanel
from src.gui.tala_panel import TalaPanel
from src.gui.mixer_panel import MixerPanel
from src.gui.help_dialog import HelpDialog
from src.core.pitch_tracker import PitchTracker
from src.ai_models.bhargava_swara import BhargavaSwaraWrapper
from src.core.raga_identifier import RagaIdentifier, TOKENS
from src.utils.json_db import JSONDatabase

# AI results at/above this confidence auto-apply (drone note + override).
AI_AUTO_APPLY_THRESHOLD = 0.60


# ----------------------------------------------------------------------
def _to_mono(y: np.ndarray) -> np.ndarray:
    """Accept mono, (channels, time) or (time, channels); return 1-D mono."""
    y = np.asarray(y, dtype=np.float32)
    if y.ndim == 1:
        return y
    if y.shape[0] in (1, 2) and y.shape[1] > 2:   # (channels, time)
        return y.mean(axis=0).astype(np.float32)
    return y.mean(axis=1).astype(np.float32)      # (time, channels)


def _apply_breath_gate(audio, sr, times, confs):
    """Zero confidences where the vocal has energy but no harmonics (breaths)."""
    try:
        from src.core.breath_detector import breath_quality
        q = breath_quality(audio, sr, times)
        return confs * np.where(q > 0.3, 1.0, 0.0)
    except Exception as e:
        print("[breath] gate skipped:", e)
        return confs


def _estimate_reference_shift(ident, freqs, confs, threshold=0.4):
    """Reuse the identifier's rotation search to find the true Sa offset."""
    try:
        mask = confs >= threshold
        vf = freqs[mask]
        vf = vf[vf > 0]
        if len(vf) == 0:
            return 0

        semis = 12.0 * np.log2(vf / ident.sruti)
        best_s, best_key = 0, -1.0

        for s in range(12):
            raw = [TOKENS[int(np.round(x - s)) % 12] for x in semis]
            held = ident._hold_filter(ident._collapse_gamakas(raw), 12)
            if hasattr(ident, "_absorb_overshoot"):
                held = ident._absorb_overshoot(held)
            stream = ident._compress_swara_stream(held, 10)
            if not stream:
                continue

            counts = {}
            for t in held:
                if t != "-":
                    counts[t] = counts.get(t, 0) + 1
            total = sum(counts.values()) or 1

            top = 0.0
            for r in ident.db.get_all("ragas"):
                if hasattr(ident, "_score_raga_v6"):
                    sc = ident._score_raga_v6(r, stream, set(stream), counts, total, 0.5)
                elif hasattr(ident, "_score_raga_v5"):
                    sc = ident._score_raga_v5(r, stream, set(stream), counts, total, 0.5)
                else:
                    sc = 0.0
                top = max(top, sc)

            key = top + (0.03 if s == 0 else 0.0)
            if "S" not in set(stream):      # no tonic = rotation artifact
                key -= 0.5
            if key > best_key:
                best_key, best_s = key, s

        return best_s
    except Exception as e:
        print("[sruti] shift estimation skipped:", e)
        return 0


class AnalysisWorker(QThread):
    pitch_tracked = pyqtSignal(object, object, object)
    sruti_detected = pyqtSignal(float)
    finished = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, audio, sr):
        super().__init__()
        self.audio = audio
        self.sr = sr

    def run(self):
        try:
            tracker = PitchTracker(backend='crepe', crepe_model_size='full')
            times, freqs, confs = tracker.track(self.audio, self.sr)

            # silence the tracker during breaths (energy without harmonics)
            confs = _apply_breath_gate(self.audio, self.sr, times, confs)

            bhargava = BhargavaSwaraWrapper()
            sruti = bhargava.get_dominant_sruti(freqs, confs)
            if not sruti:
                sruti = 261.63

            self.sruti_detected.emit(sruti)
            self.pitch_tracked.emit(freqs, confs, times)
            self.finished.emit()
        except Exception as e:
            self.error.emit(str(e))


class AIWorker(QThread):
    """Runs the offline ResNet raga classifier without freezing the GUI."""
    ai_raga_ready = pyqtSignal(list)

    def __init__(self, audio, sr):
        super().__init__()
        self.audio = audio
        self.sr = sr

    def run(self):
        try:
            from src.ai_models.raga_classifier import AIRagaClassifier
            res = AIRagaClassifier().identify(self.audio, self.sr, top_k=5)
            if res:
                self.ai_raga_ready.emit(res)
        except Exception as e:
            print("[AI Raga] worker skipped:", e)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Carnatic Vocal Accompanist")
        self.setMinimumSize(1200, 800)

        self.current_audio = None
        self.current_sr = None
        self.current_file = None

        self.detected_sruti = 261.63
        self.detected_bpm = 120.0
        self.detected_aksharas = 8

        self.current_freqs = None
        self.current_confs = None
        self.current_times = None
        self.ai_results = None

        self.raga_panel = RagaPanel()
        self.tala_panel = TalaPanel()
        self.mixer_panel = MixerPanel()
        self.mixer_panel.tala_score = 1.0
        self.mixer_panel.sruti_secondary = "P"

        self.analysis_worker = None
        self.ai_worker = None

        self.init_ui()
        self.create_menu_bar()
        self.create_status_bar()
        self.connect_signals()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        title_label = QLabel("Carnatic Vocal Accompanist")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; padding: 20px;")
        main_layout.addWidget(title_label)

        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)

        self.audio_panel = AudioPanel()
        self.tab_widget.addTab(self.audio_panel, "Load Audio")
        self.tab_widget.addTab(self.raga_panel, "Raga")
        self.tab_widget.addTab(self.tala_panel, "Tala")
        self.tab_widget.addTab(self.mixer_panel, "Mix & Export")

        button_layout = QHBoxLayout()

        self.btn_load = QPushButton("Load Vocal")
        self.btn_load.setStyleSheet("padding: 10px; font-size: 14px; font-weight: bold;")
        self.btn_load.clicked.connect(self.on_load_clicked)

        self.btn_help = QPushButton("📖 Help & Mixing Guide")
        self.btn_help.setStyleSheet(
            "padding: 10px; font-size: 14px; font-weight: bold; "
            "background-color: #2c3e50; color: white; border-radius: 4px;"
        )
        self.btn_help.clicked.connect(self.show_help)

        self.btn_analyze = QPushButton("🔍 Auto-Analyze Mix Settings")
        self.btn_analyze.setStyleSheet(
            "padding: 10px; font-size: 14px; font-weight: bold; "
            "background-color: #f39c12; color: white; border-radius: 4px;"
        )
        self.btn_analyze.clicked.connect(self.run_mix_analysis)

        button_layout.addWidget(self.btn_load)
        button_layout.addWidget(self.btn_help)
        button_layout.addWidget(self.btn_analyze)
        button_layout.addStretch()
        main_layout.addLayout(button_layout)

        self.status_label = QLabel("Ready")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(self.status_label)

        self.analysis_progress = QProgressBar()
        self.analysis_progress.setRange(0, 0)
        self.analysis_progress.setVisible(False)
        self.analysis_progress.setTextVisible(False)
        main_layout.addWidget(self.analysis_progress)

    def connect_signals(self):
        self.audio_panel.audio_loaded.connect(self.on_audio_loaded_for_analysis)
        self.tala_panel.tala_identified.connect(self.on_tala_identified)
        self.raga_panel.raga_identified.connect(self.on_raga_identified)

    # ------------------------------------------------------------------
    def on_tala_identified(self, tala_name: str, score: float):
        tala_map = {"Adi": 8, "Rupaka": 6, "Misra Chapu": 7, "Khanda Chapu": 5, "Khanda Ata": 14}
        self.detected_aksharas = tala_map.get(tala_name, 8)
        self.mixer_panel.tala_score = float(score)

        if self.current_audio is not None:
            self.mixer_panel.set_analysis_data(
                self.current_audio, self.current_sr, self.detected_sruti,
                self.detected_bpm, self.detected_aksharas,
                frequencies=self.current_freqs, confidences=self.current_confs
            )

    # ------------------------------------------------------------------
    # raga (detected or overridden) -> sruti-box secondary drone note
    # ------------------------------------------------------------------
    def on_raga_identified(self, raga_name: str, score: float):
        try:
            db = JSONDatabase(str(_project_root / "config" / "databases" / "ragas.json"),
                              default_data={"ragas": []})
            entry = next((r for r in db.get_all("ragas") if r.get("name") == raga_name), None)
            if entry:
                scale = set(str(entry.get("arohana", "")).split()) | \
                        set(str(entry.get("avarohana", "")).split())
                if "P" in scale:
                    secondary = "P"
                elif ("M1" in scale) or ("M2" in scale):
                    secondary = "M1"
                else:
                    secondary = "N3"
                self.mixer_panel.sruti_secondary = secondary
                print(f"[raga] {raga_name} (score {score:.0%}) -> sruti secondary drone: {secondary}")
        except Exception as e:
            print("[raga] secondary-note wiring skipped:", e)

    # ------------------------------------------------------------------
    def on_audio_loaded_for_analysis(self, file_path, audio, sr):
        audio = _to_mono(audio)
        self.current_file = file_path
        self.current_audio = audio
        self.current_sr = sr

        # --- CHECK FOR CACHED ANALYSIS ---
        cache_file = Path(file_path).with_suffix('.npz')
        if cache_file.exists():
            file_name = Path(file_path).name
            self.statusBar().showMessage(f"Loading cached analysis for: {file_name}...")
            self.status_label.setText(f"Loading Cache: {file_name}")
            QApplication.processEvents()
            try:
                data = np.load(cache_file, allow_pickle=True)
                self.detected_sruti = float(data['sruti'])
                self.detected_bpm = float(data['bpm'])
                self.detected_aksharas = int(data['aksharas'])
                self.current_freqs = data['freqs']
                self.current_confs = data['confs']
                self.current_times = data['times']

                # breath-gate old caches too (no re-analysis needed)
                self.current_confs = _apply_breath_gate(
                    self.current_audio, self.current_sr, self.current_times, self.current_confs
                )

                # cached AI result?
                if 'ai_raga' in data:
                    ai_res = data['ai_raga'].tolist() if hasattr(data['ai_raga'], 'tolist') else list(data['ai_raga'])
                    cleaned = []
                    for item in ai_res:
                        if isinstance(item, dict):
                            cleaned.append({"name": str(item.get("name", "")),
                                            "score": float(item.get("score", 0.0))})
                    if cleaned:
                        self._handle_ai_results(cleaned, save_cache=False)
                else:
                    self._start_ai_worker()

                self.raga_panel.set_audio_data(self.current_freqs, self.current_confs, self.detected_sruti)
                self.mixer_panel.set_analysis_data(
                    self.current_audio, self.current_sr, self.detected_sruti,
                    self.detected_bpm, self.detected_aksharas,
                    frequencies=self.current_freqs, confidences=self.current_confs,
                    pitch_times=self.current_times
                )
                self.statusBar().showMessage(f"Loaded cached analysis for: {file_name}")
                self.status_label.setText(f"Analyzed (Cached): {file_name}")
                return
            except Exception as e:
                print(f"Failed to load cache. Re-analyzing. Error: {e}")

        # --- FALLBACK: RUN NEURAL NETWORK IF NO CACHE EXISTS ---
        self.statusBar().showMessage(f"Loaded: {file_path}. Analyzing rhythm and pitch...")
        QApplication.processEvents()

        self.tala_panel.set_audio_data(audio, sr)
        self.detected_sruti = 261.63
        self.mixer_panel.set_analysis_data(
            audio, sr, self.detected_sruti, self.detected_bpm, self.detected_aksharas
        )

        self.analysis_progress.setVisible(True)
        self.status_label.setText(f"Loaded: {file_path} - Neural Network Analysis in Progress...")

        self.analysis_worker = AnalysisWorker(audio, sr)
        self.analysis_worker.sruti_detected.connect(self.on_sruti_detected)
        self.analysis_worker.pitch_tracked.connect(self.on_pitch_tracked)
        self.analysis_worker.finished.connect(self.on_analysis_finished)
        self.analysis_worker.error.connect(self.on_analysis_error)
        self.analysis_worker.start()

        self._start_ai_worker()

    # ------------------------------------------------------------------
    def _start_ai_worker(self):
        if self.current_audio is None:
            return
        self.ai_worker = AIWorker(self.current_audio, self.current_sr)
        self.ai_worker.ai_raga_ready.connect(self.on_ai_raga_ready)
        self.ai_worker.start()

    def on_ai_raga_ready(self, results):
        self._handle_ai_results(results, save_cache=True)

    def _handle_ai_results(self, results, save_cache=True):
        self.ai_results = results

        # Show in the Raga tab if the panel supports it.
        if hasattr(self.raga_panel, "set_ai_results"):
            self.raga_panel.set_ai_results(results)

        # Auto-apply only when confident and present in the local DB.
        if results and results[0]["score"] >= AI_AUTO_APPLY_THRESHOLD:
            top_name = results[0]["name"].strip()
            try:
                db = JSONDatabase(str(_project_root / "config" / "databases" / "ragas.json"),
                                  default_data={"ragas": []})
                entry = next((r for r in db.get_all("ragas")
                              if str(r.get("name", "")).strip().lower() == top_name.lower()), None)
                if entry:
                    print(f"[AI Raga] auto-apply: {entry['name']} ({results[0]['score']:.0%})")
                    self.raga_panel.raga_identified.emit(entry["name"], results[0]["score"])
                else:
                    print(f"[AI Raga] top pick '{top_name}' not in local DB; display only.")
            except Exception as e:
                print("[AI Raga] auto-apply skipped:", e)

        # Persist into the .npz cache.
        if save_cache and self.current_file:
            cache_file = Path(self.current_file).with_suffix('.npz')
            try:
                existing = dict(np.load(cache_file, allow_pickle=True))
                existing['ai_raga'] = np.array(results, dtype=object)
                np.savez_compressed(cache_file, **existing)
            except Exception as e:
                print(f"[AI Raga] cache save skipped: {e}")

    # ------------------------------------------------------------------
    def on_sruti_detected(self, sruti_freq):
        self.detected_sruti = sruti_freq
        self.mixer_panel.set_analysis_data(
            self.current_audio, self.current_sr, self.detected_sruti,
            self.detected_bpm, self.detected_aksharas,
            frequencies=self.current_freqs, confidences=self.current_confs
        )

    def on_pitch_tracked(self, freqs, confs, times):
        self.current_freqs = freqs
        self.current_confs = confs
        self.current_times = times

        # sruti auto-correction via raga reference-rotation
        try:
            ident = RagaIdentifier(str(_project_root / "config" / "databases" / "ragas.json"))
            ident.set_sruti(self.detected_sruti)
            shift = _estimate_reference_shift(ident, freqs, confs)
            if shift:
                self.detected_sruti = self.detected_sruti * (2.0 ** (shift / 12.0))
                print(f"[sruti] auto-corrected by {shift} semitone(s) -> {self.detected_sruti:.2f} Hz")
        except Exception as e:
            print("[sruti] auto-correction skipped:", e)

        self.raga_panel.set_audio_data(freqs, confs, self.detected_sruti)
        self.mixer_panel.set_analysis_data(
            self.current_audio, self.current_sr, self.detected_sruti,
            self.detected_bpm, self.detected_aksharas,
            frequencies=freqs, confidences=confs, pitch_times=times
        )

        # save analysis cache for instant recall
        if self.current_file:
            cache_file = Path(self.current_file).with_suffix('.npz')
            try:
                np.savez_compressed(
                    cache_file,
                    sruti=self.detected_sruti,
                    bpm=self.detected_bpm,
                    aksharas=self.detected_aksharas,
                    freqs=self.current_freqs,
                    confs=self.current_confs,
                    times=self.current_times
                )
            except Exception as e:
                print(f"Could not save cache: {e}")

    def on_analysis_finished(self):
        self.analysis_progress.setVisible(False)
        self.statusBar().showMessage(f"Analysis complete for: {self.current_file}")
        self.status_label.setText(f"Analyzed: {self.current_file}")

    def on_analysis_error(self, error_msg):
        self.analysis_progress.setVisible(False)
        self.statusBar().showMessage(f"Analysis error: {error_msg}")
        self.status_label.setText("Analysis Failed.")
        QMessageBox.warning(self, "Analysis Error", f"Pitch tracking failed:\n{error_msg}")

    # ------------------------------------------------------------------
    def on_load_clicked(self):
        self.tab_widget.setCurrentWidget(self.audio_panel)
        self.audio_panel.browse_file()

    def run_mix_analysis(self):
        if self.current_audio is None:
            QMessageBox.warning(self, "No Audio", "Please load an audio file first so the analyzer can check the tempo.")
            return

        file_name = Path(self.current_file).name if self.current_file else "Unknown Audio"
        suggestions = []

        try:
            vocal_vol = self.mixer_panel.vocal_vol_slider.value()
            veena_vol = self.mixer_panel.veena_vol.value()
            mrid_vol = self.mixer_panel.mrid_vol.value()
            sruti_vol = self.mixer_panel.sruti_vol.value()

            veena_sustain = getattr(self.mixer_panel, 'veena_sustain_slider', None)
            veena_sustain_val = veena_sustain.value() / 10.0 if veena_sustain else 7.5
            veena_attack = self.mixer_panel.veena_attack_slider.value()

            harm_vol = self.mixer_panel.harm_vol.value()
            harm_timbre = self.mixer_panel.timbre_slider.value()
            harm_swara = self.mixer_panel.ornament_slider.value()

            clar_vol_slider = getattr(self.mixer_panel, 'clar_vol', None)
            clar_vol = clar_vol_slider.value() if clar_vol_slider else 0
            clar_wood_slider = getattr(self.mixer_panel, 'clar_wood_slider', None)
            clar_wood = clar_wood_slider.value() if clar_wood_slider else 60

            if veena_vol > vocal_vol * 0.85:
                suggestions.append("• [Veena Volume] The Veena is set very high relative to the vocals. Consider lowering it to prevent masking the singer.")
            if harm_vol > vocal_vol * 0.85:
                suggestions.append("• [Harmonium Volume] The Harmonium is set very high relative to the vocals. Lower it so the singer remains the focus.")
            if clar_vol > vocal_vol * 0.85:
                suggestions.append("• [Clarinet Volume] The Clarinet is set very high relative to the vocals. Lower it so the singer remains the focus.")

            if harm_timbre > 85:
                suggestions.append(f"• [Harmonium Timbre] Timbre is bright ({harm_timbre}%). This creates a piercing tone that might clash with the vocalist. The traditional sweet spot is 40-60%.")
            if self.detected_sruti > 350 and self.mixer_panel.harm_octave_combo.currentIndex() == 0:
                suggestions.append(f"• [Harmonium Octave] The detected Sruti is quite high ({self.detected_sruti:.0f} Hz). If the Harmonium sounds thin or squeaky, try an Octave Shift of -1.")
            if clar_wood < 30 and clar_vol > 50:
                suggestions.append("• [Clarinet Timbre] Woodiness is very low (bright/reedy). This may clash with the vocal's upper frequencies. Consider raising it to 50%+ for a warmer tone.")

            if self.detected_bpm > 100 and veena_sustain_val > 6.0:
                suggestions.append(f"• [Veena Sustain] Tempo is fast ({self.detected_bpm:.0f} BPM), but Sustain is high ({veena_sustain_val}). Lower sustain to ~4.0 to prevent muddy overlap on fast syllables.")
            elif self.detected_bpm < 70 and veena_sustain_val < 4.0:
                suggestions.append(f"• [Veena Sustain] Tempo is slow ({self.detected_bpm:.0f} BPM). Consider increasing Sustain (5.5+) to allow strings to ring beautifully during long vowels.")
            if self.detected_bpm > 100 and harm_swara < 50:
                suggestions.append(f"• [Harmonium Swara Lock] Tempo is fast ({self.detected_bpm:.0f} BPM), but Swara Lock is loose ({harm_swara}%). Increase to 70%+ so it plays strict keys instead of sliding out of rhythm.")
            elif self.detected_bpm < 70 and harm_swara > 80:
                suggestions.append(f"• [Harmonium Swara Lock] Tempo is slow ({self.detected_bpm:.0f} BPM), but Swara Lock is strict ({harm_swara}%). Lower to 40-60% to let the Harmonium smoothly follow the vocalist's gamakas.")

            total_vol = (vocal_vol + veena_vol + mrid_vol + sruti_vol + harm_vol + clar_vol) / 100.0
            if total_vol > 2.8:
                suggestions.append("• [Master Mix] The combined volume of all instruments is dangerously high. You risk digital clipping (distortion). Lower all sliders by 10-15%.")

            if veena_attack > 20:
                suggestions.append("• [Veena Attack] Meetu sharpness is very soft (>0.02s). For distinct, traditional plucks, keep this between 1 and 10 (0.001s - 0.010s).")

            header = f"📊 Diagnostics for: {file_name}\n"
            header += f"Tempo: {self.detected_bpm:.0f} BPM | Detected Sruti: {self.detected_sruti:.1f} Hz\n"
            header += "-" * 40 + "\n"

            if not suggestions:
                msg = header + "✅ Perfect Mix!\nAll sliders appear optimally balanced for the current tempo, pitch, and vocal track."
            else:
                msg = header + "⚠️ Suggested Slider Adjustments:\n" + "\n".join(suggestions)

            QMessageBox.information(self, "Pre-Mix Diagnostics", msg)

        except AttributeError as e:
            QMessageBox.warning(self, "Analyzer Error", f"Could not read all mixer values. Ensure the Mixer Panel is fully updated.\n{e}")

    # ------------------------------------------------------------------
    def create_menu_bar(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu("File")
        load_action = QAction("Load Audio", self)
        load_action.setShortcut("Ctrl+O")
        load_action.triggered.connect(self.on_load_clicked)
        file_menu.addAction(load_action)
        file_menu.addSeparator()
        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        edit_menu = menubar.addMenu("Edit")
        edit_menu.addAction("Manage Raga Database")
        edit_menu.addAction("Manage Tala Database")

        help_menu = menubar.addMenu("Help")
        user_guide_action = QAction("User Guide", self)
        user_guide_action.setShortcut("F1")
        user_guide_action.triggered.connect(self.show_help)
        help_menu.addAction(user_guide_action)
        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def create_status_bar(self):
        self.statusBar().showMessage("Ready")

    def show_help(self):
        try:
            help_dialog = HelpDialog(self)
            help_dialog.exec()
        except Exception as e:
            QMessageBox.warning(self, "Help Error", f"Could not open Help: {str(e)}")

    def show_about(self):
        QMessageBox.about(
            self,
            "About Carnatic Accompanist",
            "Carnatic Vocal Accompanist\n"
            "AI-powered accompaniment for Carnatic vocal music.\n"
            "Version: 1.1.0 (Offline AI Raga Integration)\n"
            "Optimized for Asus Zenbook Duo 2024"
        )


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()