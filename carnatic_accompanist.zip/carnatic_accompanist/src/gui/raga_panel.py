#!/usr/bin/env python3
"""
Raga identification and database management panel.
- Rule-based identification (raga_identifier v6) + top-3 display.
- Manual override control (force any DB raga).
- AI Model (offline ResNet) results box with Accept button
  (set_ai_results is called by main_window's AI worker).
- Anchored DB path; defensive dict access (no KeyError on missing keys).
"""
from pathlib import Path
from typing import Optional
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox,
    QFormLayout, QLineEdit, QTextEdit, QMessageBox, QDialog,
    QDialogButtonBox, QComboBox
)
from PyQt6.QtCore import pyqtSignal

from src.core.raga_identifier import RagaIdentifier
from src.utils.json_db import JSONDatabase


class RagaPanel(QWidget):
    """Panel for raga identification and database management."""
    raga_identified = pyqtSignal(str, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        _project_root = Path(__file__).resolve().parent.parent.parent
        self.db_path = _project_root / "config" / "databases" / "ragas.json"
        self.db = JSONDatabase(str(self.db_path), default_data={"ragas": []})
        self.identifier = RagaIdentifier(str(self.db_path))
        self.current_frequencies = None
        self.current_confidences = None
        self.ai_results_cache = None
        self.init_ui()
        self.refresh_table()

    # ------------------------------------------------------------------
    def init_ui(self):
        layout = QVBoxLayout(self)

        # --- Rule-based results ---
        result_group = QGroupBox("Identified Raga (rule-based)")
        result_layout = QVBoxLayout(result_group)
        self.lbl_detected_raga = QLabel("No audio analyzed yet")
        self.lbl_detected_raga.setStyleSheet("font-size: 18px; font-weight: bold; color: blue;")
        result_layout.addWidget(self.lbl_detected_raga)
        self.lbl_confidence = QLabel("Confidence: -")
        result_layout.addWidget(self.lbl_confidence)
        self.lbl_details = QLabel("")
        self.lbl_details.setWordWrap(True)
        self.lbl_details.setStyleSheet("color: gray; padding: 10px;")
        result_layout.addWidget(self.lbl_details)

        override_layout = QHBoxLayout()
        override_layout.addWidget(QLabel("Manual override:"))
        self.override_combo = QComboBox()
        self.btn_override = QPushButton("Use Selected Raga (Override)")
        self.btn_override.clicked.connect(self.apply_override)
        override_layout.addWidget(self.override_combo, 1)
        override_layout.addWidget(self.btn_override)
        result_layout.addLayout(override_layout)
        layout.addWidget(result_group)

        # --- NEW: AI model results ---
        ai_group = QGroupBox("AI Model (ResNet Offline)")
        ai_layout = QVBoxLayout(ai_group)
        self.lbl_ai_raga = QLabel("Awaiting AI analysis...")
        self.lbl_ai_raga.setStyleSheet("font-size: 16px; font-weight: bold; color: darkgreen;")
        ai_layout.addWidget(self.lbl_ai_raga)
        self.lbl_ai_conf = QLabel("AI Confidence: -")
        ai_layout.addWidget(self.lbl_ai_conf)
        self.lbl_ai_details = QLabel("")
        self.lbl_ai_details.setWordWrap(True)
        self.lbl_ai_details.setStyleSheet("color: gray;")
        ai_layout.addWidget(self.lbl_ai_details)
        self.btn_accept_ai = QPushButton("Accept AI Prediction (Override)")
        self.btn_accept_ai.clicked.connect(self.accept_ai_prediction)
        self.btn_accept_ai.setEnabled(False)
        ai_layout.addWidget(self.btn_accept_ai)
        layout.addWidget(ai_group)

        # --- Database management ---
        db_group = QGroupBox("Raga Database")
        db_layout = QVBoxLayout(db_group)
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Name", "Arohana", "Avarohana", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        db_layout.addWidget(self.table)

        btn_layout = QHBoxLayout()
        self.btn_add = QPushButton("Add New Raga")
        self.btn_edit = QPushButton("Edit Selected")
        self.btn_delete = QPushButton("Delete Selected")
        self.btn_add.clicked.connect(self.show_add_dialog)
        self.btn_edit.clicked.connect(self.show_edit_dialog)
        self.btn_delete.clicked.connect(self.delete_selected)
        btn_layout.addWidget(self.btn_add)
        btn_layout.addWidget(self.btn_edit)
        btn_layout.addWidget(self.btn_delete)
        db_layout.addLayout(btn_layout)
        layout.addWidget(db_group)

    # ------------------------------------------------------------------
    def set_audio_data(self, frequencies, confidences, sruti_freq: Optional[float] = None):
        if frequencies is None or confidences is None:
            self.lbl_detected_raga.setText("Awaiting pitch analysis...")
            return
        self.current_frequencies = frequencies
        self.current_confidences = confidences
        if sruti_freq:
            self.identifier.set_sruti(sruti_freq)

        results = self.identifier.identify_raga(frequencies, confidences)
        if results:
            top_raga = results[0]
            self.lbl_detected_raga.setText(f"Detected: {top_raga['name']}")
            self.lbl_confidence.setText(f"Confidence: {top_raga['score']:.1%}")
            self.lbl_details.setText("\n".join(
                f"{i + 1}. {r['name']} — {r['score']:.0%}  ({r['arohana']} / {r['avarohana']})"
                for i, r in enumerate(results[:3])
            ))
            self.raga_identified.emit(top_raga['name'], top_raga['score'])
        else:
            self.lbl_detected_raga.setText("Could not identify raga")
            self.lbl_confidence.setText("Confidence: 0%")
            self.lbl_details.setText("Try adjusting the Sruti or ensuring the vocal is clear.")

    # ------------------------------------------------------------------
    # NEW: AI results (called by main_window's AI worker / cache load)
    # ------------------------------------------------------------------
    def set_ai_results(self, results):
        self.ai_results_cache = results
        if not results:
            self.lbl_ai_raga.setText("AI Model: No result / Offline")
            self.lbl_ai_conf.setText("AI Confidence: -")
            self.lbl_ai_details.setText("")
            self.btn_accept_ai.setEnabled(False)
            return

        top = results[0]
        self.lbl_ai_raga.setText(f"AI Detected: {top['name']}")
        self.lbl_ai_conf.setText(f"AI Confidence: {top['score']:.1%}")
        self.lbl_ai_details.setText("\n".join(
            f"{i + 1}. {r['name']} — {r['score']:.0%}"
            for i, r in enumerate(results[:5])
        ))
        self.btn_accept_ai.setEnabled(True)

    def accept_ai_prediction(self):
        """Force the AI's top prediction and notify the rest of the app."""
        if not self.ai_results_cache:
            return
        top = self.ai_results_cache[0]
        name = self._match_db_name(top["name"]) or top["name"]

        self.lbl_detected_raga.setText(f"Detected: {name} (via AI)")
        self.lbl_confidence.setText(f"Confidence: {top['score']:.1%} (AI)")
        entry = self._get_entry(name)
        if entry:
            self.lbl_details.setText(
                f"Arohana: {entry.get('arohana', '')}\n"
                f"Avarohana: {entry.get('avarohana', '')}"
            )
        self.raga_identified.emit(name, float(top["score"]))

    # ------------------------------------------------------------------
    def apply_override(self):
        """Force the selected raga and notify the rest of the app."""
        name = self.override_combo.currentText()
        if not name:
            return
        entry = self._get_entry(name)
        if entry is None:
            return
        self.lbl_detected_raga.setText(f"Detected: {name} (manual override)")
        self.lbl_confidence.setText("Confidence: 100% (override)")
        self.lbl_details.setText(
            f"Arohana: {entry.get('arohana', '')}\n"
            f"Avarohana: {entry.get('avarohana', '')}\n"
            f"Note: {entry.get('description', '')}"
        )
        self.raga_identified.emit(name, 1.0)

    # ------------------------------------------------------------------
    def refresh_table(self):
        ragas = self.db.get_all("ragas")
        self.table.setRowCount(len(ragas))
        for row, raga in enumerate(ragas):
            self.table.setItem(row, 0, QTableWidgetItem(str(raga.get("name", ""))))
            self.table.setItem(row, 1, QTableWidgetItem(str(raga.get("arohana", ""))))
            self.table.setItem(row, 2, QTableWidgetItem(str(raga.get("avarohana", ""))))
            self.table.setItem(row, 3, QTableWidgetItem(str(raga.get("description", ""))))
        self.override_combo.clear()
        for raga in ragas:
            self.override_combo.addItem(str(raga.get("name", "")))

    # ------------------------------------------------------------------
    def show_add_dialog(self):
        self._show_raga_dialog()

    def show_edit_dialog(self):
        selected = self.table.selectedItems()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select a raga to edit.")
            return
        row = selected[0].row()
        name = self.table.item(row, 0).text()
        raga_to_edit = self._get_entry(name)
        if raga_to_edit:
            self._show_raga_dialog(raga_to_edit)

    def _show_raga_dialog(self, existing_raga: dict = None):
        dialog = QDialogWithForm(self, existing_raga)
        if dialog.exec():
            data = dialog.get_data()
            try:
                if existing_raga:
                    self.db.update_entry("ragas", existing_raga["name"], data)
                    QMessageBox.information(self, "Success", f"Raga '{data['name']}' updated and saved to database.")
                else:
                    self.db.add_entry("ragas", data)
                    QMessageBox.information(self, "Success", f"Raga '{data['name']}' added and saved to database.")
                self.refresh_table()
            except ValueError as e:
                QMessageBox.warning(self, "Error", str(e))

    def delete_selected(self):
        selected = self.table.selectedItems()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select a raga to delete.")
            return
        row = selected[0].row()
        name = self.table.item(row, 0).text()
        reply = QMessageBox.question(
            self,
            "Confirm Delete",
            f"Are you sure you want to delete '{name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.db.delete_entry("ragas", name)
            self.refresh_table()
            QMessageBox.information(self, "Success", f"Raga '{name}' deleted from database.")

    # ------------------------------------------------------------------
    def _get_entry(self, name: str):
        ragas = self.db.get_all("ragas")
        return next((r for r in ragas if str(r.get("name", "")).strip() == str(name).strip()), None)

    def _match_db_name(self, ai_name: str):
        """Case-insensitive match of an AI label against the DB names."""
        ragas = self.db.get_all("ragas")
        low = str(ai_name).strip().lower()
        for r in ragas:
            if str(r.get("name", "")).strip().lower() == low:
                return str(r.get("name"))
        return None


class QDialogWithForm(QDialog):
    def __init__(self, parent=None, existing_raga=None):
        super().__init__(parent)
        self.setWindowTitle("Add/Edit Raga" if existing_raga else "Add New Raga")
        self.setMinimumWidth(400)
        layout = QVBoxLayout(self)
        form = QFormLayout()

        er = existing_raga or {}
        self.name_input = QLineEdit(str(er.get("name", "")))
        self.arohana_input = QLineEdit(str(er.get("arohana", "")))
        self.avarohana_input = QLineEdit(str(er.get("avarohana", "")))
        self.desc_input = QTextEdit(str(er.get("description", "")))
        self.desc_input.setMaximumHeight(60)

        form.addRow("Name (e.g., Mayamalavagowla):", self.name_input)
        form.addRow("Arohana (e.g., S R1 G3 M1 P D1 N3 S):", self.arohana_input)
        form.addRow("Avarohana (e.g., S N3 D1 P M1 G3 R1 S):", self.avarohana_input)
        form.addRow("Description:", self.desc_input)
        layout.addLayout(form)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_data(self) -> dict:
        return {
            "name": self.name_input.text().strip(),
            "arohana": self.arohana_input.text().strip().upper(),
            "avarohana": self.avarohana_input.text().strip().upper(),
            "description": self.desc_input.toPlainText().strip()
        }