#!/usr/bin/env python3
"""
Help and Mixing Guide dialog for Carnatic Accompanist.
"""

from PyQt6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QTextBrowser,
    QPushButton
)


class HelpDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Help & Mixing Guide")
        self.resize(1050, 800)

        layout = QVBoxLayout(self)

        browser = QTextBrowser(self)
        browser.setOpenExternalLinks(False)
        browser.setHtml(self._build_help_html())

        layout.addWidget(browser)

        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        layout.addWidget(close_button)

    def _build_help_html(self) -> str:
        return """
        <html>
        <head>
        <style>
            body {
                font-family: Arial, Helvetica, sans-serif;
                font-size: 14px;
                line-height: 1.45;
            }
            h1 {
                color: #1f3a5f;
                font-size: 22px;
            }
            h2 {
                color: #2c5f8a;
                font-size: 18px;
                margin-top: 24px;
                border-bottom: 1px solid #dddddd;
                padding-bottom: 4px;
            }
            h3 {
                color: #34495e;
                font-size: 15px;
                margin-top: 16px;
            }
            table {
                border-collapse: collapse;
                width: 100%;
                margin-top: 8px;
                margin-bottom: 16px;
            }
            th, td {
                border: 1px solid #bbbbbb;
                padding: 6px 8px;
                vertical-align: top;
            }
            th {
                background-color: #eef4fa;
                text-align: left;
            }
            .note {
                background-color: #fff8e5;
                border-left: 4px solid #f39c12;
                padding: 8px;
                margin: 10px 0;
            }
            .good {
                color: #1e7e34;
                font-weight: bold;
            }
            .warning {
                color: #b02a1e;
                font-weight: bold;
            }
            .section-nav {
                background-color: #f5f8fb;
                border: 1px solid #d7e2ee;
                padding: 10px;
                margin-bottom: 18px;
            }
            code {
                background-color: #f2f2f2;
                padding: 2px 4px;
                border-radius: 3px;
            }
        </style>
        </head>

        <body>

        <h1>Carnatic Vocal Accompanist — Help &amp; Mixing Guide</h1>

        <div class="section-nav">
            <strong>Quick Navigation:</strong><br><br>
            <a href="#workflow">1. Basic Workflow</a><br>
            <a href="#general">2. General Mixing Rules</a><br>
            <a href="#vocal">3. Vocal Settings</a><br>
            <a href="#sruti">4. Sruti Box Settings</a><br>
            <a href="#harmonium">5. Harmonium Settings</a><br>
            <a href="#veena">6. Veena Settings</a><br>
            <a href="#clarinet">7. Clarinet Settings</a><br>
            <a href="#articulation">8. Clarinet Articulation Guide</a><br>
            <a href="#mridangam">9. Mridangam Settings</a><br>
            <a href="#presets">10. Recommended Presets</a><br>
            <a href="#troubleshooting">11. Troubleshooting</a><br>
        </div>

        <h2 id="workflow">1. Basic Workflow</h2>
        <ol>
            <li>Load the vocal audio file from the <strong>Load Audio</strong> tab.</li>
            <li>Allow the system to detect pitch, sruti, raga, and tala.</li>
            <li>Go to the <strong>Mix &amp; Export</strong> tab.</li>
            <li>Adjust instrument volumes and expression settings.</li>
            <li>Use <strong>Auto-Analyze Mix Settings</strong> to check for common issues.</li>
            <li>Click <strong>Generate Mix &amp; Export to File</strong> to render the final mix.</li>
        </ol>

        <div class="note">
            Tip: The vocalist should always remain the main focus. Accompaniment instruments
            should support the voice, not compete with it.
        </div>

        <h2 id="general">2. General Mixing Rules</h2>
        <ul>
            <li>Vocal should usually be the loudest element.</li>
            <li>Sruti box should be subtle and stable.</li>
            <li>Melodic instruments such as Harmonium, Veena, and Clarinet should sit slightly behind the vocal.</li>
            <li>Mridangam should be clear but not aggressive unless the song requires rhythmic emphasis.</li>
            <li>Avoid setting all instrument volumes above 70 at the same time.</li>
            <li>If the mix sounds crowded, reduce one or two melodic instruments rather than reducing the vocal.</li>
        </ul>

        <h2 id="vocal">3. Vocal Settings</h2>
        <table>
            <tr>
                <th>Parameter</th>
                <th>Recommended Value</th>
                <th>Notes</th>
            </tr>
            <tr>
                <td>Vocal Volume</td>
                <td>80 to 140</td>
                <td>Default is 100. Increase only if the original recording is too quiet.</td>
            </tr>
        </table>

        <h2 id="sruti">4. Sruti Box Settings</h2>
        <table>
            <tr>
                <th>Parameter</th>
                <th>Recommended Value</th>
                <th>Notes</th>
            </tr>
            <tr>
                <td>Volume</td>
                <td>45 to 65</td>
                <td>The sruti should be felt more than heard.</td>
            </tr>
            <tr>
                <td>Pitch Shift</td>
                <td>0 cents</td>
                <td>Change only if the detected sruti needs manual correction.</td>
            </tr>
            <tr>
                <td>Tempo</td>
                <td>1.0</td>
                <td>Sruti box usually does not need tempo change.</td>
            </tr>
            <tr>
                <td>Offset</td>
                <td>0 ms</td>
                <td>Keep zero unless there is a timing issue.</td>
            </tr>
        </table>

        <h2 id="harmonium">5. Harmonium Settings</h2>

        <div class="note">
            The harmonium should sound like a reed-based keyboard accompaniment.
            It can be strict and key-based, or more expressive with meend and microtonal pitch follow.
        </div>

        <table>
            <tr>
                <th>Parameter</th>
                <th>Recommended Value</th>
                <th>Notes</th>
            </tr>
            <tr>
                <td>Volume</td>
                <td>50 to 70</td>
                <td>Should remain below the vocal.</td>
            </tr>
            <tr>
                <td>Timbre</td>
                <td>40% to 60%</td>
                <td>Avoid very bright harmonium tones above 85%, as they can clash with the voice.</td>
            </tr>
            <tr>
                <td>Swara Lock</td>
                <td>Tempo-dependent</td>
                <td>Use stricter lock for fast phrases and looser lock for slow gamaka-heavy phrases.</td>
            </tr>
            <tr>
                <td>Expression Mode</td>
                <td>Meend / Glide</td>
                <td>Best general expressive mode. Use Strict Keys for fast, clean accompaniment.</td>
            </tr>
            <tr>
                <td>Pitch Follow</td>
                <td>30% to 45%</td>
                <td>Higher values follow the vocalist's microtones more closely. Lower values stay closer to fixed keys.</td>
            </tr>
            <tr>
                <td>Meend Glide</td>
                <td>50 ms to 90 ms</td>
                <td>Controls slide feeling between swaras. Reduce for fast passages.</td>
            </tr>
            <tr>
                <td>Gamaka Amount</td>
                <td>35% to 55%</td>
                <td>Use more for slow phrases and less for fast passages.</td>
            </tr>
            <tr>
                <td>Gamaka Rate</td>
                <td>5.0 Hz to 6.0 Hz</td>
                <td>Natural oscillation speed.</td>
            </tr>
            <tr>
                <td>Gamaka Depth</td>
                <td>8 to 15 cents</td>
                <td>Higher values create stronger ornamentation.</td>
            </tr>
            <tr>
                <td>Bellows Sensitivity</td>
                <td>60% to 80%</td>
                <td>Higher values make the harmonium respond more to vocal energy.</td>
            </tr>
            <tr>
                <td>Bellows Attack</td>
                <td>35 ms to 60 ms</td>
                <td>Controls how fast the harmonium blooms into a phrase.</td>
            </tr>
            <tr>
                <td>Bellows Release</td>
                <td>180 ms to 280 ms</td>
                <td>Controls how long the harmonium sustains after the phrase ends.</td>
            </tr>
            <tr>
                <td>Reed Detune</td>
                <td>3 to 6 cents</td>
                <td>Adds natural chorus-like realism.</td>
            </tr>
            <tr>
                <td>Reed Blend</td>
                <td>40% to 60%</td>
                <td>Controls the amount of detuned reed layer.</td>
            </tr>
            <tr>
                <td>Air Noise</td>
                <td>8% to 15%</td>
                <td>Small amount improves realism. Too much makes it airy.</td>
            </tr>
            <tr>
                <td>Key Click</td>
                <td>8% to 15%</td>
                <td>Adds mechanical attack realism.</td>
            </tr>
            <tr>
                <td>Dynamic Brightness</td>
                <td>45% to 65%</td>
                <td>Makes louder phrases brighter, like real bellows pressure.</td>
            </tr>
            <tr>
                <td>Octave Shift</td>
                <td>0 or -1</td>
                <td>If detected sruti is high, use -1 to avoid thin or squeaky sound.</td>
            </tr>
        </table>

        <h3>Harmonium Tempo Guide</h3>
        <table>
            <tr>
                <th>Tempo</th>
                <th>Swara Lock</th>
                <th>Pitch Follow</th>
                <th>Meend Glide</th>
                <th>Gamaka Amount</th>
            </tr>
            <tr>
                <td>Slow, below 70 BPM</td>
                <td>40% to 60%</td>
                <td>40% to 55%</td>
                <td>70 ms to 110 ms</td>
                <td>50% to 70%</td>
            </tr>
            <tr>
                <td>Medium, 70 to 100 BPM</td>
                <td>55% to 75%</td>
                <td>30% to 45%</td>
                <td>50 ms to 80 ms</td>
                <td>35% to 55%</td>
            </tr>
            <tr>
                <td>Fast, above 100 BPM</td>
                <td>70% to 90%</td>
                <td>20% to 35%</td>
                <td>25 ms to 50 ms</td>
                <td>15% to 35%</td>
            </tr>
        </table>

        <h2 id="veena">6. Veena Settings</h2>
        <table>
            <tr>
                <th>Parameter</th>
                <th>Recommended Value</th>
                <th>Notes</th>
            </tr>
            <tr>
                <td>Volume</td>
                <td>45 to 65</td>
                <td>Veena should support the vocal without dominating it.</td>
            </tr>
            <tr>
                <td>Meetu Sharpness</td>
                <td>1 to 10</td>
                <td>Use lower values for soft plucks and higher values for sharper attack.</td>
            </tr>
            <tr>
                <td>Sustain</td>
                <td>Tempo-dependent</td>
                <td>Lower sustain for fast passages, higher sustain for slow phrases.</td>
            </tr>
            <tr>
                <td>Gamaka Tension Choke</td>
                <td>1.5 to 3.5</td>
                <td>Higher values can make the string feel choked during heavy gamakas.</td>
            </tr>
            <tr>
                <td>Kampita Depth</td>
                <td>8 to 20 cents</td>
                <td>Controls the wobble or oscillation depth.</td>
            </tr>
            <tr>
                <td>Octave Shift</td>
                <td>0 or -1</td>
                <td>Use -1 if the veena sounds too high or thin.</td>
            </tr>
        </table>

        <h3>Veena Sustain Guide</h3>
        <table>
            <tr>
                <th>Tempo</th>
                <th>Recommended Sustain</th>
            </tr>
            <tr>
                <td>Fast, above 100 BPM</td>
                <td>3.5 to 4.5</td>
            </tr>
            <tr>
                <td>Medium, 70 to 100 BPM</td>
                <td>4.5 to 6.0</td>
            </tr>
            <tr>
                <td>Slow, below 70 BPM</td>
                <td>5.5 to 7.5</td>
            </tr>
        </table>

        <h2 id="clarinet">7. Clarinet Settings</h2>

        <div class="note">
            The clarinet works best when it behaves like a melodic accompanist.
            It should follow the vocal phrase, breathe naturally, and avoid excessive ornamentation
            during fast passages.
        </div>

        <table>
            <tr>
                <th>Parameter</th>
                <th>Recommended Value</th>
                <th>Notes</th>
            </tr>
            <tr>
                <td>Volume</td>
                <td>55 to 70</td>
                <td>Keep the clarinet slightly below the vocal level.</td>
            </tr>
            <tr>
                <td>Melody Mode</td>
                <td>Shadow Vocal</td>
                <td>Best default. It follows the vocal phrase smoothly.</td>
            </tr>
            <tr>
                <td>Pitch Glide</td>
                <td>30 ms to 60 ms</td>
                <td>Higher glide gives smoother Carnatic-style slides. Lower it for fast passages.</td>
            </tr>
            <tr>
                <td>Gamaka Amount</td>
                <td>35% to 65%</td>
                <td>Use more for slow phrases and less for fast passages.</td>
            </tr>
            <tr>
                <td>Vibrato Rate</td>
                <td>4.8 Hz to 5.8 Hz</td>
                <td>Natural subtle vibrato range.</td>
            </tr>
            <tr>
                <td>Vibrato Depth</td>
                <td>5 to 12 cents</td>
                <td>Avoid very high vibrato depth, or the clarinet may sound unnatural.</td>
            </tr>
            <tr>
                <td>Breath Sensitivity</td>
                <td>60% to 80%</td>
                <td>Adds dynamic response and expression.</td>
            </tr>
            <tr>
                <td>Breath Noise / Turbulence</td>
                <td>8% to 20%</td>
                <td>Small amount improves realism. Too much makes the sound airy.</td>
            </tr>
            <tr>
                <td>Timbre / Woodiness</td>
                <td>55% to 75%</td>
                <td>Higher woodiness gives a warmer, more natural clarinet tone.</td>
            </tr>
            <tr>
                <td>Octave Shift</td>
                <td>0 or -1</td>
                <td>Use -1 if the clarinet sounds too thin or high.</td>
            </tr>
        </table>

        <h3>Clarinet Melody Mode Guide</h3>
        <table>
            <tr>
                <th>Mode</th>
                <th>When to Use</th>
            </tr>
            <tr>
                <td>Shadow Vocal</td>
                <td>Best general accompaniment. The clarinet softly follows the vocal contour.</td>
            </tr>
            <tr>
                <td>Unison</td>
                <td>Use when you want the clarinet to follow the vocal more directly.</td>
            </tr>
            <tr>
                <td>Answer Phrases</td>
                <td>Use when you want the clarinet to respond during gaps in the vocal phrase.</td>
            </tr>
            <tr>
                <td>Off</td>
                <td>Disables the clarinet melody while keeping the volume slider available.</td>
            </tr>
        </table>

        <h3>Clarinet Gamaka and Glide Guide</h3>
        <table>
            <tr>
                <th>Tempo</th>
                <th>Pitch Glide</th>
                <th>Gamaka Amount</th>
            </tr>
            <tr>
                <td>Slow, below 70 BPM</td>
                <td>45 ms to 70 ms</td>
                <td>55% to 75%</td>
            </tr>
            <tr>
                <td>Medium, 70 to 100 BPM</td>
                <td>30 ms to 50 ms</td>
                <td>35% to 55%</td>
            </tr>
            <tr>
                <td>Fast, above 100 BPM</td>
                <td>15 ms to 35 ms</td>
                <td>15% to 35%</td>
            </tr>
        </table>

        <h2 id="articulation">8. Clarinet Articulation Guide</h2>

        <p>
            Articulation controls how connected or separated the clarinet notes feel.
            For Carnatic accompaniment, the clarinet should usually be smooth and legato,
            not sharply tongued.
        </p>

        <table>
            <tr>
                <th>Musical Situation</th>
                <th>Recommended Articulation Value</th>
            </tr>
            <tr>
                <td>Slow, expressive phrases</td>
                <td>15 to 25</td>
            </tr>
            <tr>
                <td>Normal Carnatic vocal shadowing</td>
                <td>20 to 35</td>
            </tr>
            <tr>
                <td>Medium tempo</td>
                <td>30 to 45</td>
            </tr>
            <tr>
                <td>Fast passages / quicker BPM</td>
                <td>40 to 55</td>
            </tr>
            <tr>
                <td>Answer phrases / gaps only</td>
                <td>35 to 55</td>
            </tr>
            <tr>
                <td>Very gamaka-heavy phrases</td>
                <td>10 to 25</td>
            </tr>
        </table>

        <h3>Simple Articulation Rule</h3>
        <ul>
            <li>If the clarinet sounds <strong>too smooth or smeared</strong>, increase articulation to 35 to 45.</li>
            <li>If the clarinet sounds <strong>too choppy or machine-like</strong>, reduce articulation to 15 to 25.</li>
            <li>For most Carnatic accompaniment, start with <span class="good">25</span>.</li>
        </ul>

        <h2 id="mridangam">9. Mridangam Settings</h2>
        <table>
            <tr>
                <th>Parameter</th>
                <th>Recommended Value</th>
                <th>Notes</th>
            </tr>
            <tr>
                <td>Volume</td>
                <td>45 to 65</td>
                <td>The mridangam should support rhythm without masking the vocal.</td>
            </tr>
            <tr>
                <td>Sustain / Gumki Resonance</td>
                <td>Tempo-dependent</td>
                <td>Lower sustain for fast passages, higher sustain for slow phrases.</td>
            </tr>
            <tr>
                <td>Skin Tightness</td>
                <td>55% to 80%</td>
                <td>Higher values give a tighter, brighter stroke. Lower values sound deeper.</td>
            </tr>
        </table>

        <h3>Mridangam Sustain Guide</h3>
        <table>
            <tr>
                <th>Tempo</th>
                <th>Recommended Sustain</th>
            </tr>
            <tr>
                <td>Fast, above 100 BPM</td>
                <td>3.5 to 5.0</td>
            </tr>
            <tr>
                <td>Medium, 70 to 100 BPM</td>
                <td>4.5 to 6.0</td>
            </tr>
            <tr>
                <td>Slow, below 70 BPM</td>
                <td>5.0 to 7.0</td>
            </tr>
        </table>

        <h2 id="presets">10. Recommended Presets</h2>

        <h3>Slow, Expressive Piece</h3>
        <ul>
            <li>Harmonium Expression Mode: Meend / Glide</li>
            <li>Harmonium Pitch Follow: 40% to 55%</li>
            <li>Harmonium Meend Glide: 70 ms to 110 ms</li>
            <li>Harmonium Gamaka Amount: 50% to 70%</li>
            <li>Harmonium Bellows Release: 250 ms to 400 ms</li>
            <li>Veena Sustain: 5.5 to 7.5</li>
            <li>Clarinet Pitch Glide: 45 ms to 70 ms</li>
            <li>Clarinet Gamaka Amount: 55% to 75%</li>
            <li>Clarinet Articulation: 18 to 25</li>
            <li>Mridangam Sustain: 5.0 to 7.0</li>
        </ul>

        <h3>Medium Tempo Piece</h3>
        <ul>
            <li>Harmonium Expression Mode: Meend / Glide</li>
            <li>Harmonium Pitch Follow: 30% to 45%</li>
            <li>Harmonium Meend Glide: 50 ms to 80 ms</li>
            <li>Harmonium Gamaka Amount: 35% to 55%</li>
            <li>Harmonium Bellows Release: 180 ms to 280 ms</li>
            <li>Veena Sustain: 4.5 to 6.0</li>
            <li>Clarinet Pitch Glide: 30 ms to 50 ms</li>
            <li>Clarinet Gamaka Amount: 35% to 55%</li>
            <li>Clarinet Articulation: 25 to 35</li>
            <li>Mridangam Sustain: 4.5 to 6.0</li>
        </ul>

        <h3>Fast Piece</h3>
        <ul>
            <li>Harmonium Expression Mode: Strict Keys</li>
            <li>Harmonium Pitch Follow: 20% to 35%</li>
            <li>Harmonium Meend Glide: 25 ms to 50 ms</li>
            <li>Harmonium Gamaka Amount: 15% to 35%</li>
            <li>Harmonium Bellows Release: 120 ms to 200 ms</li>
            <li>Veena Sustain: 3.5 to 4.5</li>
            <li>Clarinet Pitch Glide: 15 ms to 35 ms</li>
            <li>Clarinet Gamaka Amount: 15% to 35%</li>
            <li>Clarinet Articulation: 40 to 55</li>
            <li>Mridangam Sustain: 3.5 to 5.0</li>
        </ul>

        <h2 id="troubleshooting">11. Troubleshooting</h2>

        <h3>Harmonium sounds too mechanical</h3>
        <ul>
            <li>Use Meend / Glide mode.</li>
            <li>Increase Pitch Follow to 35% to 50%.</li>
            <li>Increase Meend Glide slightly.</li>
            <li>Increase Bellows Sensitivity.</li>
            <li>Add a small amount of Air Noise and Key Click.</li>
        </ul>

        <h3>Harmonium sounds too smeared or unstable</h3>
        <ul>
            <li>Reduce Pitch Follow.</li>
            <li>Reduce Meend Glide.</li>
            <li>Increase Swara Lock.</li>
            <li>Use Strict Keys mode for fast passages.</li>
        </ul>

        <h3>Harmonium sounds too thin or squeaky</h3>
        <ul>
            <li>Use Octave Shift -1.</li>
            <li>Reduce Timbre / Brightness.</li>
            <li>Reduce Gamaka Depth.</li>
        </ul>

        <h3>Harmonium sounds too chorus-like</h3>
        <ul>
            <li>Reduce Reed Detune.</li>
            <li>Reduce Reed Blend.</li>
        </ul>

        <h3>Clarinet sounds too artificial</h3>
        <ul>
            <li>Increase Pitch Glide slightly.</li>
            <li>Increase Gamaka Amount moderately.</li>
            <li>Increase Breath Sensitivity.</li>
            <li>Increase Woodiness to 60% or higher.</li>
            <li>Set Articulation to 20 to 30.</li>
        </ul>

        <h3>Clarinet sounds too choppy</h3>
        <ul>
            <li>Reduce Articulation.</li>
            <li>Increase Pitch Glide.</li>
            <li>Reduce Breath Noise / Turbulence.</li>
            <li>Use Shadow Vocal mode instead of Unison.</li>
        </ul>

        <h3>Clarinet sounds too smeared or unclear</h3>
        <ul>
            <li>Increase Articulation.</li>
            <li>Reduce Pitch Glide.</li>
            <li>Reduce Gamaka Amount.</li>
            <li>For fast passages, reduce clarinet volume slightly.</li>
        </ul>

        <h3>Mix sounds crowded</h3>
        <ul>
            <li>Lower Harmonium, Veena, or Clarinet volume.</li>
            <li>Do not lower the vocal first.</li>
            <li>Use only one main melodic accompaniment prominently at a time.</li>
            <li>Reduce sruti box volume if the background feels too dense.</li>
        </ul>

        <h3>Mridangam masks the vocal</h3>
        <ul>
            <li>Reduce mridangam volume.</li>
            <li>Reduce sustain.</li>
            <li>Lower skin tightness slightly if the strokes are too sharp.</li>
        </ul>

        <div class="note">
            Final tip: Use the <strong>Auto-Analyze Mix Settings</strong> button before exporting.
            It can detect common volume, timbre, and tempo-related issues.
        </div>

        </body>
        </html>
        """