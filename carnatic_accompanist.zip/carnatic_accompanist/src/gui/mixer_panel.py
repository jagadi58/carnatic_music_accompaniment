#!/usr/bin/env python3
"""
Mixer and Export panel for Carnatic Accompanist.
Compact main panel: each instrument shows only its volume slider.
All detailed expression controls live in per-instrument popup dialogs.
NEW: sruti_secondary attribute (set by main window from detected/overridden
raga) is exported to the sruti box as secondary_note.
"""
from pathlib import Path
from typing import Optional

import numpy as np

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QGroupBox, QFormLayout, QSlider, QDoubleSpinBox, QSpinBox,
    QFileDialog, QMessageBox, QProgressBar, QComboBox,
    QDialog, QScrollArea, QFrame
)
from PyQt6.QtCore import Qt, pyqtSignal, QThread

from src.mixer.audio_mixer import AudioMixer


OCTAVE_ITEMS = [
    "0 (Normal)",
    "-1 (Down 1 Octave)",
    "-2 (Down 2 Octaves)",
    "+1 (Up 1 Octave)",
    "+2 (Up 2 Octaves)"
]

AKSHARA_MAP = {
    "8 (Adi)": 8,
    "6 (Rupaka)": 6,
    "7 (Misra Chapu)": 7,
    "5 (Khanda Chapu)": 5,
    "14 (Khanda Ata)": 14
}


class MixWorker(QThread):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    progress = pyqtSignal(int)

    def __init__(
        self,
        mixer,
        vocal_audio,
        sr,
        sruti,
        bpm,
        aksharas,
        inst_params,
        vocal_vol,
        out_path,
        frequencies,
        confidences,
        pitch_times
    ):
        super().__init__()

        self.mixer = mixer
        self.vocal_audio = vocal_audio
        self.sr = sr
        self.sruti = sruti
        self.bpm = bpm
        self.aksharas = aksharas
        self.inst_params = inst_params
        self.vocal_vol = vocal_vol
        self.out_path = out_path
        self.frequencies = frequencies
        self.confidences = confidences
        self.pitch_times = pitch_times

    def run(self):
        try:
            result_path = self.mixer.mix_and_export(
                self.vocal_audio,
                self.sr,
                self.sruti,
                self.bpm,
                self.aksharas,
                self.inst_params,
                self.vocal_vol,
                self.out_path,
                frequencies=self.frequencies,
                confidences=self.confidences,
                pitch_times=self.pitch_times,
                progress_callback=self.progress.emit
            )
            self.finished.emit(result_path)
        except Exception as e:
            self.error.emit(str(e))


class SettingsDialog(QDialog):
    """Scrollable popup dialog that hosts the detailed controls of one instrument."""

    def __init__(self, title: str, parent=None):
        super().__init__(parent)

        self.setWindowTitle(title)
        self.resize(560, 620)

        outer = QVBoxLayout(self)

        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)

        content = QWidget(self.scroll)
        self.form = QFormLayout(content)
        self.form.setHorizontalSpacing(14)
        self.form.setVerticalSpacing(8)
        self.form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

        self.scroll.setWidget(content)
        outer.addWidget(self.scroll)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        outer.addWidget(close_btn)

    def add_section(self, title: str):
        lbl = QLabel(f"<b>{title}</b>")
        lbl.setStyleSheet("margin-top: 10px;")
        self.form.addRow("", lbl)

    def add_slider(self, label: str, min_val: int, max_val: int, initial: int, formatter):
        row = QWidget(self)
        lay = QHBoxLayout(row)
        lay.setContentsMargins(0, 0, 0, 0)

        slider = QSlider(Qt.Orientation.Horizontal, row)
        slider.setRange(min_val, max_val)
        slider.setValue(initial)

        val = QLabel(formatter(initial), row)
        val.setMinimumWidth(95)
        slider.valueChanged.connect(lambda v: val.setText(formatter(v)))

        lay.addWidget(slider, 1)
        lay.addWidget(val)

        self.form.addRow(label, row)
        return slider, val

    def add_combo(self, label: str, items: list):
        combo = QComboBox(self)
        combo.addItems(items)
        self.form.addRow(label, combo)
        return combo

    def add_int_spin(self, label: str, min_val: int, max_val: int, initial: int, suffix: str = ""):
        spin = QSpinBox(self)
        spin.setRange(min_val, max_val)
        spin.setValue(initial)
        spin.setSuffix(suffix)
        self.form.addRow(label, spin)
        return spin

    def add_double_spin(self, label: str, min_val: float, max_val: float, initial: float, step: float = 0.1):
        spin = QDoubleSpinBox(self)
        spin.setRange(min_val, max_val)
        spin.setValue(initial)
        spin.setSingleStep(step)
        self.form.addRow(label, spin)
        return spin


class MixerPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.mixer = AudioMixer()

        self.vocal_audio = None
        self.sr = 44100
        self.sruti_freq = 261.63
        self.bpm = 120.0
        self.aksharas = 8
        self.tala_score = 1.0
        self.sruti_secondary = "P"          # NEW: set by main window from raga

        self.frequencies = None
        self.confidences = None
        self.pitch_times = None

        self.worker = None

        self.init_ui()

    def set_analysis_data(
        self,
        vocal_audio,
        sr,
        sruti_freq,
        bpm,
        aksharas,
        frequencies=None,
        confidences=None,
        pitch_times=None
    ):
        self.vocal_audio = vocal_audio
        self.sr = sr

        if sruti_freq and sruti_freq > 0:
            self.sruti_freq = sruti_freq

        if bpm and bpm > 0:
            self.bpm = bpm

        if aksharas and aksharas > 0:
            self.aksharas = aksharas

        self.frequencies = frequencies
        self.confidences = confidences
        self.pitch_times = pitch_times

        self.lbl_status.setText(
            f"Ready to mix. Sruti: {self.sruti_freq:.1f} Hz, "
            f"Tala: {self.aksharas} beats @ {self.bpm:.1f} BPM"
        )

    # ------------------------------------------------------------------
    def _open_dialog(self, dlg):
        try:
            dlg.exec()
        except Exception as e:
            QMessageBox.warning(self, "Settings Error", f"Could not open settings:\n{e}")

    # ------------------------------------------------------------------
    def init_ui(self):
        layout = QVBoxLayout(self)

        self.lbl_status = QLabel("Load an audio file first to enable mixing.")
        self.lbl_status.setStyleSheet("color: gray; font-weight: bold; padding: 10px;")
        layout.addWidget(self.lbl_status)

        controls_group = QGroupBox("Instrument Controls", self)
        controls_layout = QVBoxLayout(controls_group)
        controls_layout.setSpacing(8)

        tip = QLabel(
            "Tip: use the ⚙ Settings button of each instrument to open "
            "its detailed expression controls."
        )
        tip.setStyleSheet("color: #555555; padding: 4px;")
        tip.setWordWrap(True)
        controls_layout.addWidget(tip)

        def make_main_row(name: str, vol_range=(0, 100), vol_default=70, has_settings=True):
            row = QWidget(self)
            lay = QHBoxLayout(row)
            lay.setContentsMargins(0, 0, 0, 0)

            name_label = QLabel(name, row)
            name_label.setFixedWidth(95)
            name_label.setStyleSheet("font-weight: bold;")
            lay.addWidget(name_label)

            lay.addWidget(QLabel("Vol:", row))

            vol = QSlider(Qt.Orientation.Horizontal, row)
            vol.setRange(vol_range[0], vol_range[1])
            vol.setValue(vol_default)
            vol.setFixedWidth(170)

            vol_label = QLabel(f"{vol_default}%", row)
            vol_label.setMinimumWidth(45)
            vol.valueChanged.connect(lambda v: vol_label.setText(f"{v}%"))

            lay.addWidget(vol)
            lay.addWidget(vol_label)

            settings_btn = None
            if has_settings:
                settings_btn = QPushButton("⚙ Settings...", row)
                settings_btn.setFixedWidth(110)
                lay.addWidget(settings_btn)

            lay.addStretch()
            controls_layout.addWidget(row)

            return vol, settings_btn

        # -------------------------------------------------
        # Compact main rows
        # -------------------------------------------------
        self.vocal_vol_slider, _ = make_main_row("Vocal Track", (0, 200), 100, has_settings=False)
        self.sruti_vol, sruti_btn = make_main_row("Sruti Box")
        self.harm_vol, harm_btn = make_main_row("Harmonium")
        self.veena_vol, veena_btn = make_main_row("Veena")
        self.clar_vol, clar_btn = make_main_row("Clarinet")
        self.mrid_vol, mrid_btn = make_main_row("Mridangam")

        # -------------------------------------------------
        # Sruti Box popup
        # -------------------------------------------------
        self.sruti_dialog = SettingsDialog("Sruti Box Settings", self)
        self.sruti_pitch = self.sruti_dialog.add_int_spin("Pitch Shift:", -1200, 1200, 0, " cents")
        self.sruti_tempo = self.sruti_dialog.add_double_spin("Tempo:", 0.5, 2.0, 1.0)
        self.sruti_offset = self.sruti_dialog.add_int_spin("Offset:", -500, 500, 0, " ms")
        sruti_btn.clicked.connect(lambda: self._open_dialog(self.sruti_dialog))

        # -------------------------------------------------
        # Harmonium popup
        # -------------------------------------------------
        hd = SettingsDialog("Harmonium Settings", self)
        self.harm_dialog = hd

        hd.add_section("Basic")
        self.harm_pitch = hd.add_int_spin("Pitch Shift:", -1200, 1200, 0, " cents")
        self.harm_tempo = hd.add_double_spin("Tempo:", 0.5, 2.0, 1.0)
        self.harm_offset = hd.add_int_spin("Offset:", -500, 500, 0, " ms")

        hd.add_section("Tone & Expression")
        self.timbre_slider, self.timbre_val_label = hd.add_slider(
            "Timbre (Muffled -> Piercing):", 0, 150, 50, lambda v: f"{v}%"
        )
        self.ornament_slider, self.ornament_val_label = hd.add_slider(
            "Swara Lock (Loose -> Strict):", 20, 120, 60, lambda v: f"{v}%"
        )
        self.harm_expression_combo = hd.add_combo(
            "Expression Mode:",
            ["Meend / Glide", "Strict Keys", "Shadow Vocal"]
        )
        self.harm_follow_slider, _ = hd.add_slider(
            "Pitch Follow (Keys -> Microtones):", 0, 100, 35, lambda v: f"{v}%"
        )
        self.harm_glide_slider, _ = hd.add_slider(
            "Meend Glide:", 0, 150, 70, lambda v: f"{v} ms"
        )

        hd.add_section("Gamaka")
        self.harm_gamaka_amount_slider, _ = hd.add_slider(
            "Gamaka Amount:", 0, 100, 45, lambda v: f"{v}%"
        )
        self.harm_gamaka_rate_slider, _ = hd.add_slider(
            "Gamaka Rate:", 30, 90, 55, lambda v: f"{v / 10:.1f} Hz"
        )
        self.harm_gamaka_depth_slider, _ = hd.add_slider(
            "Gamaka Depth:", 0, 40, 12, lambda v: f"{v} cents"
        )

        hd.add_section("Bellows & Reeds")
        self.harm_bellows_sens_slider, _ = hd.add_slider(
            "Bellows Sensitivity:", 0, 100, 70, lambda v: f"{v}%"
        )
        self.harm_bellows_attack_slider, _ = hd.add_slider(
            "Bellows Attack:", 10, 200, 45, lambda v: f"{v} ms"
        )
        self.harm_bellows_release_slider, _ = hd.add_slider(
            "Bellows Release:", 50, 600, 220, lambda v: f"{v} ms"
        )
        self.harm_detune_slider, _ = hd.add_slider(
            "Reed Detune:", 0, 15, 4, lambda v: f"{v} cents"
        )
        self.harm_reed_blend_slider, _ = hd.add_slider(
            "Reed Blend / Chorus:", 0, 100, 50, lambda v: f"{v}%"
        )
        self.harm_air_slider, _ = hd.add_slider(
            "Air Noise:", 0, 30, 10, lambda v: f"{v}%"
        )
        self.harm_click_slider, _ = hd.add_slider(
            "Key Click:", 0, 30, 12, lambda v: f"{v}%"
        )
        self.harm_dynamic_bright_slider, _ = hd.add_slider(
            "Dynamic Brightness:", 0, 100, 55, lambda v: f"{v}%"
        )
        self.harm_octave_combo = hd.add_combo("Octave Shift:", OCTAVE_ITEMS)

        harm_btn.clicked.connect(lambda: self._open_dialog(hd))

        # -------------------------------------------------
        # Veena popup (v4 defaults: soft attack, long ring)
        # -------------------------------------------------
        vd = SettingsDialog("Veena Settings", self)
        self.veena_dialog = vd

        vd.add_section("Basic")
        self.veena_pitch = vd.add_int_spin("Pitch Shift:", -1200, 1200, 0, " cents")
        self.veena_tempo = vd.add_double_spin("Tempo:", 0.5, 2.0, 1.0)
        self.veena_offset = vd.add_int_spin("Offset:", -500, 500, 0, " ms")

        vd.add_section("Pluck & String Expression")
        self.veena_attack_slider, self.veena_attack_val_label = vd.add_slider(
            "Meetu Sharpness:", 1, 50, 30, lambda v: f"{v / 1000:.3f}s"
        )
        self.veena_sustain_slider, self.veena_sustain_val_label = vd.add_slider(
            "Sustain (Decay Rate):", 20, 100, 40, lambda v: f"{v / 10:.1f}"
        )
        self.veena_tension_slider, self.veena_tension_val_label = vd.add_slider(
            "Gamaka Tension Choke:", 10, 50, 15, lambda v: f"{v / 10:.1f}"
        )
        self.veena_wobble_slider, self.veena_wobble_val_label = vd.add_slider(
            "Kampita Depth (Wobble):", 5, 45, 15, lambda v: f"{v:.1f} cents"
        )
        self.veena_kamp_rate_slider, self.veena_kamp_rate_val_label = vd.add_slider(
            "Kampita Rate:", 30, 70, 42, lambda v: f"{v / 10:.1f} Hz"
        )

        vd.add_section("Slide & Body")
        self.veena_slide_slider, self.veena_slide_val_label = vd.add_slider(
            "Jaru / Slide Time:", 20, 250, 120, lambda v: f"{v} ms"
        )
        self.veena_res_slider, self.veena_res_val_label = vd.add_slider(
            "Body Resonance (Ring):", 0, 100, 55, lambda v: f"{v}%"
        )
        self.veena_syll_slider, self.veena_syll_val_label = vd.add_slider(
            "Syllable Response:", 0, 100, 45, lambda v: f"{v}%"
        )

        self.veena_octave_combo = vd.add_combo("Octave Shift:", OCTAVE_ITEMS)

        veena_btn.clicked.connect(lambda: self._open_dialog(vd))

        # -------------------------------------------------
        # Clarinet popup
        # -------------------------------------------------
        cd = SettingsDialog("Clarinet Settings", self)
        self.clar_dialog = cd

        cd.add_section("Basic")
        self.clar_pitch = cd.add_int_spin("Pitch Shift:", -1200, 1200, 0, " cents")
        self.clar_tempo = cd.add_double_spin("Tempo:", 0.5, 2.0, 1.0)
        self.clar_offset = cd.add_int_spin("Offset:", -500, 500, 0, " ms")

        cd.add_section("Tone & Breath")
        self.clar_breath_slider, self.clar_breath_val_label = cd.add_slider(
            "Breath Sensitivity:", 0, 100, 70, lambda v: f"{v}%"
        )
        self.clar_wood_slider, self.clar_wood_val_label = cd.add_slider(
            "Timbre (Reedy -> Woody):", 0, 100, 60, lambda v: f"{v}%"
        )
        self.clar_turb_slider, self.clar_turb_val_label = cd.add_slider(
            "Breath Noise (Turbulence):", 0, 50, 15, lambda v: f"{v}%"
        )
        self.clar_octave_combo = cd.add_combo("Octave Shift:", OCTAVE_ITEMS)

        cd.add_section("Melody Expression")
        self.clar_follow_combo = cd.add_combo(
            "Melody Mode:",
            ["Shadow Vocal", "Unison", "Answer Phrases", "Off"]
        )
        self.clar_glide_slider, _ = cd.add_slider(
            "Pitch Glide:", 0, 120, 45, lambda v: f"{v} ms"
        )
        self.clar_gamaka_slider, _ = cd.add_slider(
            "Gamaka Amount:", 0, 100, 55, lambda v: f"{v}%"
        )
        self.clar_vib_rate_slider, _ = cd.add_slider(
            "Vibrato Rate:", 30, 80, 52, lambda v: f"{v / 10:.1f} Hz"
        )
        self.clar_vib_depth_slider, _ = cd.add_slider(
            "Vibrato Depth:", 0, 30, 8, lambda v: f"{v} cents"
        )
        self.clar_articulation_slider, _ = cd.add_slider(
            "Articulation (Legato -> Tongued):",
            0,
            100,
            25,
            lambda v: (
                f"{v}% (Legato)" if v < 35 else
                f"{v}% (Balanced)" if v < 75 else
                f"{v}% (Tongued)"
            )
        )

        clar_btn.clicked.connect(lambda: self._open_dialog(cd))

        # -------------------------------------------------
        # Mridangam popup (accompanist edition)
        # -------------------------------------------------
        md = SettingsDialog("Mridangam Settings", self)
        self.mrid_dialog = md

        md.add_section("Basic")
        self.mrid_pitch = md.add_int_spin("Pitch Shift:", -1200, 1200, 0, " cents")
        self.mrid_tempo = md.add_double_spin("Tempo:", 0.5, 2.0, 1.0)
        self.mrid_offset = md.add_int_spin("Offset:", -500, 500, 0, " ms")

        md.add_section("Drum Expression")
        self.mrid_sustain_slider, self.mrid_sustain_val_label = md.add_slider(
            "Sustain (Gumki Resonance):", 20, 100, 50, lambda v: f"{v / 10:.1f}"
        )
        self.mrid_timbre_slider, self.mrid_timbre_val_label = md.add_slider(
            "Skin Tightness (Timbre):", 0, 100, 70, lambda v: f"{v}%"
        )

        md.add_section("Accompanist Behaviour")
        self.mrid_density_slider, self.mrid_density_val_label = md.add_slider(
            "Groove Density:", 0, 100, 55, lambda v: f"{v}%"
        )
        self.mrid_fills_slider, self.mrid_fills_val_label = md.add_slider(
            "Phrase Fills (Korvai/Gumki):", 0, 100, 60, lambda v: f"{v}%"
        )
        self.mrid_follow_slider, self.mrid_follow_val_label = md.add_slider(
            "Vocal Follow & Ducking:", 0, 100, 40, lambda v: f"{v}%"
        )

        md.add_section("Rhythm Source")
        self.mrid_rhythm_combo = md.add_combo(
            "Tempo / Aksharas:",
            ["Auto (Detected)", "Manual Override"]
        )
        self.mrid_bpm_spin = md.add_double_spin("Manual BPM:", 30.0, 240.0, 120.0, 1.0)
        self.mrid_aksharas_combo = md.add_combo("Manual Aksharas:", list(AKSHARA_MAP.keys()))

        mrid_btn.clicked.connect(lambda: self._open_dialog(md))

        layout.addWidget(controls_group)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        self.btn_export = QPushButton("Generate Mix & Export to File...")
        self.btn_export.setStyleSheet(
            "padding: 15px; "
            "font-size: 16px; "
            "font-weight: bold; "
            "background-color: #4CAF50; "
            "color: white;"
        )
        self.btn_export.clicked.connect(self.export_mix)

        layout.addWidget(self.btn_export)
        layout.addStretch()

    # ------------------------------------------------------------------
    def _get_octave_shift_val(self, combo: QComboBox) -> int:
        text = combo.currentText()

        if "-1" in text:
            return -1
        elif "-2" in text:
            return -2
        elif "+1" in text:
            return 1
        elif "+2" in text:
            return 2

        return 0

    # ------------------------------------------------------------------
    def export_mix(self):
        if self.vocal_audio is None:
            QMessageBox.warning(self, "No Audio", "Please load an audio file first.")
            return

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Export Mixed Audio",
            "",
            "WAV Files (*.wav);;MP3 Files (*.mp3)"
        )

        if not file_path:
            return

        harm_mode_text = self.harm_expression_combo.currentText()

        if "Strict" in harm_mode_text:
            harm_mode = "strict_keys"
        elif "Shadow" in harm_mode_text:
            harm_mode = "shadow_vocal"
        else:
            harm_mode = "meend"

        clar_mode_text = self.clar_follow_combo.currentText()

        if clar_mode_text == "Off":
            clar_mode = "off"
        elif clar_mode_text == "Unison":
            clar_mode = "unison"
        elif clar_mode_text == "Answer Phrases":
            clar_mode = "answer_phrases"
        else:
            clar_mode = "shadow_vocal"

        inst_params = {
            "sruti": {
                "volume": self.sruti_vol.value() / 100.0,
                "pitch_shift_cents": self.sruti_pitch.value(),
                "tempo_multiplier": self.sruti_tempo.value(),
                "time_offset_ms": self.sruti_offset.value(),
                # NEW: raga-aware secondary drone (P / M1 / N3)
                "secondary_note": getattr(self, "sruti_secondary", "P")
            },

            "harmonium": {
                "volume": self.harm_vol.value() / 100.0,
                "pitch_shift_cents": self.harm_pitch.value(),
                "tempo_multiplier": self.harm_tempo.value(),
                "time_offset_ms": self.harm_offset.value(),

                "brightness": self.timbre_slider.value() / 100.0,
                "hysteresis_semitones": self.ornament_slider.value() / 100.0,
                "tremolo_rate_hz": 4.0,
                "tremolo_depth": 0.04,
                "octave_shift": self._get_octave_shift_val(self.harm_octave_combo),

                "expression_mode": harm_mode,
                "pitch_follow": self.harm_follow_slider.value() / 100.0,
                "meend_glide_ms": float(self.harm_glide_slider.value()),

                "gamaka_amount": self.harm_gamaka_amount_slider.value() / 100.0,
                "gamaka_rate_hz": self.harm_gamaka_rate_slider.value() / 10.0,
                "gamaka_depth_cents": float(self.harm_gamaka_depth_slider.value()),

                "bellows_sensitivity": self.harm_bellows_sens_slider.value() / 100.0,
                "bellows_attack_ms": float(self.harm_bellows_attack_slider.value()),
                "bellows_release_ms": float(self.harm_bellows_release_slider.value()),

                "reed_detune_cents": float(self.harm_detune_slider.value()),
                "reed_blend": self.harm_reed_blend_slider.value() / 100.0,

                "air_noise": self.harm_air_slider.value() / 100.0,
                "key_click": self.harm_click_slider.value() / 100.0,

                "dynamic_brightness": self.harm_dynamic_bright_slider.value() / 100.0
            },

            "veena": {
                "volume": self.veena_vol.value() / 100.0,
                "pitch_shift_cents": self.veena_pitch.value(),
                "tempo_multiplier": self.veena_tempo.value(),
                "time_offset_ms": self.veena_offset.value(),

                "attack_time": self.veena_attack_slider.value() / 1000.0,
                "decay_rate": self.veena_sustain_slider.value() / 10.0,
                "tension_choke": self.veena_tension_slider.value() / 10.0,
                "kampita_cents": float(self.veena_wobble_slider.value()),
                "kampita_hz": self.veena_kamp_rate_slider.value() / 10.0,
                "octave_shift": self._get_octave_shift_val(self.veena_octave_combo),

                "slide_ms": float(self.veena_slide_slider.value()),
                "resonance": self.veena_res_slider.value() / 100.0,
                "syllable_response": self.veena_syll_slider.value() / 100.0
            },

            "clarinet": {
                "volume": self.clar_vol.value() / 100.0,
                "pitch_shift_cents": self.clar_pitch.value(),
                "tempo_multiplier": self.clar_tempo.value(),
                "time_offset_ms": self.clar_offset.value(),

                "breath_sensitivity": self.clar_breath_slider.value() / 100.0,
                "woodiness": self.clar_wood_slider.value() / 100.0,
                "turbulence": self.clar_turb_slider.value() / 100.0,
                "octave_shift": self._get_octave_shift_val(self.clar_octave_combo),

                "follow_mode": clar_mode,
                "glide_ms": float(self.clar_glide_slider.value()),
                "gamaka_amount": self.clar_gamaka_slider.value() / 100.0,
                "vibrato_rate_hz": self.clar_vib_rate_slider.value() / 10.0,
                "vibrato_depth_cents": float(self.clar_vib_depth_slider.value()),
                "articulation": self.clar_articulation_slider.value() / 100.0
            },

            "mridangam": {
                "volume": self.mrid_vol.value() / 100.0,
                "pitch_shift_cents": self.mrid_pitch.value(),
                "tempo_multiplier": self.mrid_tempo.value(),
                "time_offset_ms": self.mrid_offset.value(),

                "decay_rate": self.mrid_sustain_slider.value() / 10.0,
                "skin_tightness": self.mrid_timbre_slider.value() / 100.0,

                "groove_density": self.mrid_density_slider.value() / 100.0,
                "phrase_fills": self.mrid_fills_slider.value() / 100.0,
                "vocal_follow": self.mrid_follow_slider.value() / 100.0,

                "rhythm_mode": "manual" if self.mrid_rhythm_combo.currentText().startswith("Manual") else "auto",
                "bpm_override": self.mrid_bpm_spin.value(),
                "aksharas_override": AKSHARA_MAP.get(self.mrid_aksharas_combo.currentText(), 0),
                "tala_confidence": getattr(self, "tala_score", 1.0)
            }
        }

        vocal_vol = self.vocal_vol_slider.value() / 100.0

        self.btn_export.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)

        self.worker = MixWorker(
            self.mixer,
            self.vocal_audio,
            self.sr,
            self.sruti_freq,
            self.bpm,
            self.aksharas,
            inst_params,
            vocal_vol,
            file_path,
            self.frequencies,
            self.confidences,
            self.pitch_times
        )

        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.finished.connect(self.on_export_finished)
        self.worker.error.connect(self.on_export_error)
        self.worker.start()

    def on_export_finished(self, file_path: str):
        self.progress_bar.setVisible(False)
        self.btn_export.setEnabled(True)

        QMessageBox.information(
            self,
            "Export Successful",
            f"Mix saved successfully to:\n{file_path}"
        )

    def on_export_error(self, error_msg: str):
        self.progress_bar.setVisible(False)
        self.btn_export.setEnabled(True)

        QMessageBox.critical(
            self,
            "Export Failed",
            f"An error occurred:\n{error_msg}"
        )