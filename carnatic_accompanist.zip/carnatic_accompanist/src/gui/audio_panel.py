#!/usr/bin/env python3
"""
Audio panel for loading and inspecting vocal audio files.
"""

from pathlib import Path
from typing import Optional

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QGroupBox, QFormLayout, QMessageBox
)
from PyQt6.QtCore import pyqtSignal

from src.core.audio_loader import AudioLoader


class AudioPanel(QWidget):
    """Panel for loading and inspecting audio files."""
    
    audio_loaded = pyqtSignal(str, object, int)  # file_path, audio, sr
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.loader = AudioLoader()
        self.current_file: Optional[Path] = None
        self.current_audio = None
        self.current_sr: Optional[int] = None
        
        self.init_ui()
    
    def init_ui(self):
        """Initialize the UI."""
        layout = QVBoxLayout(self)
        
        # File selection group
        file_group = QGroupBox("Audio File")
        file_layout = QHBoxLayout(file_group)
        
        self.file_path_label = QLabel("No file loaded")
        self.file_path_label.setStyleSheet("color: gray;")
        file_layout.addWidget(self.file_path_label, stretch=1)
        
        self.btn_browse = QPushButton("Browse...")
        self.btn_browse.clicked.connect(self.browse_file)
        file_layout.addWidget(self.btn_browse)
        
        self.btn_load = QPushButton("Load")
        self.btn_load.clicked.connect(self.load_file)
        self.btn_load.setEnabled(False)
        file_layout.addWidget(self.btn_load)
        
        layout.addWidget(file_group)
        
        # Audio info group
        info_group = QGroupBox("Audio Information")
        info_layout = QFormLayout(info_group)
        
        self.lbl_duration = QLabel("-")
        self.lbl_sample_rate = QLabel("-")
        self.lbl_channels = QLabel("-")
        self.lbl_format = QLabel("-")
        self.lbl_file_size = QLabel("-")
        
        info_layout.addRow("Duration:", self.lbl_duration)
        info_layout.addRow("Sample Rate:", self.lbl_sample_rate)
        info_layout.addRow("Channels:", self.lbl_channels)
        info_layout.addRow("Format:", self.lbl_format)
        info_layout.addRow("File Size:", self.lbl_file_size)
        
        layout.addWidget(info_group)
        
        # Status
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("padding: 10px; color: blue;")
        layout.addWidget(self.status_label)
        
        layout.addStretch()
    
    def browse_file(self):
        """Open file dialog to select audio file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Audio File",
            "",
            "Audio Files (*.wav *.mp3 *.flac *.ogg *.m4a);;All Files (*)"
        )
        
        if file_path:
            self.current_file = Path(file_path)
            self.file_path_label.setText(str(self.current_file))
            self.file_path_label.setStyleSheet("color: black;")
            self.btn_load.setEnabled(True)
    
    def load_file(self):
        """Load the selected audio file."""
        if not self.current_file:
            return
        
        try:
            self.status_label.setText(f"Loading {self.current_file.name}...")
            self.status_label.setStyleSheet("padding: 10px; color: orange;")
            
            # Force UI update
            from PyQt6.QtWidgets import QApplication
            QApplication.processEvents()
            
            # Get info
            info = self.loader.get_info(self.current_file)
            
            # Load audio
            audio, sr = self.loader.load(self.current_file)
            
            self.current_audio = audio
            self.current_sr = sr
            
            # Update info display
            self.lbl_duration.setText(f"{info['duration']:.2f} seconds")
            self.lbl_sample_rate.setText(f"{info['sample_rate']} Hz")
            self.lbl_channels.setText(str(info['channels']))
            self.lbl_format.setText(f"{info['format']} ({info['subtype']})")
            self.lbl_file_size.setText(self._format_file_size(info['file_size']))
            
            self.status_label.setText(f"Loaded: {self.current_file.name}")
            self.status_label.setStyleSheet("padding: 10px; color: green;")
            
            # Emit signal
            self.audio_loaded.emit(str(self.current_file), audio, sr)
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Load Error",
                f"Failed to load audio file:\n\n{e}"
            )
            self.status_label.setText(f"Error: {e}")
            self.status_label.setStyleSheet("padding: 10px; color: red;")
    
    @staticmethod
    def _format_file_size(size_bytes: int) -> str:
        """Format file size in human-readable form."""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} TB"
    
    def get_audio(self):
        """Get currently loaded audio."""
        return self.current_audio, self.current_sr
    
    def has_audio(self) -> bool:
        """Check if audio is loaded."""
        return self.current_audio is not None