#!/usr/bin/env python3
"""
Clarinet Instrument — No-Zoom / Anti-Spike edition.

Same smoothing philosophy as the final harmonium:
1. Pitch is HELD across vocal pauses (no linear bridges -> no racing glissando).
2. Microtone follow is CLAMPED around the locked key (±max_follow_dev_cents),
   so the clarinet shimmers with the voice but never chases large jumps.
3. Interval-aware transitions: small moves glide; large moves STEP with a
   breath dip (masked), instead of a siren-like zoom.
4. Hard vocal-presence gate: silent singer = silent clarinet (causal envelope,
   entry delay, gap hold). Dips are gated so cold entries are never notched.
5. Dynamics proportional to vocal energy (rms_contrast).
"""

import numpy as np
from typing import Dict, Any, Optional

from scipy.ndimage import gaussian_filter1d, uniform_filter1d, median_filter


class Clarinet:
    """Expressive clarinet-like accompaniment generator."""

    def get_default_params(self) -> Dict[str, Any]:
        return {
            # Basic
            "volume": 0.7,
            "pitch_shift_cents": 0.0,
            "confidence_threshold": 0.40,
            "time_offset_ms": 0.0,
            "breath_sensitivity": 0.7,
            "woodiness": 0.6,
            "turbulence": 0.10,
            "octave_shift": 0,

            # Melody behaviour
            "follow_mode": "shadow_vocal",   # shadow_vocal | unison | answer_phrases | off
            "pitch_follow": 0.5,
            "glide_ms": 45.0,
            "hysteresis_semitones": 0.6,

            # NO-ZOOM controls (clarinet: wider, more legato than harmonium)
            "max_follow_dev_cents": 90.0,    # clarinet can bend further
            "max_gliss_semitones": 3.0,      # <= glides; larger steps
            "step_dip_depth": 0.30,
            "step_dip_ms": 80.0,
            "key_dip_depth": 0.15,
            "key_dip_ms": 50.0,

            # Ornamentation
            "gamaka_amount": 0.55,
            "vibrato_rate_hz": 5.2,
            "vibrato_depth_cents": 8.0,
            "articulation": 0.25,

            # Phrasing
            "entry_delay_ms": 25.0,
            "gap_hold_ms": 150.0,
            "rms_contrast": 0.7,
        }

    # ------------------------------------------------------------------
    # Safe parameter readers
    # ------------------------------------------------------------------
    @staticmethod
    def _float(params, key, default):
        try:
            if key not in params or params[key] is None:
                return default
            return float(params[key])
        except Exception:
            return default

    @staticmethod
    def _int(params, key, default):
        try:
            if key not in params or params[key] is None:
                return default
            return int(params[key])
        except Exception:
            return default

    @staticmethod
    def _string(params, key, default):
        try:
            value = params.get(key, default)
            if value is None:
                return default
            return str(value).lower().replace(" ", "_")
        except Exception:
            return default

    # ------------------------------------------------------------------
    # Main generation
    # ------------------------------------------------------------------
    def generate(
        self,
        duration: float,
        sr: int,
        params: Dict[str, Any],
        start_freq: float = 261.63,
        frequencies: Optional[np.ndarray] = None,
        confidences: Optional[np.ndarray] = None,
        pitch_times: Optional[np.ndarray] = None,
        sruti_freq: Optional[float] = None,
        vocal_audio: Optional[np.ndarray] = None,
        **kwargs
    ) -> np.ndarray:
        p = self.get_default_params()
        p.update(params or {})

        n_samples = int(max(0.0, duration) * sr)
        out = np.zeros(n_samples, dtype=np.float32)

        if n_samples == 0:
            return out

        volume = self._float(p, "volume", 0.7)
        follow_mode = self._string(p, "follow_mode", "shadow_vocal")

        if volume <= 0.0 or follow_mode == "off":
            return out

        conf_thresh = self._float(p, "confidence_threshold", 0.40)
        rms_contrast = np.clip(self._float(p, "rms_contrast", 0.7), 0.3, 1.0)

        prepared = self._prepare_frames(
            frequencies=frequencies,
            confidences=confidences,
            pitch_times=pitch_times,
            duration=duration,
            conf_threshold=conf_thresh,
        )

        if prepared is None:
            return out

        times, filled_freqs, voiced_raw, conf_filled, frame_rate = prepared

        # ---------------- Global tuning ----------------
        octave_shift = self._int(p, "octave_shift", 0)
        pitch_shift_cents = self._float(p, "pitch_shift_cents", 0.0)

        ref_pitch = sruti_freq if sruti_freq and sruti_freq > 0 else start_freq
        if not ref_pitch or ref_pitch <= 0:
            ref_pitch = 261.63
        ref_pitch = max(20.0, float(ref_pitch))

        ref = ref_pitch * (2.0 ** octave_shift)
        freqs_oct = filled_freqs * (2.0 ** octave_shift)

        # ---------------- Swara reference (hysteresis) ----------------
        hysteresis = self._float(p, "hysteresis_semitones", 0.6)

        semitones = 12.0 * np.log2(np.maximum(freqs_oct, 10.0) / ref)
        quantized = self._hysteresis_quantize(semitones, hysteresis)

        if len(quantized) >= 3:
            quantized = median_filter(quantized, size=3)

        key_cents = quantized * 100.0
        continuous_cents = 1200.0 * np.log2(np.maximum(freqs_oct, 10.0) / ref)

        # ---------------- Follow amount per mode ----------------
        pitch_follow = np.clip(self._float(p, "pitch_follow", 0.5), 0.0, 1.0)

        if follow_mode == "unison":
            follow_amount = max(pitch_follow, 0.7)
        elif follow_mode == "answer_phrases":
            follow_amount = pitch_follow * 0.8
        else:
            follow_amount = pitch_follow

        glide_ms = self._float(p, "glide_ms", 45.0)
        glide_tau = max(0.020, glide_ms / 1000.0)

        # ---------------- NO-ZOOM pitch curve ----------------
        final_cents, large_mask = self._build_pitch_curve(
            key_cents=key_cents,
            continuous_cents=continuous_cents,
            follow_amount=follow_amount,
            max_dev_cents=self._float(p, "max_follow_dev_cents", 90.0),
            frame_rate=frame_rate,
            glide_tau=glide_tau,
            large_thresh_cents=self._float(p, "max_gliss_semitones", 3.0) * 100.0,
        )

        freq_frames = ref * np.power(2.0, final_cents / 1200.0)

        # ---------------- Causal phrase envelope ----------------
        rms_frames = self._vocal_rms_frames(vocal_audio, sr, times)

        # NEW: breath-proof gate. A breath has ENERGY but weak harmonics, so
        # neither the RMS presence gate nor raw CREPE confidence can catch it.
        # Zero the voiced mask wherever harmonic content is low.
        if vocal_audio is not None and len(vocal_audio) > 0:
            try:
                from src.core.breath_detector import breath_quality
                q = breath_quality(vocal_audio, sr, times)
                voiced_raw = voiced_raw * (q > 0.3)
            except Exception as e:
                print("[clarinet] breath gate skipped:", e)

        voiced = self._hold_gaps(
            voiced_raw.astype(float),
            frame_rate,
            self._float(p, "gap_hold_ms", 150.0) / 1000.0
        )

        voiced_smooth = self._smooth_env(voiced, frame_rate, 0.04, 0.15)

        breath_sens = np.clip(self._float(p, "breath_sensitivity", 0.7), 0.0, 1.0)

        if rms_frames is not None:
            # HARD presence gate: confidence alone must never keep the reed
            # sounding during vocal pauses.
            presence = self._smooth_env(
                (rms_frames > 0.02).astype(float),
                frame_rate,
                0.03,
                0.20
            )
            rms_gate = np.where(rms_frames > 0.02, rms_frames, 0.0) ** rms_contrast
            energy_target = voiced_smooth * rms_gate   # no floor
        else:
            presence = np.ones_like(voiced_smooth)
            energy_target = voiced_smooth

        if follow_mode == "answer_phrases":
            # Respond in the gaps: envelope from silence, no presence gate.
            silence = np.clip(1.0 - voiced_smooth, 0.0, 1.0)
            env_target = self._smooth_env(silence, frame_rate, 0.25, 0.25) * 0.75
        else:
            env_target = (
                (1.0 - breath_sens) * voiced_smooth
                + breath_sens * energy_target
            )
            # Silent singer = silent clarinet.
            env_target *= presence

        articulation = np.clip(self._float(p, "articulation", 0.25), 0.0, 1.0)
        attack = 0.020 + 0.040 * articulation
        release = 0.28 - 0.16 * articulation

        env_frames = self._smooth_env(env_target, frame_rate, attack, release)
        env_frames = np.clip(env_frames, 0.0, 1.0)

        # -------- Breath dips: mask MID-PHRASE moves only (never cold entries)
        key_dip_depth = np.clip(self._float(p, "key_dip_depth", 0.15), 0.0, 0.6)
        step_dip_depth = np.clip(self._float(p, "step_dip_depth", 0.30), 0.0, 0.7)

        pre_level = np.empty_like(env_frames)
        pre_level[0] = 0.0
        pre_level[1:] = env_frames[:-1]
        pre_level = self._smooth_onepole(pre_level, frame_rate, 0.06)
        dip_gate = np.clip(pre_level / 0.25, 0.0, 1.0)

        if key_dip_depth > 0.0:
            key_change = np.abs(np.diff(quantized, prepend=quantized[0])) > 0.4
            dip = gaussian_filter1d(
                key_change.astype(float),
                sigma=max(1.0, frame_rate * (self._float(p, "key_dip_ms", 50.0) / 1000.0) / 3.0)
            )
            dip_max = float(np.max(dip))
            if dip_max > 0:
                shaped = np.clip(dip / dip_max, 0.0, 1.0) * dip_gate
                env_frames *= (1.0 - key_dip_depth * shaped)

        if step_dip_depth > 0.0:
            dip = gaussian_filter1d(
                large_mask.astype(float),
                sigma=max(1.0, frame_rate * (self._float(p, "step_dip_ms", 80.0) / 1000.0) / 3.0)
            )
            dip_max = float(np.max(dip))
            if dip_max > 0:
                shaped = np.clip(dip / dip_max, 0.0, 1.0) * dip_gate
                env_frames *= (1.0 - step_dip_depth * shaped)

        # Accompanist reaction delay: enter slightly AFTER the voice.
        delay_frames = int(round((self._float(p, "entry_delay_ms", 25.0) / 1000.0) * frame_rate))
        if 0 < delay_frames < len(env_frames):
            env_frames = np.concatenate([np.zeros(delay_frames), env_frames[:-delay_frames]])

        # ---------------- Synthesis setup ----------------
        pitch_ratio = 2.0 ** (pitch_shift_cents / 1200.0)

        max_f = min(max(60.0, float(np.max(freq_frames)) * pitch_ratio), sr * 0.45)
        max_h = int(min(15, max(1, int((sr * 0.5) / max_f))))
        if max_h % 2 == 0:
            max_h -= 1

        odd_h = np.arange(1, max_h + 1, 2, dtype=int)
        even_h = np.arange(2, max_h + 1, 2, dtype=int)

        woodiness = np.clip(self._float(p, "woodiness", 0.6), 0.0, 1.0)
        exponent = 0.85 + woodiness * 1.75

        odd_weights = 1.0 / np.power(odd_h.astype(float), exponent)
        even_weights = 0.12 / np.power(even_h.astype(float), exponent) if len(even_h) else np.array([])

        turb = np.clip(self._float(p, "turbulence", 0.10), 0.0, 1.0)
        vib_rate = self._float(p, "vibrato_rate_hz", 5.2)
        vib_depth = self._float(p, "vibrato_depth_cents", 8.0)
        gamaka_amount = np.clip(self._float(p, "gamaka_amount", 0.55), 0.0, 1.0)

        two_pi = 2.0 * np.pi
        phase_offset = 0.0
        chunk_size = 65536
        rng = np.random.default_rng(2026)

        # ---------------- Chunked additive synthesis ----------------
        for start in range(0, n_samples, chunk_size):
            end = min(n_samples, start + chunk_size)
            chunk_len = end - start

            t = np.arange(start, end, dtype=np.float64) / float(sr)

            f = np.interp(t, times, freq_frames).astype(np.float64)
            env = np.interp(t, times, env_frames).astype(np.float32)

            f *= pitch_ratio

            if float(np.max(env)) < 0.004:
                phase_offset = (phase_offset + two_pi * float(np.sum(f / sr))) % two_pi
                continue

            # Vibrato / gamaka-like modulation, gated by the envelope.
            vib_env = np.clip((env - 0.2) * 3.0, 0.0, 1.0)
            cents_mod = np.zeros_like(f, dtype=np.float64)

            if vib_depth > 0.0:
                cents_mod += vib_depth * np.sin(two_pi * vib_rate * t) * vib_env

            if gamaka_amount > 0.0:
                g_rate = 4.2 + 1.3 * np.sin(two_pi * 0.12 * t)
                g_phase = two_pi * g_rate * t + 0.75 * np.sin(two_pi * 0.23 * t)
                cents_mod += (gamaka_amount * 22.0) * np.sin(g_phase) * vib_env

            if np.any(cents_mod):
                f *= np.power(2.0, cents_mod / 1200.0)

            f = np.clip(f, 25.0, sr * 0.48)

            phase = phase_offset + two_pi * np.cumsum(f / float(sr))
            phase_offset = float(phase[-1] % two_pi)

            sig = np.zeros(chunk_len, dtype=np.float32)

            # Odd harmonics: clarinet-like core.
            for h, w in zip(odd_h, odd_weights):
                sig += (w * np.sin(h * phase)).astype(np.float32)

            # Small even harmonics for reed/wood realism.
            for h, w in zip(even_h, even_weights):
                sig += (w * np.sin(h * phase)).astype(np.float32)

            # Breath noise / turbulence (low-passed, gentle).
            if turb > 0.0:
                noise = rng.standard_normal(chunk_len).astype(np.float32)
                noise = (noise + np.roll(noise, 1) + np.roll(noise, 2)) / 3.0
                noise_amt = turb * (0.02 + 0.09 * breath_sens)
                breath_curve = 0.7 + 0.6 * (1.0 - env)
                sig += noise * env * noise_amt * breath_curve

            # Amplitude envelope.
            sig *= env * 0.40

            # Soft reed-like saturation.
            drive = 0.9 + 0.4 * breath_sens
            sig = np.tanh(sig * drive).astype(np.float32)

            out[start:end] = sig

        # ---------------- Offset, fades, volume ----------------
        offset_ms = self._float(p, "time_offset_ms", 0.0)
        offset_samples = int(round((offset_ms / 1000.0) * sr))

        if offset_samples > 0:
            out = np.roll(out, offset_samples)
            out[:offset_samples] = 0.0
        elif offset_samples < 0:
            out = np.roll(out, offset_samples)
            out[offset_samples:] = 0.0

        fade_len = min(int(0.02 * sr), n_samples // 3)
        if fade_len > 1:
            out[:fade_len] *= np.linspace(0.0, 1.0, fade_len, dtype=np.float32)
            out[-fade_len:] *= np.linspace(1.0, 0.0, fade_len, dtype=np.float32)

        out *= volume * 0.55

        peak = float(np.max(np.abs(out))) if n_samples else 0.0
        if peak > 0.95:
            out *= 0.95 / peak

        return out.astype(np.float32)

    # ------------------------------------------------------------------
    # NO-ZOOM pitch curve builder (same logic as the harmonium)
    # ------------------------------------------------------------------
    def _build_pitch_curve(
        self,
        key_cents,
        continuous_cents,
        follow_amount,
        max_dev_cents,
        frame_rate,
        glide_tau,
        large_thresh_cents,
    ):
        key_cents = np.asarray(key_cents, dtype=float)
        continuous_cents = np.asarray(continuous_cents, dtype=float)

        # Clamped microtone deviation around the locked key.
        dev = np.clip(continuous_cents - key_cents, -max_dev_cents, max_dev_cents)
        dev_smooth = self._smooth_onepole(dev, frame_rate, 0.05)

        n = len(key_cents)
        out = np.empty(n, dtype=float)
        large_mask = np.zeros(n, dtype=bool)

        alpha = 1.0 - float(np.exp(-1.0 / (max(1.0, frame_rate) * max(0.005, glide_tau))))

        prev = float(key_cents[0])

        for i in range(n):
            target = float(key_cents[i])
            diff = target - prev

            if abs(diff) > large_thresh_cents:
                prev = target
                large_mask[i] = True
            else:
                prev += alpha * diff

            out[i] = prev

        final_cents = out + follow_amount * dev_smooth

        return final_cents, large_mask

    # ------------------------------------------------------------------
    # Control-frame preparation (HOLD fill — no bridges across pauses)
    # ------------------------------------------------------------------
    def _prepare_frames(self, frequencies, confidences, pitch_times, duration, conf_threshold):
        if frequencies is None or len(frequencies) == 0:
            return None

        freqs = np.asarray(frequencies, dtype=float)
        confs = np.ones_like(freqs) if confidences is None else np.asarray(confidences, dtype=float)

        common_len = min(len(freqs), len(confs))
        freqs = freqs[:common_len]
        confs = confs[:common_len]
        m = len(freqs)

        if m == 0:
            return None

        if pitch_times is None or len(pitch_times) < m:
            times = np.arange(m, dtype=float) / 100.0
        else:
            times = np.asarray(pitch_times[:m], dtype=float)

        times = np.maximum(times, 0.0)

        if len(times) > 1:
            times = np.maximum.accumulate(times)
            dt = np.where(np.diff(times) > 1e-6, np.diff(times), 1e-3)
            times = np.concatenate(([times[0]], times[0] + np.cumsum(dt)))
        else:
            times = np.array([0.0, max(float(duration), 0.01)], dtype=float)
            freqs = np.array([freqs[0], freqs[0]], dtype=float)
            confs = np.array([confs[0], confs[0]], dtype=float)
            m = 2

        dt = np.diff(times)
        dt = dt[dt > 0]
        frame_rate = float(np.clip(1.0 / float(np.median(dt)), 20.0, 200.0)) if len(dt) else 100.0

        freqs = np.nan_to_num(freqs, nan=0.0, posinf=0.0, neginf=0.0)
        confs = np.clip(np.nan_to_num(confs, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

        # Octave jitter correction.
        if m >= 5:
            win = min(15, m if m % 2 == 1 else m - 1)
            if win >= 3:
                rolling = median_filter(freqs, size=win)
                glitch = (freqs > rolling * 1.45) | (freqs < rolling * 0.65)
                freqs = freqs.copy()
                freqs[glitch] = rolling[glitch]

        valid_pitch = (freqs > 40.0) & (freqs < 5000.0)
        if not np.any(valid_pitch):
            return None

        # HOLD the last voiced pitch across pauses (no racing bridges).
        valid_idx = np.where(valid_pitch)[0]
        filled = np.full(m, freqs[valid_idx[0]], dtype=float)

        last = freqs[valid_idx[0]]
        for i in range(m):
            if valid_pitch[i]:
                last = freqs[i]
            filled[i] = last

        voiced = valid_pitch & (confs >= conf_threshold)
        if not np.any(voiced):
            voiced = valid_pitch
        if not np.any(voiced):
            return None
        # NEW: kill octave flips at phrase ENDS (voice breaking into breath),
        # so the held pause pitch stays on the true last note (no racing).
        filled = self._stabilize_phrase_ends(filled, times, voiced, frame_rate)

        conf_valid = confs > 0.01
        if np.any(conf_valid):
            conf_filled = np.interp(np.arange(m), np.where(conf_valid)[0], confs[conf_valid])
        else:
            conf_filled = np.full(m, 0.5, dtype=float)

        return times, filled, voiced, conf_filled, frame_rate

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _vocal_rms_frames(self, vocal_audio, sr, times):
        if vocal_audio is None or len(vocal_audio) == 0:
            return None

        v = np.asarray(vocal_audio, dtype=np.float32)
        if v.ndim > 1:
            v = np.mean(v, axis=1)
        if len(v) == 0:
            return None

        window = max(16, int(sr * 0.05))
        rms = np.sqrt(np.maximum(0.0, uniform_filter1d(v.astype(np.float64) ** 2, size=window)))

        rms_frames = np.interp(times, np.arange(len(rms)) / float(sr), rms)

        max_rms = float(np.max(rms_frames))
        if max_rms > 0:
            rms_frames /= max_rms

        return rms_frames

    @staticmethod
    def _hold_gaps(v, frame_rate, min_hold_s):
        held = v.copy()
        hold_frames = int(max(0.0, min_hold_s) * frame_rate)

        run_start = None
        for i in range(len(v)):
            if v[i] > 0.5:
                if run_start is not None and run_start > 0 and (i - run_start) <= hold_frames:
                    held[run_start:i] = 1.0
                run_start = None
            else:
                if run_start is None:
                    run_start = i

        return held

    @staticmethod
    def _stabilize_phrase_ends(freqs, times, voiced, frame_rate,
                             lookback_s=0.35, anchor_s=0.6):
        """At each voiced->silence transition, replace trailing frames that
        jump ~an octave away from the stable anchor with the anchor itself."""
        out = freqs.copy()
        n = len(out)
        lb = max(2, int(lookback_s * frame_rate))   # suspect window before the end
        an = max(3, int(anchor_s * frame_rate))     # stable anchor before that

        for i in range(1, n):
            if voiced[i - 1] and not voiced[i]:     # phrase end
                i_b = max(0, i - lb)
                i_a = max(0, i_b - an)
                if i_b <= i_a:
                    continue
                anchor = float(np.median(out[i_a:i_b]))
                if anchor <= 0:
                    continue
                for j in range(i_b, i):
                    if out[j] > 1.5 * anchor or out[j] < 0.66 * anchor:
                        out[j] = anchor
        return out

    @staticmethod
    def _hysteresis_quantize(semitones, hysteresis):
        out = np.zeros_like(semitones, dtype=float)
        if len(semitones) == 0:
            return out

        h = max(0.05, float(hysteresis))
        current = float(np.round(semitones[0]))

        for i in range(len(semitones)):
            if abs(semitones[i] - current) > h:
                current = float(np.round(semitones[i]))
            out[i] = current

        return out

    @staticmethod
    def _smooth_onepole(values, frame_rate, tau):
        values = np.asarray(values, dtype=float)
        if len(values) == 0:
            return values

        alpha = 1.0 - float(np.exp(-1.0 / (max(1.0, frame_rate) * max(0.001, tau))))

        out = np.empty_like(values)
        y = float(values[0])
        for i in range(len(values)):
            y += alpha * (float(values[i]) - y)
            out[i] = y

        return out

    @staticmethod
    def _smooth_env(values, frame_rate, attack, release):
        values = np.asarray(values, dtype=float)
        if len(values) == 0:
            return values

        frame_rate = max(1.0, float(frame_rate))

        out = np.empty_like(values)
        current = 0.0

        for i in range(len(values)):
            target = float(values[i])
            tau = max(0.001, attack) if target > current else max(0.001, release)
            alpha = 1.0 - float(np.exp(-1.0 / (frame_rate * tau)))
            current += alpha * (target - current)
            out[i] = current

        return out