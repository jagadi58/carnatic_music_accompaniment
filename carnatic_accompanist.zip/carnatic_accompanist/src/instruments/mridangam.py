#!/usr/bin/env python3
"""
Mridangam Instrument — Carnatic accompanist edition (final).

- Stroke vocabulary tha/dhi/ka/thom/gumki/nam with humanized timing/velocity.
- Tala-aware groove (eduppu accents, subdivision, cycle-end korvai).
- Vocal responsiveness: ducks under lines, answers gaps, echoes syllables.
- AUTO TEMPO LOCK: estimates the singer's real pulse when the given BPM
  disagrees (the 120 BPM placeholder problem).
- pause_duck ("Rest Silence"): strokes fade to silence during vocal pauses.
- Breath-gated: the singer's breaths never trigger strokes.
- Manual BPM/aksharas override + adaptive mode for low tala confidence.
"""
import numpy as np
from typing import Dict, Any, Optional


class Mridangam:
    """Expressive mridangam accompaniment generator."""

    def __init__(self):
        self.name = "Mridangam"

    def get_default_params(self) -> Dict[str, Any]:
        return {
            "volume": 0.6,
            "pitch_shift_cents": 0.0,
            "time_offset_ms": 0.0,
            "tempo_multiplier": 1.0,

            "decay_rate": 5.0,
            "skin_tightness": 0.70,
            "bass_freq": 70.0,

            "groove_density": 0.55,
            "phrase_fills": 0.60,
            "vocal_follow": 0.60,
            "duck_depth": 0.55,
            "pause_duck": 1.0,          # Rest Silence: silent in vocal pauses
            "humanize_ms": 8.0,
            "velocity_var": 0.15,

            "auto_tempo": 1.0,
            "rhythm_mode": "auto",      # auto | manual
            "bpm_override": 0.0,
            "aksharas_override": 0,
            "tala_confidence": 1.0,
        }

    @staticmethod
    def _float(params, key, default):
        try:
            if key not in params or params[key] is None:
                return default
            return float(params[key])
        except Exception:
            return default

    @staticmethod
    def _int(params, key, default):
        try:
            if key not in params or params[key] is None:
                return default
            return int(params[key])
        except Exception:
            return default

    @staticmethod
    def _string(params, key, default):
        try:
            value = params.get(key, default)
            if value is None:
                return default
            return str(value).lower().replace(" ", "_")
        except Exception:
            return default

    # ------------------------------------------------------------------
    def generate(
        self,
        duration: float,
        sr: int,
        params: Dict[str, Any],
        bpm: float = 120.0,
        aksharas: int = 8,
        vocal_audio: Optional[np.ndarray] = None,
        sruti_freq: Optional[float] = None,
        **kwargs
    ) -> np.ndarray:
        p = self.get_default_params()
        p.update(params or {})

        total_samples = int(max(0.0, duration) * sr)
        out = np.zeros(total_samples, dtype=np.float32)

        if total_samples == 0:
            return out

        volume = self._float(p, "volume", 0.6)
        if volume <= 0.0:
            return out

        # ---------------- Tempo / aksharas resolution + AUTO TEMPO LOCK ----
        rhythm_mode = self._string(p, "rhythm_mode", "auto")
        bpm_ov = self._float(p, "bpm_override", 0.0)
        akh_ov = self._int(p, "aksharas_override", 0)
        tala_conf = self._float(p, "tala_confidence", 1.0)
        auto_tempo = self._float(p, "auto_tempo", 1.0)

        use_akh = akh_ov if (rhythm_mode == "manual" and akh_ov > 0) else max(1, int(aksharas))

        est_bpm = None
        if vocal_audio is not None and auto_tempo > 0.5 and rhythm_mode != "manual":
            est = self._estimate_beat_seconds(vocal_audio, sr)
            if est:
                est_bpm = 60.0 / est
                while est_bpm < 55.0:
                    est_bpm *= 2.0
                while est_bpm > 140.0:
                    est_bpm /= 2.0

        if rhythm_mode == "manual" and bpm_ov > 0:
            bpm_eff = bpm_ov
            adaptive = False
        else:
            bpm_eff = max(30.0, float(bpm) * self._float(p, "tempo_multiplier", 1.0))
            adaptive = (tala_conf < 0.5)
            if est_bpm is not None:
                if adaptive:
                    bpm_eff = est_bpm
                elif abs(est_bpm - bpm_eff) / max(1.0, bpm_eff) > 0.12:
                    bpm_eff = est_bpm

        print(f"[mridangam] grid: given={float(bpm):.0f} BPM, "
              f"estimated={est_bpm if est_bpm else 0:.0f} BPM, "
              f"using={bpm_eff:.0f} BPM, aksharas={use_akh}")

        beat = 60.0 / bpm_eff

        pitch_ratio = 2.0 ** (self._float(p, "pitch_shift_cents", 0.0) / 1200.0)
        f_right = (sruti_freq if sruti_freq and sruti_freq > 0 else 261.63) * pitch_ratio
        f_left = self._float(p, "bass_freq", 70.0) * pitch_ratio

        tight = np.clip(self._float(p, "skin_tightness", 0.70), 0.0, 1.0)
        decay_rate = max(0.5, self._float(p, "decay_rate", 5.0))
        density = np.clip(self._float(p, "groove_density", 0.55), 0.0, 1.0)
        fills = np.clip(self._float(p, "phrase_fills", 0.60), 0.0, 1.0)
        follow = np.clip(self._float(p, "vocal_follow", 0.60), 0.0, 1.0)
        duck_depth = np.clip(self._float(p, "duck_depth", 0.55), 0.0, 0.9)
        pause_duck = np.clip(self._float(p, "pause_duck", 1.0), 0.0, 1.0)
        humanize = self._float(p, "humanize_ms", 8.0)
        vel_var = np.clip(self._float(p, "velocity_var", 0.15), 0.0, 0.5)

        rng = np.random.default_rng(7)

        # ---------------- Vocal analysis (breath-gated) ----------------
        rms_t, rms = None, None
        if vocal_audio is not None and len(vocal_audio) > 0:
            rms_t, rms = self._vocal_rms(vocal_audio, sr)
            try:
                from src.core.breath_detector import breath_quality
                q = breath_quality(vocal_audio, sr, rms_t)
                rms = rms * np.where(q > 0.3, 1.0, 0.15)   # breaths = near-silence
            except Exception:
                pass

        def vocal_level(tt):
            if rms is None:
                return 0.0
            return float(np.interp(tt, rms_t, rms))

        def presence_at(tt):
            if pause_duck <= 0.0 or rms is None:
                return 1.0
            r = vocal_level(tt)
            gate = min(1.0, max(0.0, (r - 0.08) / 0.12))
            return 1.0 - pause_duck * (1.0 - gate)

        # ---------------- Groove grid (breathes with the vocal) ------------
        events = []   # (time, stroke_type, velocity)

        sub = 2 if bpm_eff < 95.0 else 1
        n_beats = int(duration / beat)

        for b in range(n_beats):
            tb = b * beat
            pos = b % use_akh
            r = vocal_level(tb)
            presence = presence_at(tb)

            if adaptive:
                if b % 4 == 0:
                    st, v0 = "tha", 0.85
                else:
                    st, v0 = ("tha" if b % 2 == 0 else "dhi"), 0.5 + 0.15 * rng.random()
            elif pos == 0:
                st, v0 = "tha", 1.0
            elif pos == use_akh // 2:
                st, v0 = "thom", 0.85
            else:
                st = "tha" if (b % 2) == 0 else "dhi"
                v0 = 0.60 + 0.20 * rng.random()

            v0 *= (1.0 - duck_depth * follow * r) * presence
            events.append((tb, st, v0))

            off_p = (0.25 + 0.50 * density) * (1.0 - 0.65 * min(1.0, r * 1.5))
            if sub == 2 and rng.random() < off_p:
                events.append((tb + beat / 2.0, "ka",
                               (0.30 + 0.30 * rng.random()) * (1.0 - 0.5 * r) * presence))

            if r < 0.15 and rng.random() < (0.25 + 0.40 * density):
                events.append((tb + 0.5 * beat,
                               "dhi" if rng.random() < 0.5 else "ka",
                               (0.35 + 0.15 * rng.random()) * presence))

            if (not adaptive) and pos == use_akh - 1 and rng.random() < (0.30 + 0.60 * fills):
                for k in range(4):
                    events.append((tb + k * beat / 4.0,
                                   "ka" if k < 3 else "tha",
                                   (0.30 + 0.13 * k) * (1.0 - 0.4 * r) * presence))

        # ---------------- Phrase answers & syllable echoes -----------------
        if rms is not None:
            for pe in self._phrase_ends(rms_t, rms):
                if rng.random() < (0.40 + 0.60 * fills):
                    events.append((pe + 0.03, "gumki",
                                   (0.55 + 0.20 * rng.random()) * presence_at(pe)))

            for o in self._vocal_onsets(rms_t, rms):
                if rng.random() < 0.50 * follow:
                    events.append((o + 0.02, "ka",
                                   (0.28 + 0.18 * rng.random()) * presence_at(o)))

        # ---------------- Humanize + render ----------------
        for tt, st, vel in events:
            if tt >= duration - 0.02 or vel <= 0.01:
                continue

            tt += rng.uniform(-1.0, 1.0) * humanize / 1000.0
            tt = max(0.0, tt)

            vel *= rng.uniform(1.0 - vel_var, 1.0 + vel_var)
            vel = min(1.2, vel)

            buf = self._stroke_buffer(st, sr, f_right, f_left, tight, vel, decay_rate, rng)

            s0 = int(tt * sr)
            e0 = min(total_samples, s0 + len(buf))
            if e0 > s0:
                out[s0:e0] += buf[:e0 - s0]

        # ---------------- Post ----------------
        out = np.tanh(out * 1.2).astype(np.float32)

        offset_samples = int(round((self._float(p, "time_offset_ms", 0.0) / 1000.0) * sr))
        if offset_samples > 0:
            out = np.roll(out, offset_samples)
            out[:offset_samples] = 0.0
        elif offset_samples < 0:
            out = np.roll(out, offset_samples)
            out[offset_samples:] = 0.0

        fade_len = min(int(0.02 * sr), total_samples // 3)
        if fade_len > 1:
            out[:fade_len] *= np.linspace(0.0, 1.0, fade_len, dtype=np.float32)
            out[-fade_len:] *= np.linspace(1.0, 0.0, fade_len, dtype=np.float32)

        out *= volume * 0.9

        peak = float(np.max(np.abs(out))) if total_samples else 0.0
        if peak > 0.95:
            out *= 0.95 / peak

        return out.astype(np.float32)

    # ------------------------------------------------------------------
    def _stroke_buffer(self, stype, sr, f_r, f_l, tight, vel, decay_rate, rng):
        R = {
            "tha":  (0.30, [(1, 1.0), (2.0, 0.55), (2.8, 0.35), (3.9, 0.22)], "right", 0.35, 0.020, 0.94, 1.3, 0.001),
            "dhi":  (0.45, [(1, 1.0), (1.5, 0.45), (2.2, 0.25)],              "right", 0.15, 0.015, 0.97, 0.9, 0.002),
            "ka":   (0.12, [(2.5, 0.4), (3.5, 0.2)],                          "right", 0.60, 0.030, 1.00, 2.2, 0.001),
            "thom": (0.55, [(1, 1.0), (2.0, 0.25)],                           "both",  0.10, 0.010, 0.90, 0.7, 0.003),
            "gumki":(0.60, [(1, 0.9), (1.5, 0.2)],                            "left",  0.05, 0.010, 0.72, 0.6, 0.010),
            "nam":  (0.40, [(1, 0.7)],                                        "left",  0.05, 0.010, 0.90, 0.8, 0.004),
        }
        dur, partials, head, noise_amt, nlen, glide, dec_mul, atk = R.get(stype, R["dhi"])

        n = max(16, int(dur * sr))
        t = np.arange(n, dtype=np.float64) / sr

        sig = np.zeros(n, dtype=np.float64)

        if head == "both":
            glide_l = f_l * (1.0 - (1.0 - glide) * (t / dur))
            sig += 0.9 * np.sin(2.0 * np.pi * np.cumsum(glide_l) / sr)
            f_inst = f_r * (1.0 - (1.0 - glide) * (t / dur))
            phase = 2.0 * np.pi * np.cumsum(f_inst) / sr
            for ratio, amp in partials[1:]:
                sig += amp * np.sin(ratio * phase)
        else:
            f0 = f_r if head == "right" else f_l
            f_inst = f0 * (1.0 - (1.0 - glide) * (t / dur))
            phase = 2.0 * np.pi * np.cumsum(f_inst) / sr
            for ratio, amp in partials:
                a = amp
                if ratio > 2.0:
                    a *= (0.6 + 0.8 * tight)
                sig += a * np.sin(ratio * phase)

        nz = rng.standard_normal(n) * np.exp(-t / max(1e-3, nlen))
        sig += nz * noise_amt * (0.5 + tight)

        env = np.exp(-decay_rate * dec_mul * t) * vel
        att = max(1, int(atk * sr))
        if att < n:
            env[:att] *= np.linspace(0.0, 1.0, att)

        sig *= env

        return (sig * 0.5).astype(np.float32)

    # ------------------------------------------------------------------
    @staticmethod
    def _vocal_rms(vocal_audio, sr, hop_s=0.05):
        v = np.asarray(vocal_audio, dtype=np.float64)
        if v.ndim > 1:
            v = np.mean(v, axis=1)

        hop = max(16, int(hop_s * sr))
        nfr = max(1, len(v) // hop)

        rms = np.zeros(nfr)
        for i in range(nfr):
            seg = v[i * hop:(i + 1) * hop]
            rms[i] = np.sqrt(np.mean(seg ** 2)) if len(seg) else 0.0

        mx = float(np.max(rms))
        if mx > 0:
            rms /= mx

        times = (np.arange(nfr) + 0.5) * hop_s
        return times, rms

    @staticmethod
    def _phrase_ends(rms_t, rms, hop_s=0.05):
        active = rms > 0.18
        ends = []
        i, n = 0, len(active)
        min_run = int(0.25 / hop_s)

        while i < n:
            if active[i]:
                j = i
                while j < n and active[j]:
                    j += 1
                if (j - i) >= min_run and j < n:
                    ends.append(float(rms_t[j]))
                i = j
            else:
                i += 1
        return ends

    @staticmethod
    def _vocal_onsets(rms_t, rms):
        active = rms > 0.18
        return [float(rms_t[i]) for i in range(1, len(active)) if active[i] and not active[i - 1]]

    @staticmethod
    def _estimate_beat_seconds(vocal_audio, sr):
        if vocal_audio is None or len(vocal_audio) == 0:
            return None

        v = np.asarray(vocal_audio, dtype=np.float64)
        if v.ndim > 1:
            v = np.mean(v, axis=1)

        hop = max(16, int(0.05 * sr))
        nfr = len(v) // hop
        if nfr < 80:
            return None

        rms = np.array([np.sqrt(np.mean(v[i * hop:(i + 1) * hop] ** 2)) for i in range(nfr)])
        ons = np.clip(np.diff(rms, prepend=rms[0]), 0.0, None)
        ons = ons - np.mean(ons)

        min_lag = int(0.30 / 0.05)
        max_lag = min(int(1.20 / 0.05), nfr // 2)

        best_lag, best_corr = None, 0.0
        for lag in range(min_lag, max_lag):
            c = float(np.dot(ons[lag:], ons[:-lag]))
            if c > best_corr:
                best_corr, best_lag = c, lag

        return (best_lag * 0.05) if best_lag else None