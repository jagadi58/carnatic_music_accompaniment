#!/usr/bin/env python3
"""
Abstract base class for all Carnatic instruments.
"""

from abc import ABC, abstractmethod
import numpy as np
from typing import Dict, Any

class BaseInstrument(ABC):
    """Abstract base class defining the interface for instrument generation."""
    
    def __init__(self, name: str):
        self.name = name
        self.default_params = self.get_default_params()
    
    @abstractmethod
    def get_default_params(self) -> Dict[str, Any]:
        """Return default parameters for this instrument."""
        pass
    
    @abstractmethod
    def generate(
        self, 
        duration: float, 
        sr: int, 
        params: Dict[str, Any],
        **kwargs
    ) -> np.ndarray:
        """
        Generate the instrument audio.
        
        Args:
            duration: Length of audio to generate in seconds
            sr: Sample rate
            params: Dictionary of parameters (volume, pitch_shift, tempo, etc.)
            **kwargs: Instrument-specific arguments (e.g., sruti_freq, swara_sequence)
            
        Returns:
            Numpy array of audio samples (mono, float32, normalized to [-1, 1])
        """
        pass
    
    def apply_volume(self, audio: np.ndarray, volume: float) -> np.ndarray:
        """Apply volume scaling (0.0 to 1.0)."""
        return audio * np.clip(volume, 0.0, 1.0)
    
    def apply_pitch_shift(self, freq: float, pitch_shift_cents: float) -> float:
        """Calculate new frequency after pitch shift in cents."""
        return freq * (2.0 ** (pitch_shift_cents / 1200.0))