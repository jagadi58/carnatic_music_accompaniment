#!/usr/bin/env python3
"""
Harmonium Instrument — FINAL merged edition.

Everything included:
1. Original signal path: acoustic harmonic profiling, hysteresis Swara Lock,
   octave jitter correction, octave shift, tremolo, time offset, limiter.
2. Expressive layer: expression modes, pitch follow, meend glide, gamaka,
   bellows attack/release, reed detune/blend, air noise, key click,
   dynamic brightness.
3. Smooth-phrase fix: pitch is HELD across vocal pauses (no racing bridges),
   causal envelope, accompanist entry delay, gap hold.
4. No-zoom fix: microtone follow is clamped around the locked key; small
   intervals glide; large intervals STEP with a bellows dip (no siren sweep).
5. Anti-spike fix: hard vocal-presence gate (silent singer = silent reeds),
   proportional dynamics (rms_contrast), bellows dips on key moves,
   softened click/air noise, slower re-attack.
"""

import numpy as np
from typing import Dict, Any, Optional

from scipy.ndimage import (
    gaussian_filter1d,
    uniform_filter1d,
    median_filter
)


class Harmonium:
    """Expressive, phrase-aware harmonium accompaniment generator."""

    def __init__(self):
        self.name = "Harmonium"

        # Measured acoustic harmonic profile of a real harmonium reed set.
        self.acoustic_profile = np.array(
            [
                0.993, 0.671, 0.272, 0.688, 0.226,
                0.953, 0.100, 0.259, 0.056, 0.341,
                0.048, 0.124, 0.023, 0.234, 0.010
            ],
            dtype=np.float64
        )

    # ------------------------------------------------------------------
    # Parameters
    # ------------------------------------------------------------------
    def get_default_params(self) -> Dict[str, Any]:
        return {
            # --- Basic (original) ---
            "volume": 0.6,
            "pitch_shift_cents": 0.0,
            "confidence_threshold": 0.45,
            "time_offset_ms": 0.0,
            "brightness": 0.5,
            "hysteresis_semitones": 0.6,
            "tremolo_rate_hz": 4.0,
            "tremolo_depth": 0.025,
            "octave_shift": 0,

            # --- Expression ---
            "expression_mode": "meend",        # strict_keys | meend | shadow_vocal
            "pitch_follow": 0.35,
            "meend_glide_ms": 70.0,

            # --- NO-ZOOM controls ---
            "max_follow_dev_cents": 60.0,      # vocal may pull only this far
                                               # away from the locked key
            "max_gliss_semitones": 2.0,        # <= glides; larger steps
            "step_dip_depth": 0.35,            # bellows dip on large steps
            "step_dip_ms": 90.0,

            # --- Gamaka ---
            "gamaka_amount": 0.45,
            "gamaka_rate_hz": 5.5,
            "gamaka_depth_cents": 12.0,

            # --- Bellows / phrasing ---
            "bellows_sensitivity": 0.70,
            "bellows_attack_ms": 90.0,         # soft re-attack (anti-spike)
            "bellows_release_ms": 220.0,
            "entry_delay_ms": 35.0,            # accompanist reaction delay
            "gap_hold_ms": 150.0,              # short gaps stay legato

            # --- Realism noises (kept low: they create fake onset spikes) ---
            "reed_detune_cents": 4.0,
            "reed_blend": 0.50,
            "air_noise": 0.06,
            "key_click": 0.05,
            "key_dip_depth": 0.20,             # bellows ease on small moves
            "key_dip_ms": 60.0,
            "dynamic_brightness": 0.55,
            "rms_contrast": 0.7,               # dynamics follow vocal accents
        }

    # ------------------------------------------------------------------
    # Safe parameter readers
    # ------------------------------------------------------------------
    @staticmethod
    def _float(params: Dict[str, Any], key: str, default: float) -> float:
        try:
            if key not in params or params[key] is None:
                return default
            return float(params[key])
        except Exception:
            return default

    @staticmethod
    def _int(params: Dict[str, Any], key: str, default: int) -> int:
        try:
            if key not in params or params[key] is None:
                return default
            return int(params[key])
        except Exception:
            return default

    @staticmethod
    def _string(params: Dict[str, Any], key: str, default: str) -> str:
        try:
            value = params.get(key, default)
            if value is None:
                return default
            return str(value).lower().replace(" ", "_")
        except Exception:
            return default

    # ------------------------------------------------------------------
    # Main generation
    # ------------------------------------------------------------------
    def generate(
        self,
        duration: float,
        sr: int,
        params: Dict[str, Any],
        frequencies: Optional[np.ndarray] = None,
        confidences: Optional[np.ndarray] = None,
        pitch_times: Optional[np.ndarray] = None,
        sruti_freq: float = 261.63,
        vocal_audio: Optional[np.ndarray] = None,
        **kwargs
    ) -> np.ndarray:
        """Generate harmonium accompaniment. Returns mono float32 audio."""
        p = self.get_default_params()
        p.update(params or {})

        total_samples = int(max(0.0, duration) * sr)
        out = np.zeros(total_samples, dtype=np.float32)

        if total_samples == 0:
            return out

        volume = self._float(p, "volume", 0.6)
        if volume <= 0.0:
            return out

        conf_thresh = self._float(p, "confidence_threshold", 0.45)
        rms_contrast = np.clip(self._float(p, "rms_contrast", 0.7), 0.3, 1.0)

        prepared = self._prepare_frames(
            frequencies=frequencies,
            confidences=confidences,
            pitch_times=pitch_times,
            duration=duration,
            conf_threshold=conf_thresh,
        )

        if prepared is None:
            return out

        times, filled_freqs, voiced_raw, conf_filled, frame_rate = prepared

        # ---------------- Original: manual octave shifting ----------------
        octave_shift = self._int(p, "octave_shift", 0)
        pitch_shift_cents = self._float(p, "pitch_shift_cents", 0.0)

        base_sruti = sruti_freq if sruti_freq and sruti_freq > 0 else 261.63
        base_sruti = max(20.0, float(base_sruti))

        sruti = base_sruti * (2.0 ** octave_shift)
        freqs_oct = filled_freqs * (2.0 ** octave_shift)

        # ---------------- Original: hysteresis Swara Lock ----------------
        hysteresis = self._float(p, "hysteresis_semitones", 0.6)

        semitones = 12.0 * np.log2(np.maximum(freqs_oct, 10.0) / sruti)
        quantized = self._hysteresis_quantize(semitones, hysteresis)

        if len(quantized) >= 3:
            quantized = median_filter(quantized, size=3)

        key_cents = quantized * 100.0
        continuous_cents = 1200.0 * np.log2(np.maximum(freqs_oct, 10.0) / sruti)

        # ---------------- Expression mode / pitch follow ----------------
        expression_mode = self._string(p, "expression_mode", "meend")
        pitch_follow = np.clip(self._float(p, "pitch_follow", 0.35), 0.0, 1.0)

        if expression_mode == "strict_keys":
            follow_amount = 0.0
        elif expression_mode == "shadow_vocal":
            follow_amount = max(pitch_follow, 0.65)
        else:
            follow_amount = pitch_follow

        glide_ms = self._float(p, "meend_glide_ms", 70.0)

        # Even in strict mode, never jump faster than ~30 ms: instant key
        # jumps are hard spectral transients the onset detector reads as
        # giant beats.
        glide_tau = (
            0.030
            if expression_mode == "strict_keys"
            else max(0.030, glide_ms / 1000.0)
        )

        # ---------------- NO-ZOOM pitch curve ----------------
        final_cents, large_mask = self._build_pitch_curve(
            key_cents=key_cents,
            continuous_cents=continuous_cents,
            follow_amount=follow_amount,
            max_dev_cents=self._float(p, "max_follow_dev_cents", 60.0),
            frame_rate=frame_rate,
            glide_tau=glide_tau,
            large_thresh_cents=self._float(p, "max_gliss_semitones", 2.0) * 100.0,
        )

        freq_frames = sruti * np.power(2.0, final_cents / 1200.0)

        # ---------------- Causal phrase envelope ----------------
        
        rms_frames = self._vocal_rms_frames(vocal_audio, sr, times)

        # NEW: breath-proof gate. A breath has ENERGY but weak harmonics, so
        # neither the RMS presence gate nor raw CREPE confidence can catch it.
        # Zero the voiced mask wherever harmonic content is low.
        if vocal_audio is not None and len(vocal_audio) > 0:
            try:
                from src.core.breath_detector import breath_quality
                q = breath_quality(vocal_audio, sr, times)
                voiced_raw = voiced_raw * (q > 0.3)
            except Exception as e:
                print("[harmonium] breath gate skipped:", e)

        voiced = self._hold_gaps(
            voiced_raw.astype(float),
            frame_rate,
            self._float(p, "gap_hold_ms", 150.0) / 1000.0
        )
        voiced_smooth = self._smooth_env(voiced, frame_rate, 0.03, 0.12)

        bellows_sensitivity = np.clip(self._float(p, "bellows_sensitivity", 0.7), 0.0, 1.0)

        if rms_frames is not None:
            # HARD presence gate: confidence alone must never keep the reeds
            # sounding during vocal pauses (CREPE often stays "confident" on
            # silence). Silent singer = silent reeds.
            presence = self._smooth_env(
                (rms_frames > 0.02).astype(float),
                frame_rate,
                0.03,
                0.20
            )
            rms_gate = np.where(rms_frames > 0.02, rms_frames, 0.0) ** rms_contrast
            energy_target = voiced_smooth * rms_gate   # no floor
        else:
            presence = np.ones_like(voiced_smooth)
            energy_target = voiced_smooth

        env_target = (
            (1.0 - bellows_sensitivity) * voiced_smooth
            + bellows_sensitivity * energy_target
        )

        # Silence the reeds whenever the singer is silent.
        env_target *= presence

        attack = max(0.005, self._float(p, "bellows_attack_ms", 90.0) / 1000.0)
        release = max(0.020, self._float(p, "bellows_release_ms", 220.0) / 1000.0)

        env_frames = self._smooth_env(env_target, frame_rate, attack, release)
        env_frames = np.clip(env_frames, 0.0, 1.0)

                # -------- Bellows dips: mask MID-PHRASE key moves ONLY ----
        # A dip must never fire when entering from silence, otherwise it
        # notches the attack and the entry sounds wobbly / stuttered.
        key_dip_depth = np.clip(self._float(p, "key_dip_depth", 0.20), 0.0, 0.6)
        step_dip_depth = np.clip(self._float(p, "step_dip_depth", 0.35), 0.0, 0.7)

        # Envelope level just BEFORE each frame (0 = coming from silence).
        pre_level = np.empty_like(env_frames)
        pre_level[0] = 0.0
        pre_level[1:] = env_frames[:-1]
        pre_level = self._smooth_onepole(pre_level, frame_rate, 0.06)

        # 0 at cold entries, 1 during sustained sound.
        dip_gate = np.clip(pre_level / 0.25, 0.0, 1.0)

        if key_dip_depth > 0.0:
            key_change = np.abs(np.diff(quantized, prepend=quantized[0])) > 0.4
            dip = gaussian_filter1d(
                key_change.astype(float),
                sigma=max(1.0, frame_rate * (self._float(p, "key_dip_ms", 60.0) / 1000.0) / 3.0)
            )
            dip_max = float(np.max(dip))
            if dip_max > 0:
                shaped = np.clip(dip / dip_max, 0.0, 1.0) * dip_gate
                env_frames *= (1.0 - key_dip_depth * shaped)

        if step_dip_depth > 0.0:
            dip = gaussian_filter1d(
                large_mask.astype(float),
                sigma=max(1.0, frame_rate * (self._float(p, "step_dip_ms", 90.0) / 1000.0) / 3.0)
            )
            dip_max = float(np.max(dip))
            if dip_max > 0:
                shaped = np.clip(dip / dip_max, 0.0, 1.0) * dip_gate
                env_frames *= (1.0 - step_dip_depth * shaped)

        # Accompanist reaction delay: enter slightly AFTER the voice.
        delay_frames = int(round((self._float(p, "entry_delay_ms", 35.0) / 1000.0) * frame_rate))
        if 0 < delay_frames < len(env_frames):
            env_frames = np.concatenate([np.zeros(delay_frames), env_frames[:-delay_frames]])

        # Key-click transient curve.
        click_frames = self._build_click_frames(env_frames, quantized, frame_rate)

        # ---------------- Synthesis setup ----------------
        pitch_shift_ratio = 2.0 ** (pitch_shift_cents / 1200.0)

        max_f = min(max(60.0, float(np.max(freq_frames)) * pitch_shift_ratio), sr * 0.45)
        max_h = int(min(len(self.acoustic_profile), max(1, int((sr * 0.5) / max_f))))

        harmonics = np.arange(1, max_h + 1, dtype=int)
        base_profile = self.acoustic_profile[:max_h]

        brightness = self._float(p, "brightness", 0.5)
        dynamic_brightness = self._float(p, "dynamic_brightness", 0.55)
        trem_rate = self._float(p, "tremolo_rate_hz", 4.0)
        trem_depth = self._float(p, "tremolo_depth", 0.025)

        reed_detune_cents = self._float(p, "reed_detune_cents", 4.0)
        reed_blend = np.clip(self._float(p, "reed_blend", 0.5), 0.0, 1.0)
        air_noise = np.clip(self._float(p, "air_noise", 0.06), 0.0, 1.0)
        key_click = np.clip(self._float(p, "key_click", 0.05), 0.0, 1.0)

        gamaka_amount = np.clip(self._float(p, "gamaka_amount", 0.45), 0.0, 1.0)
        gamaka_rate = self._float(p, "gamaka_rate_hz", 5.5)
        gamaka_depth = self._float(p, "gamaka_depth_cents", 12.0)

        detune_ratio_up = 2.0 ** (reed_detune_cents / 1200.0)
        detune_ratio_down = 2.0 ** (-reed_detune_cents / 1200.0)

        two_pi = 2.0 * np.pi
        phase_offset = 0.0
        chunk_size = 65536
        rng = np.random.default_rng(2026)

        # ---------------- Chunked additive synthesis ----------------
        for start in range(0, total_samples, chunk_size):
            end = min(total_samples, start + chunk_size)
            chunk_len = end - start

            t = np.arange(start, end, dtype=np.float64) / float(sr)

            f = np.interp(t, times, freq_frames).astype(np.float64)
            env = np.interp(t, times, env_frames).astype(np.float32)
            click = np.interp(t, times, click_frames).astype(np.float32)

            f *= pitch_shift_ratio

            # Silent region: maintain phase continuity and continue.
            if float(np.max(env)) < 0.003:
                phase_offset = (phase_offset + two_pi * float(np.sum(f / sr))) % two_pi
                continue

            # Gamaka-like oscillation, gated by the phrase envelope.
            if gamaka_amount > 0.0:
                gamaka_gate = np.clip((env - 0.25) * 3.0, 0.0, 1.0)
                gamaka_phase = two_pi * gamaka_rate * t + 0.45 * np.sin(two_pi * 0.27 * t)
                gamaka_cents = gamaka_amount * gamaka_depth * np.sin(gamaka_phase) * gamaka_gate
                f *= np.power(2.0, gamaka_cents / 1200.0)

            f = np.clip(f, 25.0, sr * 0.48)

            phase = phase_offset + two_pi * np.cumsum(f / float(sr))
            phase_offset = float(phase[-1] % two_pi)

            # Dynamic brightness (louder = brighter, like bellows pressure).
            voiced_chunk = env > 0.1
            mean_env = float(np.mean(env[voiced_chunk])) if np.any(voiced_chunk) else 0.0

            bright_eff = np.clip(brightness + dynamic_brightness * (mean_env - 0.5) * 0.9, 0.0, 1.5)
            tilt = (bright_eff - 0.5) * 0.8

            hs = harmonics.astype(float)
            weights = base_profile * np.maximum(0.0, 1.0 + tilt * np.log2(hs))

            sig = np.zeros(chunk_len, dtype=np.float64)

            # Main reed layer.
            for h, w in zip(harmonics, weights):
                sig += w * np.sin(h * phase)

            # Detuned reed layers (chorus realism).
            if reed_blend > 0.01 and reed_detune_cents > 0.05:
                phase_up = phase * detune_ratio_up
                phase_down = phase * detune_ratio_down
                detune_gain = reed_blend * 0.28

                for h, w in zip(harmonics, weights):
                    sig += detune_gain * w * np.sin(h * phase_up)
                    sig += detune_gain * w * np.sin(h * phase_down)

            # Bellows pressure variation + traditional tremolo.
            pressure = 1.0 + 0.05 * np.sin(two_pi * 0.23 * t + 0.7 * np.sin(two_pi * 0.07 * t))
            tremolo = 1.0 + trem_depth * np.sin(two_pi * trem_rate * t)

            sig *= env * pressure * tremolo * 0.18

            # Air / bellows noise (low-passed, gentle).
            if air_noise > 0.0:
                noise = rng.standard_normal(chunk_len).astype(np.float64)
                noise = (noise + np.roll(noise, 1) + np.roll(noise, 2) + np.roll(noise, 3)) / 4.0
                sig += noise * env * air_noise * 0.08

            # Key-click transient (gentle LOW-passed tick; high-passed clicks
            # are exactly what onset detectors hear as fake "beats").
            if key_click > 0.0:
                click_noise = rng.standard_normal(chunk_len).astype(np.float64)
                click_noise = (click_noise + np.roll(click_noise, 1)) * 0.5
                sig += click_noise * click * key_click * 0.05

            # Reed compression / soft saturation.
            sig = np.tanh(sig * 1.15)

            out[start:end] = sig.astype(np.float32)

        # ---------------- Time offset ----------------
        time_offset_ms = self._float(p, "time_offset_ms", 0.0)
        offset_samples = int(round((time_offset_ms / 1000.0) * sr))

        if offset_samples > 0:
            out = np.roll(out, offset_samples)
            out[:offset_samples] = 0.0
        elif offset_samples < 0:
            out = np.roll(out, offset_samples)
            out[offset_samples:] = 0.0

        # Edge fades.
        fade_len = min(int(0.02 * sr), total_samples // 3)
        if fade_len > 1:
            out[:fade_len] *= np.linspace(0.0, 1.0, fade_len, dtype=np.float32)
            out[-fade_len:] *= np.linspace(1.0, 0.0, fade_len, dtype=np.float32)

        # Final volume and safety limiter.
        out *= volume * 0.65

        peak = float(np.max(np.abs(out))) if total_samples else 0.0
        if peak > 0.95:
            out *= 0.95 / peak

        return out.astype(np.float32)

    # ------------------------------------------------------------------
    # NO-ZOOM pitch curve builder
    # ------------------------------------------------------------------
    def _build_pitch_curve(
        self,
        key_cents,
        continuous_cents,
        follow_amount,
        max_dev_cents,
        frame_rate,
        glide_tau,
        large_thresh_cents,
    ):
        """
        Build the final pitch curve in cents.

        - The vocal may only pull the harmonium ±max_dev_cents away from the
          locked key (microtone nuance yes, chasing big jumps no).
        - Key moves <= large_thresh_cents glide (meend).
        - Larger moves STEP instantly; the bellows dip (large_mask) masks it,
          exactly like a player moving the hand. No siren sweeps.
        """
        key_cents = np.asarray(key_cents, dtype=float)
        continuous_cents = np.asarray(continuous_cents, dtype=float)

        # Clamped microtone deviation around the locked key.
        dev = np.clip(continuous_cents - key_cents, -max_dev_cents, max_dev_cents)
        dev_smooth = self._smooth_onepole(dev, frame_rate, 0.05)

        n = len(key_cents)
        out = np.empty(n, dtype=float)
        large_mask = np.zeros(n, dtype=bool)

        alpha = 1.0 - float(np.exp(-1.0 / (max(1.0, frame_rate) * max(0.005, glide_tau))))

        prev = float(key_cents[0])

        for i in range(n):
            target = float(key_cents[i])
            diff = target - prev

            if abs(diff) > large_thresh_cents:
                # Big interval: step like a player moving the hand (no zoom).
                prev = target
                large_mask[i] = True
            else:
                # Small interval: smooth meend glide.
                prev += alpha * diff

            out[i] = prev

        final_cents = out + follow_amount * dev_smooth

        return final_cents, large_mask

    # ------------------------------------------------------------------
    # Control-frame preparation (HOLD fill — no bridges across pauses)
    # ------------------------------------------------------------------
    def _prepare_frames(
        self,
        frequencies: Optional[np.ndarray],
        confidences: Optional[np.ndarray],
        pitch_times: Optional[np.ndarray],
        duration: float,
        conf_threshold: float
    ):
        """
        Prepare control-rate frames. Returns None if no useful pitch exists.
        Pitch is HELD across unvoiced pauses (no linear interpolation
        bridges, which caused the racing glissando at phrase boundaries).
        """
        if frequencies is None or len(frequencies) == 0:
            return None

        freqs = np.asarray(frequencies, dtype=float)
        confs = np.ones_like(freqs) if confidences is None else np.asarray(confidences, dtype=float)

        common_len = min(len(freqs), len(confs))
        freqs = freqs[:common_len]
        confs = confs[:common_len]
        m = len(freqs)

        if m == 0:
            return None

        if pitch_times is None or len(pitch_times) < m:
            times = np.arange(m, dtype=float) / 100.0
        else:
            times = np.asarray(pitch_times[:m], dtype=float)

        times = np.maximum(times, 0.0)

        if len(times) > 1:
            times = np.maximum.accumulate(times)
            dt = np.where(np.diff(times) > 1e-6, np.diff(times), 1e-3)
            times = np.concatenate(([times[0]], times[0] + np.cumsum(dt)))
        else:
            times = np.array([0.0, max(float(duration), 0.01)], dtype=float)
            freqs = np.array([freqs[0], freqs[0]], dtype=float)
            confs = np.array([confs[0], confs[0]], dtype=float)
            m = 2

        dt = np.diff(times)
        dt = dt[dt > 0]
        frame_rate = float(np.clip(1.0 / float(np.median(dt)), 20.0, 200.0)) if len(dt) else 100.0

        freqs = np.nan_to_num(freqs, nan=0.0, posinf=0.0, neginf=0.0)
        confs = np.clip(np.nan_to_num(confs, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

        # Original: octave jitter correction.
        if m >= 5:
            win = min(15, m if m % 2 == 1 else m - 1)
            if win >= 3:
                rolling = median_filter(freqs, size=win)
                glitch = (freqs > rolling * 1.45) | (freqs < rolling * 0.65)
                freqs = freqs.copy()
                freqs[glitch] = rolling[glitch]

        valid_pitch = (freqs > 50.0) & (freqs < 5000.0)
        if not np.any(valid_pitch):
            return None

        # HOLD the last voiced pitch across pauses.
        valid_idx = np.where(valid_pitch)[0]
        filled_freqs = np.full(m, freqs[valid_idx[0]], dtype=float)

        last = freqs[valid_idx[0]]
        for i in range(m):
            if valid_pitch[i]:
                last = freqs[i]
            filled_freqs[i] = last

        voiced = valid_pitch & (confs >= conf_threshold)
        if not np.any(voiced):
            voiced = valid_pitch
        if not np.any(voiced):
            return None
        # NEW: kill octave flips at phrase ENDS (voice breaking into breath),
        # so the held pause pitch stays on the true last note (no racing).
        filled_freqs = self._stabilize_phrase_ends(filled_freqs, times, voiced, frame_rate)

        conf_valid = confs > 0.01
        if np.any(conf_valid):
            conf_filled = np.interp(np.arange(m), np.where(conf_valid)[0], confs[conf_valid])
        else:
            conf_filled = np.full(m, 0.5, dtype=float)

        return times, filled_freqs, voiced, conf_filled, frame_rate

    # ------------------------------------------------------------------
    # Vocal RMS at control rate
    # ------------------------------------------------------------------
    def _vocal_rms_frames(self, vocal_audio, sr, times):
        if vocal_audio is None or len(vocal_audio) == 0:
            return None

        v = np.asarray(vocal_audio, dtype=np.float32)
        if v.ndim > 1:
            v = np.mean(v, axis=1)
        if len(v) == 0:
            return None

        window = max(16, int(sr * 0.05))
        rms = np.sqrt(np.maximum(0.0, uniform_filter1d(v.astype(np.float64) ** 2, size=window)))

        rms_frames = np.interp(times, np.arange(len(rms)) / float(sr), rms)

        max_rms = float(np.max(rms_frames))
        if max_rms > 0:
            rms_frames /= max_rms

        return rms_frames

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _hold_gaps(v, frame_rate, min_hold_s):
        """Bridge unvoiced gaps shorter than min_hold_s (legato hold)."""
        held = v.copy()
        hold_frames = int(max(0.0, min_hold_s) * frame_rate)

        run_start = None
        for i in range(len(v)):
            if v[i] > 0.5:
                if run_start is not None and run_start > 0 and (i - run_start) <= hold_frames:
                    held[run_start:i] = 1.0
                run_start = None
            else:
                if run_start is None:
                    run_start = i

        return held

    @staticmethod
    def _stabilize_phrase_ends(freqs, times, voiced, frame_rate,
                             lookback_s=0.35, anchor_s=0.6):
        """At each voiced->silence transition, replace trailing frames that
        jump ~an octave away from the stable anchor with the anchor itself."""
        out = freqs.copy()
        n = len(out)
        lb = max(2, int(lookback_s * frame_rate))   # suspect window before the end
        an = max(3, int(anchor_s * frame_rate))     # stable anchor before that

        for i in range(1, n):
            if voiced[i - 1] and not voiced[i]:     # phrase end
                i_b = max(0, i - lb)
                i_a = max(0, i_b - an)
                if i_b <= i_a:
                    continue
                anchor = float(np.median(out[i_a:i_b]))
                if anchor <= 0:
                    continue
                for j in range(i_b, i):
                    if out[j] > 1.5 * anchor or out[j] < 0.66 * anchor:
                        out[j] = anchor
        return out

    @staticmethod
    def _hysteresis_quantize(semitones, hysteresis):
        out = np.zeros_like(semitones, dtype=float)
        if len(semitones) == 0:
            return out

        h = max(0.05, float(hysteresis))
        current = float(np.round(semitones[0]))

        for i in range(len(semitones)):
            if abs(semitones[i] - current) > h:
                current = float(np.round(semitones[i]))
            out[i] = current

        return out

    @staticmethod
    def _build_click_frames(env_frames, quantized_keys, frame_rate):
        if len(env_frames) < 2:
            return np.zeros_like(env_frames)

        onset = np.clip(np.diff(env_frames, prepend=env_frames[0]) * frame_rate, 0.0, 3.0)
        key_change = np.abs(np.diff(quantized_keys, prepend=quantized_keys[0])) > 0.4

        click = onset * (0.35 + 0.65 * key_change.astype(float))
        click = gaussian_filter1d(click, sigma=max(1.0, frame_rate * 0.015))

        max_click = float(np.max(click))
        if max_click > 0:
            click /= max_click

        return click

    @staticmethod
    def _smooth_onepole(values, frame_rate, tau):
        values = np.asarray(values, dtype=float)
        if len(values) == 0:
            return values

        alpha = 1.0 - float(np.exp(-1.0 / (max(1.0, frame_rate) * max(0.001, tau))))

        out = np.empty_like(values)
        y = float(values[0])
        for i in range(len(values)):
            y += alpha * (float(values[i]) - y)
            out[i] = y

        return out

    @staticmethod
    def _smooth_env(values, frame_rate, attack, release):
        values = np.asarray(values, dtype=float)
        if len(values) == 0:
            return values

        frame_rate = max(1.0, float(frame_rate))

        out = np.empty_like(values)
        current = 0.0

        for i in range(len(values)):
            target = float(values[i])
            tau = max(0.001, attack) if target > current else max(0.001, release)
            alpha = 1.0 - float(np.exp(-1.0 / (frame_rate * tau)))
            current += alpha * (target - current)
            out[i] = current

        return out