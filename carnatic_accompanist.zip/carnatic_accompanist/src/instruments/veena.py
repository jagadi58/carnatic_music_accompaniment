#!/usr/bin/env python3
"""
Veena Instrument — Realism edition v6 (pause-proof, verified).
Adaptive vocal-floor gating + octave-leak hold + presence envelope.
"""
import numpy as np
from typing import Dict, Any, Optional

from scipy.ndimage import median_filter, gaussian_filter1d, uniform_filter1d

VEENA_VERSION = "v6-pause-proof"


class Veena:
    """Expressive veena-like accompaniment generator."""

    def __init__(self):
        self.name = "Veena"

    def get_default_params(self) -> Dict[str, Any]:
        return {
            "volume": 0.8,
            "pitch_shift_cents": 0.0,
            "confidence_threshold": 0.35,
            "time_offset_ms": 0.0,
            "octave_shift": 0,

            "attack_time": 0.030,
            "decay_rate": 4.0,
            "tension_choke": 1.5,
            "resonance": 0.55,

            "slide_ms": 100.0,
            "pitch_follow": 0.6,
            "max_follow_dev_cents": 50.0,
            "hysteresis_semitones": 0.9,
            "kampita_cents": 15.0,
            "kampita_hz": 4.2,

            "min_pluck_interval_ms": 200.0,
            "note_debounce_ms": 60.0,
            "repluck_semitones": 1.0,
            "restroke_s": 1.2,
            "restroke_peak": 0.5,
            "syllable_response": 0.5,
            "entry_delay_ms": 15.0,
            "pluck_noise": 0.02,
        }

    @staticmethod
    def _float(params, key, default):
        try:
            if key not in params or params[key] is None:
                return default
            return float(params[key])
        except Exception:
            return default

    @staticmethod
    def _int(params, key, default):
        try:
            if key not in params or params[key] is None:
                return default
            return int(params[key])
        except Exception:
            return default

    # ------------------------------------------------------------------
    def generate(
        self,
        duration: float,
        sr: int,
        params: Dict[str, Any],
        start_freq: float = 261.63,
        frequencies: Optional[np.ndarray] = None,
        confidences: Optional[np.ndarray] = None,
        pitch_times: Optional[np.ndarray] = None,
        sruti_freq: Optional[float] = None,
        vocal_audio: Optional[np.ndarray] = None,
        **kwargs
    ) -> np.ndarray:
        p = self.get_default_params()
        p.update(params or {})

        total_samples = int(max(0.0, duration) * sr)
        out = np.zeros(total_samples, dtype=np.float32)

        if total_samples == 0:
            return out

        volume = self._float(p, "volume", 0.8)
        if volume <= 0.0 or frequencies is None or len(frequencies) == 0:
            return out

        conf_thresh = self._float(p, "confidence_threshold", 0.35)

        prepared = self._prepare_frames(
            frequencies=frequencies,
            confidences=confidences,
            pitch_times=pitch_times,
            duration=duration,
            conf_threshold=conf_thresh,
        )

        if prepared is None:
            return out

        times, filled_freqs, voiced_raw, conf_filled, frame_rate = prepared
        m = len(times)

        # ---------------- Global tuning ----------------
        octave_shift = self._int(p, "octave_shift", 0)
        pitch_shift_cents = self._float(p, "pitch_shift_cents", 0.0)
        pitch_ratio = 2.0 ** (float(octave_shift) + pitch_shift_cents / 1200.0)

        freqs_oct = filled_freqs * (2.0 ** octave_shift)

        ref = max(20.0, float(sruti_freq)) if sruti_freq and sruti_freq > 0 else max(20.0, float(start_freq))

        # ---------------- Swara reference ----------------
        hysteresis = self._float(p, "hysteresis_semitones", 0.9)

        semitones = 12.0 * np.log2(np.maximum(freqs_oct, 10.0) / ref)
        quantized = self._hysteresis_quantize(semitones, hysteresis)
        if len(quantized) >= 3:
            quantized = median_filter(quantized, size=3)

        key_cents = quantized * 100.0
        continuous_cents = 1200.0 * np.log2(np.maximum(freqs_oct, 10.0) / ref)

        max_dev = self._float(p, "max_follow_dev_cents", 50.0)
        follow = np.clip(self._float(p, "pitch_follow", 0.6), 0.0, 1.0)

        dev = np.clip(continuous_cents - key_cents, -max_dev, max_dev)
        dev_smooth = self._smooth_onepole(dev, frame_rate, 0.06)

        target_cents = key_cents + follow * dev_smooth

        # ---------------- SLIDE (jaru/meend) ----------------
        slide_tau = max(0.010, self._float(p, "slide_ms", 100.0) / 1000.0)
        final_cents = self._smooth_onepole(target_cents, frame_rate, slide_tau)

        freq_frames = ref * np.power(2.0, final_cents / 1200.0)

        # ---------------- Vocal RMS + ADAPTIVE FLOOR ----------------
        rms_frames = self._vocal_rms_frames(vocal_audio, sr, times)
        if rms_frames is None:
            rms_frames = np.clip(conf_filled, 0.0, 1.0)

        floor = float(np.percentile(rms_frames, 20))          # this recording's pause level
        pres_thr = max(0.05, floor + 0.05)
        active_thr = max(0.12, floor + 0.15)

        presence = self._smooth_env(
            (rms_frames > pres_thr).astype(float), frame_rate, 0.05, 0.20
        )

        # ---------------- ACCOMPANIST PLUCK DETECTION ----------------
        voiced = voiced_raw.astype(bool)

        syllable_response = np.clip(self._float(p, "syllable_response", 0.5), 0.0, 1.0)
        jump_thr = 0.10 - 0.06 * syllable_response

        min_frames = max(1, int(self._float(p, "min_pluck_interval_ms", 200.0) / 1000.0 * frame_rate))
        deb = max(1, int(self._float(p, "note_debounce_ms", 60.0) / 1000.0 * frame_rate))
        repluck_cents = self._float(p, "repluck_semitones", 1.0) * 100.0
        restroke_frames = max(min_frames, int(self._float(p, "restroke_s", 1.2) * frame_rate))
        restroke_peak = np.clip(self._float(p, "restroke_peak", 0.5), 0.1, 1.0)
        delay_frames = int(round((self._float(p, "entry_delay_ms", 15.0) / 1000.0) * frame_rate))

        onsets = []   # (frame, peak)
        last_pluck = -min_frames

        first_voiced = np.where(voiced)[0]
        if len(first_voiced) > 0:
            f0_idx = first_voiced[0]
            if rms_frames[f0_idx] > active_thr:
                peak0 = 0.55 + 0.45 * float(np.clip(rms_frames[f0_idx], 0.0, 1.0))
                onsets.append((min(f0_idx + delay_frames, m - 1), peak0))
            last_pluck = f0_idx

        for i in range(1, m):
            if not voiced[i]:
                continue

            since_last = i - last_pluck
            if since_last < min_frames:
                continue

            rms_i = float(np.clip(rms_frames[i], 0.0, 1.0))
            active = rms_i > active_thr                      # voice really present

            onset = active and voiced[i] and not voiced[i - 1]

            dq = quantized[i] - quantized[i - 1]
            note_changed = (abs(dq) * 100.0) >= repluck_cents
            stable = (i + deb >= m) or (quantized[min(i + deb, m - 1)] == quantized[i])

            rms_jump = rms_frames[i] - rms_frames[i - 1]
            accent = active and (rms_jump > jump_thr) and (rms_frames[i] > 0.25)

            restroke = active and since_last >= restroke_frames

            peak = 0.0
            if onset or (note_changed and stable) or accent:
                peak = 0.55 + 0.45 * rms_i
            elif restroke:
                peak = restroke_peak * (0.7 + 0.3 * rms_i)

            if peak > 0.0:
                onsets.append((min(i + delay_frames, m - 1), peak))
                last_pluck = i

        if len(onsets) == 0:
            return out

        # ---------------- Pluck envelopes (long ring + slow body) ---------
        attack_time = max(0.002, self._float(p, "attack_time", 0.030))
        attack_samples = max(1, int(attack_time * sr))
        decay_rate = max(0.5, self._float(p, "decay_rate", 4.0))
        tension_choke = self._float(p, "tension_choke", 1.5)
        resonance = np.clip(self._float(p, "resonance", 0.55), 0.0, 1.0)

        singer_anchor = float(np.median(filled_freqs[filled_freqs > 50])) if np.any(filled_freqs > 50) else float(start_freq)

        env_main = np.zeros(total_samples, dtype=np.float32)
        env_res = np.zeros(total_samples, dtype=np.float32)
        click_frames = np.zeros(m, dtype=np.float32)

        for fr, peak in onsets:
            click_frames[fr] = 1.0

            s0 = int(round(times[fr] * sr))
            if s0 >= total_samples:
                continue

            ae = min(total_samples, s0 + attack_samples)
            if ae > s0:
                x = np.linspace(0.0, 1.0, ae - s0)
                smooth_attack = 0.5 - 0.5 * np.cos(np.pi * x)
                env_main[s0:ae] = np.maximum(
                    env_main[s0:ae],
                    (smooth_attack * peak).astype(np.float32)
                )

            d0 = ae
            if d0 >= total_samples:
                continue

            f_here = float(np.interp(times[min(fr, m - 1)], times, freq_frames))
            ratio = np.clip(f_here / max(50.0, singer_anchor), 0.8, 1.5)
            dec = decay_rate * (ratio ** tension_choke)

            win = min(total_samples - d0, int(sr * (10.0 / dec)) + 1)
            if win > 0:
                tt = np.arange(win, dtype=np.float64) / sr
                env_main[d0:d0 + win] = np.maximum(
                    env_main[d0:d0 + win],
                    (np.exp(-dec * tt) * peak).astype(np.float32)
                )

            dec_r = max(0.25, dec * 0.15)
            win_r = min(total_samples - d0, int(sr * (10.0 / dec_r)) + 1)
            if win_r > 0:
                tt = np.arange(win_r, dtype=np.float64) / sr
                env_res[d0:d0 + win_r] = np.maximum(
                    env_res[d0:d0 + win_r],
                    (np.exp(-dec_r * tt) * peak).astype(np.float32)
                )

        env_total = np.clip(env_main + resonance * 0.6 * env_res, 0.0, 1.2)

        # Presence fade (frame-rate -> sample-rate, broadcast-safe)
        t_all = np.arange(total_samples, dtype=np.float64) / float(sr)
        presence_s = np.interp(t_all, times, presence)
        env_total *= np.clip(presence_s * 1.1, 0.0, 1.0)

        click_smooth = gaussian_filter1d(click_frames, sigma=max(1.0, frame_rate * 0.008))
        c_max = float(np.max(click_smooth))
        if c_max > 0:
            click_smooth /= c_max

        # ---------------- Synthesis ----------------
        kampita_cents = self._float(p, "kampita_cents", 15.0)
        kampita_hz = self._float(p, "kampita_hz", 4.2)
        pluck_noise = np.clip(self._float(p, "pluck_noise", 0.02), 0.0, 0.2)

        harmonics = np.array([1, 2, 3, 4, 5], dtype=int)
        weights = np.array([1.00, 0.30, 0.10, 0.05, 0.02], dtype=np.float64)

        two_pi = 2.0 * np.pi
        phase_offset = 0.0
        chunk_size = 65536
        rng = np.random.default_rng(2026)

        for start in range(0, total_samples, chunk_size):
            end = min(total_samples, start + chunk_size)
            chunk_len = end - start

            t = np.arange(start, end, dtype=np.float64) / float(sr)

            f = np.interp(t, times, freq_frames) * pitch_ratio
            env = env_total[start:end].astype(np.float32)
            click = np.interp(t, times, click_smooth).astype(np.float32)

            if float(np.max(env)) < 0.002:
                phase_offset = (phase_offset + two_pi * float(np.sum(f / sr))) % two_pi
                continue

            kamp_gate = np.clip(env * 2.5, 0.0, 1.0)
            kamp_phase = two_pi * kampita_hz * t + 0.4 * np.sin(two_pi * 0.21 * t)
            f *= np.power(2.0, (kampita_cents * np.sin(kamp_phase) * kamp_gate) / 1200.0)

            f = np.clip(f, 25.0, sr * 0.48)

            phase = phase_offset + two_pi * np.cumsum(f / float(sr))
            phase_offset = float(phase[-1] % two_pi)

            sig = np.zeros(chunk_len, dtype=np.float64)
            for h, w in zip(harmonics, weights):
                sig += w * np.sin(h * phase)

            sig *= env * 0.35

            if pluck_noise > 0.0:
                tick = rng.standard_normal(chunk_len)
                tick = (tick + np.roll(tick, 1)) * 0.5
                sig += tick * click * pluck_noise * 0.3

            out[start:end] = np.tanh(sig * 1.1).astype(np.float32)

        # ---------------- Offset, fades, volume ----------------
        offset_samples = int(round((self._float(p, "time_offset_ms", 0.0) / 1000.0) * sr))
        if offset_samples > 0:
            out = np.roll(out, offset_samples)
            out[:offset_samples] = 0.0
        elif offset_samples < 0:
            out = np.roll(out, offset_samples)
            out[offset_samples:] = 0.0

        fade_len = min(int(0.02 * sr), total_samples // 3)
        if fade_len > 1:
            out[:fade_len] *= np.linspace(0.0, 1.0, fade_len, dtype=np.float32)
            out[-fade_len:] *= np.linspace(1.0, 0.0, fade_len, dtype=np.float32)

        out *= volume * 0.8

        peak = float(np.max(np.abs(out))) if total_samples else 0.0
        if peak > 0.95:
            out *= 0.95 / peak

        return out.astype(np.float32)

    # ------------------------------------------------------------------
    def _prepare_frames(self, frequencies, confidences, pitch_times, duration, conf_threshold):
        if frequencies is None or len(frequencies) == 0:
            return None

        freqs = np.asarray(frequencies, dtype=float)
        confs = np.ones_like(freqs) if confidences is None else np.asarray(confidences, dtype=float)

        common_len = min(len(freqs), len(confs))
        freqs = freqs[:common_len]
        confs = confs[:common_len]
        m = len(freqs)

        if m == 0:
            return None

        if pitch_times is None or len(pitch_times) < m:
            times = np.arange(m, dtype=float) / 100.0
        else:
            times = np.asarray(pitch_times[:m], dtype=float)

        times = np.maximum(times, 0.0)

        if len(times) > 1:
            times = np.maximum.accumulate(times)
            dt = np.where(np.diff(times) > 1e-6, np.diff(times), 1e-3)
            times = np.concatenate(([times[0]], times[0] + np.cumsum(dt)))
        else:
            times = np.array([0.0, max(float(duration), 0.01)], dtype=float)
            freqs = np.array([freqs[0], freqs[0]], dtype=float)
            confs = np.array([confs[0], confs[0]], dtype=float)
            m = 2

        dt = np.diff(times)
        dt = dt[dt > 0]
        frame_rate = float(np.clip(1.0 / float(np.median(dt)), 20.0, 200.0)) if len(dt) else 100.0

        freqs = np.nan_to_num(freqs, nan=0.0, posinf=0.0, neginf=0.0)
        confs = np.clip(np.nan_to_num(confs, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

        if m >= 5:
            win = min(15, m if m % 2 == 1 else m - 1)
            if win >= 3:
                rolling = median_filter(freqs, size=win)
                glitch = (freqs > rolling * 1.45) | (freqs < rolling * 0.65)
                freqs = freqs.copy()
                freqs[glitch] = rolling[glitch]

        valid_pitch = (freqs > 50.0) & (freqs < 5000.0)
        if not np.any(valid_pitch):
            return None

        valid_idx = np.where(valid_pitch)[0]
        filled = np.full(m, freqs[valid_idx[0]], dtype=float)

        last = freqs[valid_idx[0]]
        for i in range(m):
            if valid_pitch[i]:
                last = freqs[i]
            filled[i] = last

        # NEW: hold sudden octave jumps (tracker leakage) unless they persist
        filled = self._debounce_octave_jumps(filled, times, min_hold_s=0.8)

        voiced = valid_pitch & (confs >= conf_threshold)
        if not np.any(voiced):
            voiced = valid_pitch
        if not np.any(voiced):
            return None

        conf_valid = confs > 0.01
        if np.any(conf_valid):
            conf_filled = np.interp(np.arange(m), np.where(conf_valid)[0], confs[conf_valid])
        else:
            conf_filled = np.full(m, 0.5, dtype=float)

        return times, filled, voiced, conf_filled, frame_rate

    # ------------------------------------------------------------------
    @staticmethod
    def _debounce_octave_jumps(freqs, times, min_hold_s=0.8):
        out = freqs.copy()
        n = len(out)
        i = 1
        while i < n:
            prev = out[i - 1]
            if prev > 0 and (out[i] > 1.55 * prev or out[i] < 0.645 * prev):
                j = i
                while j < n and (out[j] > 1.55 * prev or out[j] < 0.645 * prev):
                    j += 1
                dur = times[min(j, n - 1)] - times[i]
                if dur < min_hold_s:
                    out[i:j] = prev
                i = j
            else:
                i += 1
        return out

    # ------------------------------------------------------------------
    def _vocal_rms_frames(self, vocal_audio, sr, times):
        if vocal_audio is None or len(vocal_audio) == 0:
            return None

        v = np.asarray(vocal_audio, dtype=np.float32)
        if v.ndim > 1:
            v = np.mean(v, axis=1)
        if len(v) == 0:
            return None

        window = max(16, int(sr * 0.05))
        rms = np.sqrt(np.maximum(0.0, uniform_filter1d(v.astype(np.float64) ** 2, size=window)))

        rms_frames = np.interp(times, np.arange(len(rms)) / float(sr), rms)

        max_rms = float(np.max(rms_frames))
        if max_rms > 0:
            rms_frames /= max_rms

        return rms_frames

    @staticmethod
    def _stabilize_phrase_ends(freqs, times, voiced, frame_rate,
                             lookback_s=0.35, anchor_s=0.6):
        """At each voiced->silence transition, replace trailing frames that
        jump ~an octave away from the stable anchor with the anchor itself."""
        out = freqs.copy()
        n = len(out)
        lb = max(2, int(lookback_s * frame_rate))   # suspect window before the end
        an = max(3, int(anchor_s * frame_rate))     # stable anchor before that

        for i in range(1, n):
            if voiced[i - 1] and not voiced[i]:     # phrase end
                i_b = max(0, i - lb)
                i_a = max(0, i_b - an)
                if i_b <= i_a:
                    continue
                anchor = float(np.median(out[i_a:i_b]))
                if anchor <= 0:
                    continue
                for j in range(i_b, i):
                    if out[j] > 1.5 * anchor or out[j] < 0.66 * anchor:
                        out[j] = anchor
        return out

    @staticmethod
    def _hysteresis_quantize(semitones, hysteresis):
        out = np.zeros_like(semitones, dtype=float)
        if len(semitones) == 0:
            return out

        h = max(0.05, float(hysteresis))
        current = float(np.round(semitones[0]))

        for i in range(len(semitones)):
            if abs(semitones[i] - current) > h:
                current = float(np.round(semitones[i]))
            out[i] = current

        return out

    @staticmethod
    def _smooth_onepole(values, frame_rate, tau):
        values = np.asarray(values, dtype=float)
        if len(values) == 0:
            return values

        alpha = 1.0 - float(np.exp(-1.0 / (max(1.0, frame_rate) * max(0.001, tau))))

        out = np.empty_like(values)
        y = float(values[0])
        for i in range(len(values)):
            y += alpha * (float(values[i]) - y)
            out[i] = y

        return out

    @staticmethod
    def _smooth_env(values, frame_rate, attack, release):
        values = np.asarray(values, dtype=float)
        if len(values) == 0:
            return values

        frame_rate = max(1.0, float(frame_rate))

        out = np.empty_like(values)
        current = 0.0

        for i in range(len(values)):
            target = float(values[i])
            tau = max(0.001, attack) if target > current else max(0.001, release)
            alpha = 1.0 - float(np.exp(-1.0 / (frame_rate * tau)))
            current += alpha * (target - current)
            out[i] = current

        return out