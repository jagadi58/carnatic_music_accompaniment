#!/usr/bin/env python3
"""
Sruti Box (Electronic Drone) Instrument.
Generates an authentic Carnatic drone using additive synthesis with 
subtle detuning to mimic real electronic sruti boxes or tanpura.
Fully upgraded to support dynamic Raga-based tuning (Pa, Ma1, Ni3).
"""

import numpy as np
from typing import Dict, Any

from src.instruments.base_instrument import BaseInstrument

class SrutiBox(BaseInstrument):
    """Generates a continuous Sa and dynamically tuned secondary drone."""
    
    def __init__(self):
        super().__init__("Sruti Box")
    
    def get_default_params(self) -> Dict[str, Any]:
        return {
            "volume": 0.5,
            "pitch_shift_cents": 0.0,
            "secondary_note": "P",  # Automatically changes based on Raga (P, M1, N3, or None)
            "chorus_depth": 0.002  # Slight detuning for realism (in seconds)
        }
    
    def generate(
        self, 
        duration: float, 
        sr: int, 
        params: Dict[str, Any],
        sruti_freq: float = 261.63, # This will dynamically catch the Relative Anchor from our identifier
        **kwargs
    ) -> np.ndarray:
        """
        Generate the Sruti Box drone.
        
        Args:
            duration: Length in seconds
            sr: Sample rate
            params: Volume, pitch_shift_cents, secondary_note, chorus_depth
            sruti_freq: The dynamically detected base frequency of Sa in Hz
        """
        volume = params.get("volume", self.default_params["volume"])
        pitch_shift = params.get("pitch_shift_cents", self.default_params["pitch_shift_cents"])
        secondary_note = params.get("secondary_note", self.default_params["secondary_note"])
        chorus_depth = params.get("chorus_depth", self.default_params["chorus_depth"])
        
        # Apply pitch shift to the base Sa
        base_sa = self.apply_pitch_shift(sruti_freq, pitch_shift)
        
        # Determine the pure Just Intonation ratio for the secondary drone
        secondary_freq = None
        if secondary_note == "P":
            secondary_freq = base_sa * 1.5           # Perfect Fifth
        elif secondary_note == "M1":
            secondary_freq = base_sa * (4.0 / 3.0)   # Suddha Madhyamam
        elif secondary_note == "N3":
            secondary_freq = base_sa * (15.0 / 8.0)  # Kakali Nishadam
        
        t = np.linspace(0, duration, int(sr * duration), endpoint=False)
        audio = np.zeros_like(t, dtype=np.float32)
        
        def add_harmonic(freq: float, amplitude: float):
            nonlocal audio
            detune_factor = 1.0 + np.array([-chorus_depth, 0.0, chorus_depth])
            for dt in detune_factor:
                phase = 2 * np.pi * (freq * dt) * t
                phase += np.random.uniform(0, 2 * np.pi)
                audio += (amplitude / 3.0) * np.sin(phase)
        
        # --- Sa Harmonics (Fundamental + overtones) ---
        add_harmonic(base_sa, 0.6)          # Fundamental
        add_harmonic(base_sa * 2.0, 0.25)   # 1st Overtone (Octave)
        add_harmonic(base_sa * 3.0, 0.10)   # 2nd Overtone (Perfect 12th)
        add_harmonic(base_sa * 4.0, 0.05)   # 3rd Overtone (2 Octaves)
        
        # --- Dynamic Secondary Harmonics ---
        if secondary_freq:
            add_harmonic(secondary_freq, 0.4)          # Secondary Fundamental
            add_harmonic(secondary_freq * 2.0, 0.15)   # Secondary 1st Overtone
        
        # Apply volume and normalize to prevent clipping
        audio = self.apply_volume(audio, volume)
        
        # Soft fade-in and fade-out (100ms)
        fade_samples = int(0.1 * sr)
        if len(audio) > 2 * fade_samples:
            fade_in = np.linspace(0.0, 1.0, fade_samples)
            fade_out = np.linspace(1.0, 0.0, fade_samples)
            audio[:fade_samples] *= fade_in
            audio[-fade_samples:] *= fade_out
        
        # Final hard clip prevention
        max_val = np.max(np.abs(audio))
        if max_val > 1.0:
            audio = audio / max_val
            
        return audio.astype(np.float32)