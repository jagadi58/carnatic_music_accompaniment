#!/usr/bin/env python3
"""
Swara mapper for Carnatic Accompanist.
Maps frequencies to Carnatic swaras based on a reference tonic (Sruti).
"""

import numpy as np
from typing import List, Tuple, Optional

# Standard Carnatic swara intervals in cents (12-tone approximation for robust AI matching)
# S=0, R1=100, R2=200, G2=300, G3=400, M1=500, M2=600, P=700, D1=800, D2=900, N2=1000, N3=1100
SWARA_CENTS = {
    'S': 0,
    'R1': 100, 'R2': 200,
    'G2': 300, 'G3': 400,
    'M1': 500, 'M2': 600,
    'P': 700,
    'D1': 800, 'D2': 900,
    'N2': 1000, 'N3': 1100
}

class SwaraMapper:
    """Maps frequencies to Carnatic swaras."""
    
    def __init__(self, reference_freq: float = 261.63):
        """
        Initialize mapper.
        
        Args:
            reference_freq: Frequency of Shadjam (Sa) in Hz. Default is C4 (261.63 Hz).
        """
        self.reference_freq = reference_freq
    
    def set_reference_freq(self, freq: float):
        """Update the reference frequency (Sruti)."""
        if freq <= 0:
            raise ValueError("Reference frequency must be positive.")
        self.reference_freq = freq
    
    def freq_to_cents(self, freq: float) -> float:
        """Convert a frequency to cents relative to the reference."""
        if freq <= 0:
            return 0.0
        return 1200 * np.log2(freq / self.reference_freq)
    
    def cents_to_swara(self, cents: float) -> str:
        """Map cents to the closest Carnatic swara."""
        # Normalize cents to [0, 1200) range (one octave)
        normalized_cents = cents % 1200
        
        closest_swara = 'S'
        min_diff = float('inf')
        
        for swara, target_cents in SWARA_CENTS.items():
            diff = abs(normalized_cents - target_cents)
            # Handle wrap-around for S (0 and 1200 are the same)
            diff = min(diff, 1200 - diff)
            
            if diff < min_diff:
                min_diff = diff
                closest_swara = swara
        
        return closest_swara
    
    def freq_to_swara(self, freq: float) -> str:
        """Directly map a frequency to a swara."""
        if freq <= 0:
            return '-'
        cents = self.freq_to_cents(freq)
        return self.cents_to_swara(cents)
    
    def map_frequencies_to_swaras(
        self, 
        frequencies: np.ndarray, 
        confidence_threshold: float = 0.5
    ) -> List[str]:
        """
        Map an array of frequencies to a list of swaras.
        
        Args:
            frequencies: Array of frequencies in Hz
            confidence_threshold: Not used directly here, but kept for API consistency 
                                  (filtering should be done before calling this)
        
        Returns:
            List of swara strings (e.g., ['S', 'R2', 'G3', 'P', 'S'])
        """
        swaras = []
        for freq in frequencies:
            if freq > 0:
                swaras.append(self.freq_to_swara(freq))
            else:
                swaras.append('-')
        return swaras
    
    def get_unique_swaras(self, swaras: List[str]) -> List[str]:
        """Get unique swaras from a list, preserving order of first appearance."""
        seen = set()
        unique = []
        for s in swaras:
            if s != '-' and s not in seen:
                seen.add(s)
                unique.append(s)
        return unique