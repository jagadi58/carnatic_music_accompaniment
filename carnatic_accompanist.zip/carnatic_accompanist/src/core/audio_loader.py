#!/usr/bin/env python3
"""
Audio loader module for Carnatic Accompanist.
Handles loading, saving, and inspecting audio files in various formats (including m4a).
Strictly enforces Stereo 16-bit PCM exports.
"""

import os
from pathlib import Path
from typing import Tuple, Dict, Optional, Union
import numpy as np
import librosa
import soundfile as sf
import warnings

class AudioLoader:
    """Loads, saves, and inspects audio files."""
    
    SUPPORTED_FORMATS = {'.wav', '.mp3', '.flac', '.ogg', '.m4a'}
    DEFAULT_SAMPLE_RATE = 44100
    
    def __init__(self, default_sr: int = 44100):
        self.default_sr = default_sr
    
    def load(
        self,
        file_path: Union[str, Path],
        target_sr: Optional[int] = None,
        mono: bool = True,
        normalize: bool = True
    ) -> Tuple[np.ndarray, int]:
        """
        Load an audio file. Converts input to mono to ensure pitch tracking functions correctly.
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"Audio file not found: {file_path}")
        
        if file_path.suffix.lower() not in self.SUPPORTED_FORMATS:
            raise ValueError(
                f"Unsupported format: {file_path.suffix}. "
                f"Supported: {self.SUPPORTED_FORMATS}"
            )
        
        sr = target_sr if target_sr else self.default_sr
        
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            audio, orig_sr = librosa.load(
                str(file_path),
                sr=sr,
                mono=mono,
                res_type='kaiser_best'
            )
        
        if normalize and audio.size > 0:
            audio = self._normalize(audio)
        
        return audio, sr
    
    def save(
        self,
        file_path: Union[str, Path],
        audio: np.ndarray,
        sr: int
    ) -> None:
        """
        Save audio to file. Strictly enforces Stereo (2-channel) export.
        """
        file_path = Path(file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # --- STRICT STEREO ENFORCEMENT ---
        # 1. If the array is 1D (Mono), duplicate it to 2D (Stereo)
        if audio.ndim == 1:
            audio = np.column_stack((audio, audio))
        # 2. If the array is transposed as (Channels, Samples), flip it to (Samples, Channels)
        elif audio.shape[0] == 2 and audio.shape[1] > 2:
            audio = audio.T
            
        ext = file_path.suffix.lower()
        
        if ext == '.mp3':
            from pydub import AudioSegment
            
            if audio.dtype != np.int16:
                audio_clipped = np.clip(audio, -1.0, 1.0)
                audio_int16 = (audio_clipped * 32767).astype(np.int16)
            else:
                audio_int16 = audio
            
            channels = audio_int16.shape[1] 
            audio_int16 = np.ascontiguousarray(audio_int16)
            
            segment = AudioSegment(
                audio_int16.tobytes(),
                frame_rate=sr,
                sample_width=2,
                channels=channels
            )
            segment.export(str(file_path), format='mp3', bitrate='192k')
        else:
            # Force standard 16-bit PCM Stereo WAV
            sf.write(str(file_path), audio, sr, subtype='PCM_16')
    
    def get_info(self, file_path: Union[str, Path]) -> Dict:
        """
        Get metadata about an audio file.
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"Audio file not found: {file_path}")
        
        ext = file_path.suffix.lower()
        
        if ext in {'.mp3', '.m4a'}:
            duration = librosa.get_duration(path=str(file_path))
            return {
                'duration': duration,
                'sample_rate': "Unknown (Lossy)",
                'channels': "Unknown (Lossy)",
                'format': ext.replace('.', '').upper(),
                'subtype': 'Compressed',
                'file_size': os.path.getsize(file_path),
                'file_path': str(file_path)
            }
        else:
            info = sf.info(str(file_path))
            return {
                'duration': info.duration,
                'sample_rate': info.samplerate,
                'channels': info.channels,
                'format': info.format,
                'subtype': info.subtype,
                'file_size': os.path.getsize(file_path),
                'file_path': str(file_path)
            }
    
    @staticmethod
    def _normalize(audio: np.ndarray) -> np.ndarray:
        """Normalize audio to [-1, 1] range."""
        max_val = np.max(np.abs(audio))
        if max_val > 0:
            return audio / max_val
        return audio