#!/usr/bin/env python3
"""
Core Pitch Tracking Module.
Supports both standard math (pyin) and neural network (crepe) backends.
"""

import numpy as np
import librosa
import warnings

class PitchTracker:
    def __init__(self, backend='crepe', crepe_model_size='full'):
        """
        Initializes the pitch tracker.
        backend: 'pyin' or 'crepe'.
        crepe_model_size: 'tiny', 'small', 'medium', 'large', 'full'.
        """
        self.backend = backend
        self.crepe_model_size = crepe_model_size

    def track(self, audio: np.ndarray, sr: int, hop_length: int = 512):
        """
        Extracts pitch (frequencies) and confidences from the audio.
        Returns: (times, frequencies, confidences)
        """
        if self.backend == 'crepe':
            try:
                import crepe
            except ImportError:
                raise ImportError("The 'crepe' module is not installed. Please run 'pip install crepe'.")

            # TRANSLATION FIX: CREPE uses milliseconds (step_size), not samples (hop_length)
            step_size_ms = int((hop_length / sr) * 1000)
            if step_size_ms <= 0:
                step_size_ms = 10  # Fallback to standard 10ms step
                
            # Suppress excessive TensorFlow warnings during inference
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                times, frequencies, confidences, _ = crepe.predict(
                    audio, 
                    sr, 
                    viterbi=True, 
                    step_size=step_size_ms, 
                    model_capacity=self.crepe_model_size,
                    verbose=0
                )
            
            return times, frequencies, confidences

        else:
            # Default fallback to librosa's pyin
            fmin = librosa.note_to_hz('C2')
            fmax = librosa.note_to_hz('C7')
            
            frequencies, voiced_flag, confidences = librosa.pyin(
                audio, 
                fmin=fmin, 
                fmax=fmax, 
                sr=sr, 
                hop_length=hop_length
            )
            
            times = librosa.times_like(frequencies, sr=sr, hop_length=hop_length)
            
            # Clean up NaNs so downstream instruments don't crash
            frequencies = np.nan_to_num(frequencies)
            confidences = np.nan_to_num(confidences)
            
            return times, frequencies, confidences