#!/usr/bin/env python3
"""
Breath / noise vs voiced detector.

A singer's breath has ENERGY but no HARMONICS. Pitch trackers can lock onto
spurious pitches during breaths, and RMS presence gates stay open. This
module scores each frame for harmonic content (0 = breath/noise, 1 = voiced)
using spectral flatness + harmonic prominence.
"""
import numpy as np


def breath_quality(audio, sr, times, win_s=0.10):
    """Return a voiced-quality in [0,1] for each timestamp in `times`."""
    v = np.asarray(audio, dtype=np.float64)
    if v.ndim > 1:
        v = v.mean(axis=1)
    n = len(v)
    win = int(win_s * sr)
    if n < win or len(times) == 0:
        return np.ones_like(times)

    qs, ts = [], []
    hop = win // 2
    eps = 1e-12

    for start in range(0, n - win, hop):
        fr = v[start:start + win] * np.hanning(win)
        spec = np.abs(np.fft.rfft(fr))
        power = spec ** 2

        # Spectral flatness: ~1 for noise/breath, ~0 for harmonics
        am = np.mean(power) + eps
        gm = np.exp(np.mean(np.log(power + eps)))
        flat = float(np.clip(gm / am, 0.0, 1.0))

        # Harmonic prominence: energy at best f0 and its harmonics
        lo_bin = max(2, int(60 * win_s))          # 60 Hz
        hi_bin = min(len(spec) - 1, int(500 * win_s))  # 500 Hz
        if hi_bin <= lo_bin:
            qs.append(0.0); ts.append((start + win / 2) / sr); continue

        f0 = lo_bin + int(np.argmax(spec[lo_bin:hi_bin]))
        total = np.sum(power) + eps
        harm = 0.0
        for k in (1, 2, 3, 4, 5):
            b = f0 * k
            a = max(0, b - 2); c = min(len(power), b + 3)
            harm += np.sum(power[a:c])
        h = float(np.clip((harm / total) * 2.0, 0.0, 1.0))

        qs.append(h * (1.0 - flat))
        ts.append((start + win / 2) / sr)

    qs = np.asarray(qs, dtype=float)
    ts = np.asarray(ts, dtype=float)

    if len(qs) >= 5:
        kern = np.array([1, 2, 3, 2, 1], float); kern /= kern.sum()
        qs = np.convolve(qs, kern, mode="same")

    return np.interp(times, ts, np.clip(qs * 1.6, 0.0, 1.0))