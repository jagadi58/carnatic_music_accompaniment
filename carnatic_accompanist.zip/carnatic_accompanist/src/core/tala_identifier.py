#!/usr/bin/env python3
"""
Tala identifier for Carnatic Accompanist.
Estimates tempo and matches rhythmic periodicity to known tala structures.
"""

import numpy as np
import librosa
from typing import List, Dict, Optional

from src.utils.json_db import JSONDatabase


class TalaIdentifier:
    """Identifies the tala based on audio onset and tempo analysis."""
    
    def __init__(self, db_path: str):
        self.db = JSONDatabase(db_path, default_data={"talas": []})
    
    def identify_tala(
        self, 
        audio: np.ndarray, 
        sr: int,
        hop_length: int = 512
    ) -> List[Dict[str, any]]:
        """
        Identify the most likely talas from audio.
        """
        # 1. Extract onset strength envelope
        onset_env = librosa.onset.onset_strength(y=audio, sr=sr, hop_length=hop_length)
        
        if np.max(onset_env) < 1e-5:
            return []  # Silence or no transients
        
        # 2. Estimate tempo
        tempo, beat_frames = librosa.beat.beat_track(
            onset_envelope=onset_env, 
            sr=sr, 
            hop_length=hop_length,
            trim=False
        )
        
        # FIX: Ensure tempo is a scalar float, not a numpy array
        if isinstance(tempo, np.ndarray):
            tempo = float(tempo[0]) if len(tempo) > 0 else 0.0
        else:
            tempo = float(tempo)
            
        if tempo <= 0:
            return []
        
        # Get a few candidate tempos (librosa's pulse train can have harmonics)
        candidate_tempos = [tempo]
        if tempo > 80:
            candidate_tempos.append(tempo / 2.0)
        if tempo < 120:
            candidate_tempos.append(tempo * 2.0)
        
        talas = self.db.get_all("talas")
        scores = []
        
        # Time axis for onset envelope
        times = librosa.times_like(onset_env, sr=sr, hop_length=hop_length)
        
        for tala in talas:
            aksharas = tala.get("aksharas", 8)
            best_score = 0.0
            best_bpm = tempo
            
            for cand_tempo in candidate_tempos:
                if cand_tempo <= 0:
                    continue
                
                # FIX: Ensure cycle_duration is a scalar float
                cycle_duration = float((aksharas * 60.0) / float(cand_tempo))
                
                # Score based on periodicity: cross-correlate onset envelope with a pulse train
                score = self._calculate_periodicity_score(onset_env, times, cycle_duration)
                
                # Bonus for tempo being in a "natural" Carnatic range (60 - 150 aksharas/min)
                tempo_bonus = 0.0
                if 60 <= cand_tempo <= 150:
                    tempo_bonus = 0.15
                elif 40 <= cand_tempo <= 200:
                    tempo_bonus = 0.05
                
                total_score = score + tempo_bonus
                
                if total_score > best_score:
                    best_score = total_score
                    best_bpm = cand_tempo
            
            if best_score > 0.05:  # Threshold to avoid returning garbage
                scores.append({
                    "name": tala["name"],
                    "bpm": round(float(best_bpm), 1),
                    "score": min(1.0, float(best_score)),
                    "aksharas": aksharas,
                    "structure": tala.get("structure", ""),
                    "description": tala.get("description", "")
                })
        
        # Sort by score descending
        scores.sort(key=lambda x: x["score"], reverse=True)
        return scores
    
    def _calculate_periodicity_score(
        self, 
        onset_env: np.ndarray, 
        times: np.ndarray, 
        cycle_duration: float
    ) -> float:
        """
        Calculate how well the onset envelope matches a periodic pulse at cycle_duration.
        """
        # FIX: Explicitly cast to float to prevent numpy array type errors
        cycle_duration = float(cycle_duration)
        
        # Create a pulse train at the expected cycle frequency
        sr_env = len(times) / times[-1] if times[-1] > 0 else 1.0
        pulse_period_samples = int(cycle_duration * sr_env)
        
        if pulse_period_samples < 2 or pulse_period_samples > len(onset_env) // 2:
            return 0.0
        
        # Generate pulse train
        pulse_train = np.zeros_like(onset_env)
        for i in range(0, len(onset_env), pulse_period_samples):
            # Gaussian spread of ~50ms
            spread = int(0.05 * sr_env)
            start = max(0, i - spread)
            end = min(len(onset_env), i + spread + 1)
            x = np.linspace(-spread, spread, end - start)
            pulse_train[start:end] += np.exp(-(x**2) / (2 * (spread/2)**2))
        
        # Normalize
        if np.max(pulse_train) > 0:
            pulse_train /= np.max(pulse_train)
        
        # Cross-correlation
        correlation = np.correlate(onset_env, pulse_train, mode='valid')
        
        # Normalize correlation score to [0, 1]
        max_corr = np.max(correlation)
        env_energy = np.sum(onset_env)
        if env_energy > 0:
            return float(max_corr / (env_energy / len(onset_env)))
        return 0.0